.class public final Landroidx/media3/exoplayer/analytics/MediaMetricsListener;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"

# interfaces
.implements Landroidx/media3/exoplayer/analytics/AnalyticsListener;
.implements Landroidx/media3/exoplayer/analytics/PlaybackSessionManager$Listener;


# instance fields
.field public activeSessionId:Ljava/lang/String;

.field public audioUnderruns:I

.field public final backgroundExecutor:Ljava/util/concurrent/Executor;

.field public final bandwidthBytes:Ljava/util/HashMap;

.field public final bandwidthTimeMs:Ljava/util/HashMap;

.field public final context:Landroid/content/Context;

.field public currentAudioFormat:Landroidx/media3/common/Format;

.field public currentNetworkType:I

.field public currentPlaybackState:I

.field public currentTextFormat:Landroidx/media3/common/Format;

.field public currentVideoFormat:Landroidx/media3/common/Format;

.field public discontinuityReason:I

.field public droppedFrames:I

.field public hasFatalError:Z

.field public ioErrorType:Z

.field public isSeeking:Z

.field public metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

.field public pendingAudioFormat:Landroidx/compose/ui/platform/WeakCache;

.field public pendingPlayerError:Landroidx/media3/common/PlaybackException;

.field public pendingTextFormat:Landroidx/compose/ui/platform/WeakCache;

.field public pendingVideoFormat:Landroidx/compose/ui/platform/WeakCache;

.field public final period:Landroidx/media3/common/Timeline$Period;

.field public final playbackSession:Landroid/media/metrics/PlaybackSession;

.field public playedFrames:I

.field public reportedEventsForCurrentSession:Z

.field public final sessionManager:Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;

.field public final startTimeMs:J

.field public final window:Landroidx/media3/common/Timeline$Window;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/media/metrics/PlaybackSession;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->context:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 11
    .line 12
    invoke-static {}, Landroidx/media3/common/util/Log;->get()Ljava/util/concurrent/Executor;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->backgroundExecutor:Ljava/util/concurrent/Executor;

    .line 17
    .line 18
    new-instance p1, Landroidx/media3/common/Timeline$Window;

    .line 19
    .line 20
    invoke-direct {p1}, Landroidx/media3/common/Timeline$Window;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->window:Landroidx/media3/common/Timeline$Window;

    .line 24
    .line 25
    new-instance p1, Landroidx/media3/common/Timeline$Period;

    .line 26
    .line 27
    invoke-direct {p1}, Landroidx/media3/common/Timeline$Period;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->period:Landroidx/media3/common/Timeline$Period;

    .line 31
    .line 32
    new-instance p1, Ljava/util/HashMap;

    .line 33
    .line 34
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthBytes:Ljava/util/HashMap;

    .line 38
    .line 39
    new-instance p1, Ljava/util/HashMap;

    .line 40
    .line 41
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthTimeMs:Ljava/util/HashMap;

    .line 45
    .line 46
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 47
    .line 48
    .line 49
    move-result-wide p1

    .line 50
    iput-wide p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->startTimeMs:J

    .line 51
    .line 52
    const/4 p1, 0x0

    .line 53
    iput p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentPlaybackState:I

    .line 54
    .line 55
    iput p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentNetworkType:I

    .line 56
    .line 57
    new-instance p1, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;

    .line 58
    .line 59
    invoke-direct {p1}, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;-><init>()V

    .line 60
    .line 61
    .line 62
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->sessionManager:Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;

    .line 63
    .line 64
    iput-object p0, p1, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->listener:Landroidx/media3/exoplayer/analytics/PlaybackSessionManager$Listener;

    .line 65
    .line 66
    return-void
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
.end method

.method public static create(Landroid/content/Context;)Landroidx/media3/exoplayer/analytics/MediaMetricsListener;
    .locals 2

    .line 1
    const-string v0, "media_metrics"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/media/metrics/MediaMetricsManager;

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    return-object p0

    .line 13
    :cond_0
    new-instance v1, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;

    .line 14
    .line 15
    invoke-virtual {v0}, Landroid/media/metrics/MediaMetricsManager;->createPlaybackSession()Landroid/media/metrics/PlaybackSession;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-direct {v1, p0, v0}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;-><init>(Landroid/content/Context;Landroid/media/metrics/PlaybackSession;)V

    .line 20
    .line 21
    .line 22
    return-object v1
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method


# virtual methods
.method public final canReportPendingFormatUpdate(Landroidx/compose/ui/platform/WeakCache;)Z
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    iget-object p1, p1, Landroidx/compose/ui/platform/WeakCache;->referenceQueue:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p1, Ljava/lang/String;

    .line 6
    .line 7
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->sessionManager:Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;

    .line 8
    .line 9
    monitor-enter p0

    .line 10
    :try_start_0
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->currentSessionId:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    .line 12
    monitor-exit p0

    .line 13
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-eqz p0, :cond_0

    .line 18
    .line 19
    const/4 p0, 0x1

    .line 20
    return p0

    .line 21
    :catchall_0
    move-exception p1

    .line 22
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 23
    throw p1

    .line 24
    :cond_0
    const/4 p0, 0x0

    .line 25
    return p0
    .line 26
    .line 27
.end method

.method public final finishCurrentSession()V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_3

    .line 5
    .line 6
    iget-boolean v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportedEventsForCurrentSession:Z

    .line 7
    .line 8
    if-eqz v2, :cond_3

    .line 9
    .line 10
    iget v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->audioUnderruns:I

    .line 11
    .line 12
    invoke-virtual {v0, v2}, Landroid/media/metrics/PlaybackMetrics$Builder;->setAudioUnderrunCount(I)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 16
    .line 17
    iget v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->droppedFrames:I

    .line 18
    .line 19
    invoke-virtual {v0, v2}, Landroid/media/metrics/PlaybackMetrics$Builder;->setVideoFramesDropped(I)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 23
    .line 24
    iget v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playedFrames:I

    .line 25
    .line 26
    invoke-virtual {v0, v2}, Landroid/media/metrics/PlaybackMetrics$Builder;->setVideoFramesPlayed(I)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthTimeMs:Ljava/util/HashMap;

    .line 30
    .line 31
    iget-object v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->activeSessionId:Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Ljava/lang/Long;

    .line 38
    .line 39
    iget-object v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 40
    .line 41
    const-wide/16 v3, 0x0

    .line 42
    .line 43
    if-nez v0, :cond_0

    .line 44
    .line 45
    move-wide v5, v3

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 48
    .line 49
    .line 50
    move-result-wide v5

    .line 51
    :goto_0
    invoke-virtual {v2, v5, v6}, Landroid/media/metrics/PlaybackMetrics$Builder;->setNetworkTransferDurationMillis(J)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 52
    .line 53
    .line 54
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthBytes:Ljava/util/HashMap;

    .line 55
    .line 56
    iget-object v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->activeSessionId:Ljava/lang/String;

    .line 57
    .line 58
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    check-cast v0, Ljava/lang/Long;

    .line 63
    .line 64
    iget-object v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 65
    .line 66
    if-nez v0, :cond_1

    .line 67
    .line 68
    move-wide v5, v3

    .line 69
    goto :goto_1

    .line 70
    :cond_1
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 71
    .line 72
    .line 73
    move-result-wide v5

    .line 74
    :goto_1
    invoke-virtual {v2, v5, v6}, Landroid/media/metrics/PlaybackMetrics$Builder;->setNetworkBytesRead(J)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 75
    .line 76
    .line 77
    iget-object v2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 78
    .line 79
    if-eqz v0, :cond_2

    .line 80
    .line 81
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 82
    .line 83
    .line 84
    move-result-wide v5

    .line 85
    cmp-long v0, v5, v3

    .line 86
    .line 87
    if-lez v0, :cond_2

    .line 88
    .line 89
    const/4 v0, 0x1

    .line 90
    goto :goto_2

    .line 91
    :cond_2
    move v0, v1

    .line 92
    :goto_2
    invoke-virtual {v2, v0}, Landroid/media/metrics/PlaybackMetrics$Builder;->setStreamSource(I)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 93
    .line 94
    .line 95
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 96
    .line 97
    invoke-virtual {v0}, Landroid/media/metrics/PlaybackMetrics$Builder;->build()Landroid/media/metrics/PlaybackMetrics;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    new-instance v2, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 102
    .line 103
    const/16 v3, 0x11

    .line 104
    .line 105
    invoke-direct {v2, p0, v0, v3}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 106
    .line 107
    .line 108
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->backgroundExecutor:Ljava/util/concurrent/Executor;

    .line 109
    .line 110
    invoke-interface {v0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 111
    .line 112
    .line 113
    :cond_3
    const/4 v0, 0x0

    .line 114
    iput-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 115
    .line 116
    iput-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->activeSessionId:Ljava/lang/String;

    .line 117
    .line 118
    iput v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->audioUnderruns:I

    .line 119
    .line 120
    iput v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->droppedFrames:I

    .line 121
    .line 122
    iput v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playedFrames:I

    .line 123
    .line 124
    iput-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentVideoFormat:Landroidx/media3/common/Format;

    .line 125
    .line 126
    iput-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentAudioFormat:Landroidx/media3/common/Format;

    .line 127
    .line 128
    iput-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentTextFormat:Landroidx/media3/common/Format;

    .line 129
    .line 130
    iput-boolean v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportedEventsForCurrentSession:Z

    .line 131
    .line 132
    return-void
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
.end method

.method public final getLogSessionId()Landroid/media/metrics/LogSessionId;
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/media/metrics/PlaybackSession;->getSessionId()Landroid/media/metrics/LogSessionId;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
.end method

.method public final synthetic lambda$finishCurrentSession$4(Landroid/media/metrics/PlaybackMetrics;)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroid/media/metrics/PlaybackSession;->reportPlaybackMetrics(Landroid/media/metrics/PlaybackMetrics;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final synthetic lambda$maybeReportNetworkChange$1(Landroid/media/metrics/NetworkEvent;)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroid/media/metrics/PlaybackSession;->reportNetworkEvent(Landroid/media/metrics/NetworkEvent;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final synthetic lambda$maybeReportPlaybackError$0(Landroid/media/metrics/PlaybackErrorEvent;)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroid/media/metrics/PlaybackSession;->reportPlaybackErrorEvent(Landroid/media/metrics/PlaybackErrorEvent;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final synthetic lambda$maybeReportPlaybackStateChange$2(Landroid/media/metrics/PlaybackStateEvent;)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroid/media/metrics/PlaybackSession;->reportPlaybackStateEvent(Landroid/media/metrics/PlaybackStateEvent;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final synthetic lambda$reportTrackChangeEvent$3(Landroid/media/metrics/TrackChangeEvent;)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playbackSession:Landroid/media/metrics/PlaybackSession;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroid/media/metrics/PlaybackSession;->reportTrackChangeEvent(Landroid/media/metrics/TrackChangeEvent;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final maybeUpdateTimelineMetadata(Landroidx/media3/common/Timeline;Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;)V
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 2
    .line 3
    if-nez p2, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    iget-object p2, p2, Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;->periodUid:Ljava/lang/Object;

    .line 7
    .line 8
    invoke-virtual {p1, p2}, Landroidx/media3/common/Timeline;->getIndexOfPeriod(Ljava/lang/Object;)I

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    const/4 v1, -0x1

    .line 13
    if-ne p2, v1, :cond_1

    .line 14
    .line 15
    :goto_0
    return-void

    .line 16
    :cond_1
    iget-object v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->period:Landroidx/media3/common/Timeline$Period;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {p1, p2, v1, v2}, Landroidx/media3/common/Timeline;->getPeriod(ILandroidx/media3/common/Timeline$Period;Z)Landroidx/media3/common/Timeline$Period;

    .line 20
    .line 21
    .line 22
    iget p2, v1, Landroidx/media3/common/Timeline$Period;->windowIndex:I

    .line 23
    .line 24
    iget-object v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->window:Landroidx/media3/common/Timeline$Window;

    .line 25
    .line 26
    invoke-virtual {p1, p2, v1}, Landroidx/media3/common/Timeline;->getWindow(ILandroidx/media3/common/Timeline$Window;)V

    .line 27
    .line 28
    .line 29
    iget-object p1, v1, Landroidx/media3/common/Timeline$Window;->mediaItem:Landroidx/media3/common/MediaItem;

    .line 30
    .line 31
    iget-object p1, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 32
    .line 33
    const/4 p2, 0x2

    .line 34
    const/4 v3, 0x1

    .line 35
    if-nez p1, :cond_2

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_2
    iget-object v2, p1, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 39
    .line 40
    iget-object p1, p1, Landroidx/media3/common/MediaItem$LocalConfiguration;->mimeType:Ljava/lang/String;

    .line 41
    .line 42
    invoke-static {v2, p1}, Landroidx/media3/common/util/Util;->inferContentTypeForUriAndMimeType(Landroid/net/Uri;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    if-eqz p1, :cond_5

    .line 47
    .line 48
    if-eq p1, v3, :cond_4

    .line 49
    .line 50
    if-eq p1, p2, :cond_3

    .line 51
    .line 52
    move v2, v3

    .line 53
    goto :goto_1

    .line 54
    :cond_3
    const/4 v2, 0x4

    .line 55
    goto :goto_1

    .line 56
    :cond_4
    const/4 v2, 0x5

    .line 57
    goto :goto_1

    .line 58
    :cond_5
    const/4 v2, 0x3

    .line 59
    :goto_1
    invoke-virtual {v0, v2}, Landroid/media/metrics/PlaybackMetrics$Builder;->setStreamType(I)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 60
    .line 61
    .line 62
    iget-wide v4, v1, Landroidx/media3/common/Timeline$Window;->durationUs:J

    .line 63
    .line 64
    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    cmp-long p1, v4, v6

    .line 70
    .line 71
    if-eqz p1, :cond_6

    .line 72
    .line 73
    iget-boolean p1, v1, Landroidx/media3/common/Timeline$Window;->isPlaceholder:Z

    .line 74
    .line 75
    if-nez p1, :cond_6

    .line 76
    .line 77
    iget-boolean p1, v1, Landroidx/media3/common/Timeline$Window;->isDynamic:Z

    .line 78
    .line 79
    if-nez p1, :cond_6

    .line 80
    .line 81
    invoke-virtual {v1}, Landroidx/media3/common/Timeline$Window;->isLive()Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-nez p1, :cond_6

    .line 86
    .line 87
    iget-wide v4, v1, Landroidx/media3/common/Timeline$Window;->durationUs:J

    .line 88
    .line 89
    invoke-static {v4, v5}, Landroidx/media3/common/util/Util;->usToMs(J)J

    .line 90
    .line 91
    .line 92
    move-result-wide v4

    .line 93
    invoke-virtual {v0, v4, v5}, Landroid/media/metrics/PlaybackMetrics$Builder;->setMediaDurationMillis(J)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 94
    .line 95
    .line 96
    :cond_6
    invoke-virtual {v1}, Landroidx/media3/common/Timeline$Window;->isLive()Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    if-eqz p1, :cond_7

    .line 101
    .line 102
    goto :goto_2

    .line 103
    :cond_7
    move p2, v3

    .line 104
    :goto_2
    invoke-virtual {v0, p2}, Landroid/media/metrics/PlaybackMetrics$Builder;->setPlaybackType(I)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 105
    .line 106
    .line 107
    iput-boolean v3, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportedEventsForCurrentSession:Z

    .line 108
    .line 109
    return-void
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
.end method

.method public final onAdPlaybackStarted(Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final onBandwidthEstimate(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;IJ)V
    .locals 7

    .line 1
    iget-object v0, p1, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->mediaPeriodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    iget-object v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->sessionManager:Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;

    .line 6
    .line 7
    iget-object p1, p1, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->timeline:Landroidx/media3/common/Timeline;

    .line 8
    .line 9
    invoke-virtual {v1, p1, v0}, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->getSessionForMediaPeriodId(Landroidx/media3/common/Timeline;Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthBytes:Ljava/util/HashMap;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Ljava/lang/Long;

    .line 20
    .line 21
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthTimeMs:Ljava/util/HashMap;

    .line 22
    .line 23
    invoke-virtual {p0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    check-cast v2, Ljava/lang/Long;

    .line 28
    .line 29
    const-wide/16 v3, 0x0

    .line 30
    .line 31
    if-nez v1, :cond_0

    .line 32
    .line 33
    move-wide v5, v3

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 36
    .line 37
    .line 38
    move-result-wide v5

    .line 39
    :goto_0
    add-long/2addr v5, p3

    .line 40
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 41
    .line 42
    .line 43
    move-result-object p3

    .line 44
    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    if-nez v2, :cond_1

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_1
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 51
    .line 52
    .line 53
    move-result-wide v3

    .line 54
    :goto_1
    int-to-long p2, p2

    .line 55
    add-long/2addr v3, p2

    .line 56
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    invoke-virtual {p0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    :cond_2
    return-void
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
.end method

.method public final onDownstreamFormatChanged(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Landroidx/compose/animation/core/FloatTweenSpec;)V
    .locals 4

    .line 1
    iget-object v0, p1, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->mediaPeriodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    new-instance v1, Landroidx/compose/ui/platform/WeakCache;

    .line 7
    .line 8
    iget-object v2, p2, Landroidx/compose/animation/core/FloatTweenSpec;->easing:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v2, Landroidx/media3/common/Format;

    .line 11
    .line 12
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    iget-object p1, p1, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->timeline:Landroidx/media3/common/Timeline;

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    iget-object v3, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->sessionManager:Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;

    .line 21
    .line 22
    invoke-virtual {v3, p1, v0}, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->getSessionForMediaPeriodId(Landroidx/media3/common/Timeline;Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    const/16 v0, 0x17

    .line 27
    .line 28
    invoke-direct {v1, v2, p1, v0}, Landroidx/compose/ui/platform/WeakCache;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 29
    .line 30
    .line 31
    iget p1, p2, Landroidx/compose/animation/core/FloatTweenSpec;->duration:I

    .line 32
    .line 33
    if-eqz p1, :cond_3

    .line 34
    .line 35
    const/4 p2, 0x1

    .line 36
    if-eq p1, p2, :cond_2

    .line 37
    .line 38
    const/4 p2, 0x2

    .line 39
    if-eq p1, p2, :cond_3

    .line 40
    .line 41
    const/4 p2, 0x3

    .line 42
    if-eq p1, p2, :cond_1

    .line 43
    .line 44
    :goto_0
    return-void

    .line 45
    :cond_1
    iput-object v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingTextFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 46
    .line 47
    return-void

    .line 48
    :cond_2
    iput-object v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingAudioFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 49
    .line 50
    return-void

    .line 51
    :cond_3
    iput-object v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingVideoFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 52
    .line 53
    return-void
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
.end method

.method public final onEvents(Landroidx/media3/common/Player;Landroidx/core/provider/CallbackWrapper;)V
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    iget-object v2, v1, Landroidx/core/provider/CallbackWrapper;->mCallback:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v2, Landroidx/media3/common/FlagSet;

    .line 8
    .line 9
    iget-object v3, v2, Landroidx/media3/common/FlagSet;->flags:Landroid/util/SparseBooleanArray;

    .line 10
    .line 11
    invoke-virtual {v3}, Landroid/util/SparseBooleanArray;->size()I

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    if-nez v3, :cond_0

    .line 16
    .line 17
    goto/16 :goto_26

    .line 18
    .line 19
    :cond_0
    const/4 v3, 0x0

    .line 20
    move v4, v3

    .line 21
    :goto_0
    iget-object v5, v2, Landroidx/media3/common/FlagSet;->flags:Landroid/util/SparseBooleanArray;

    .line 22
    .line 23
    invoke-virtual {v5}, Landroid/util/SparseBooleanArray;->size()I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    iget-object v6, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->sessionManager:Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;

    .line 28
    .line 29
    const/16 v7, 0xb

    .line 30
    .line 31
    if-ge v4, v5, :cond_3

    .line 32
    .line 33
    invoke-virtual {v2, v4}, Landroidx/media3/common/FlagSet;->get(I)I

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    invoke-virtual {v1, v5}, Landroidx/core/provider/CallbackWrapper;->getEventTime(I)Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;

    .line 38
    .line 39
    .line 40
    move-result-object v8

    .line 41
    if-nez v5, :cond_1

    .line 42
    .line 43
    invoke-virtual {v6, v8}, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->updateSessionsWithTimelineChange(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    if-ne v5, v7, :cond_2

    .line 48
    .line 49
    iget v5, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->discontinuityReason:I

    .line 50
    .line 51
    invoke-virtual {v6, v5, v8}, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->updateSessionsWithDiscontinuity(ILandroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 52
    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_2
    invoke-virtual {v6, v8}, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->updateSessions(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 56
    .line 57
    .line 58
    :goto_1
    add-int/lit8 v4, v4, 0x1

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_3
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 62
    .line 63
    .line 64
    move-result-wide v4

    .line 65
    invoke-virtual {v1, v3}, Landroidx/core/provider/CallbackWrapper;->contains(I)Z

    .line 66
    .line 67
    .line 68
    move-result v2

    .line 69
    if-eqz v2, :cond_4

    .line 70
    .line 71
    invoke-virtual {v1, v3}, Landroidx/core/provider/CallbackWrapper;->getEventTime(I)Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    iget-object v8, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 76
    .line 77
    if-eqz v8, :cond_4

    .line 78
    .line 79
    iget-object v8, v2, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->timeline:Landroidx/media3/common/Timeline;

    .line 80
    .line 81
    iget-object v2, v2, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->mediaPeriodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 82
    .line 83
    invoke-virtual {v0, v8, v2}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->maybeUpdateTimelineMetadata(Landroidx/media3/common/Timeline;Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;)V

    .line 84
    .line 85
    .line 86
    :cond_4
    const/4 v2, 0x2

    .line 87
    invoke-virtual {v1, v2}, Landroidx/core/provider/CallbackWrapper;->contains(I)Z

    .line 88
    .line 89
    .line 90
    move-result v8

    .line 91
    const/4 v12, 0x1

    .line 92
    if-eqz v8, :cond_c

    .line 93
    .line 94
    iget-object v8, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 95
    .line 96
    if-eqz v8, :cond_c

    .line 97
    .line 98
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getCurrentTracks()Landroidx/media3/common/Tracks;

    .line 99
    .line 100
    .line 101
    move-result-object v8

    .line 102
    iget-object v8, v8, Landroidx/media3/common/Tracks;->groups:Lcom/google/common/collect/ImmutableList;

    .line 103
    .line 104
    invoke-virtual {v8, v3}, Lcom/google/common/collect/ImmutableList;->listIterator(I)Lcom/google/common/collect/ImmutableList$Itr;

    .line 105
    .line 106
    .line 107
    move-result-object v8

    .line 108
    :cond_5
    invoke-virtual {v8}, Lcom/google/common/collect/AbstractIndexedListIterator;->hasNext()Z

    .line 109
    .line 110
    .line 111
    move-result v13

    .line 112
    if-eqz v13, :cond_7

    .line 113
    .line 114
    invoke-virtual {v8}, Lcom/google/common/collect/AbstractIndexedListIterator;->next()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v13

    .line 118
    check-cast v13, Landroidx/media3/common/Tracks$Group;

    .line 119
    .line 120
    move v14, v3

    .line 121
    :goto_2
    iget v15, v13, Landroidx/media3/common/Tracks$Group;->length:I

    .line 122
    .line 123
    if-ge v14, v15, :cond_5

    .line 124
    .line 125
    iget-object v15, v13, Landroidx/media3/common/Tracks$Group;->trackSelected:[Z

    .line 126
    .line 127
    aget-boolean v15, v15, v14

    .line 128
    .line 129
    if-eqz v15, :cond_6

    .line 130
    .line 131
    iget-object v15, v13, Landroidx/media3/common/Tracks$Group;->mediaTrackGroup:Landroidx/media3/common/TrackGroup;

    .line 132
    .line 133
    iget-object v15, v15, Landroidx/media3/common/TrackGroup;->formats:[Landroidx/media3/common/Format;

    .line 134
    .line 135
    aget-object v15, v15, v14

    .line 136
    .line 137
    iget-object v15, v15, Landroidx/media3/common/Format;->drmInitData:Landroidx/media3/common/DrmInitData;

    .line 138
    .line 139
    if-eqz v15, :cond_6

    .line 140
    .line 141
    goto :goto_3

    .line 142
    :cond_6
    add-int/lit8 v14, v14, 0x1

    .line 143
    .line 144
    goto :goto_2

    .line 145
    :cond_7
    const/4 v15, 0x0

    .line 146
    :goto_3
    if-eqz v15, :cond_c

    .line 147
    .line 148
    iget-object v8, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 149
    .line 150
    sget-object v13, Landroidx/media3/common/util/Util;->DEVICE_DEBUG_INFO:Ljava/lang/String;

    .line 151
    .line 152
    move v13, v3

    .line 153
    :goto_4
    iget v14, v15, Landroidx/media3/common/DrmInitData;->schemeDataCount:I

    .line 154
    .line 155
    if-ge v13, v14, :cond_b

    .line 156
    .line 157
    iget-object v14, v15, Landroidx/media3/common/DrmInitData;->schemeDatas:[Landroidx/media3/common/DrmInitData$SchemeData;

    .line 158
    .line 159
    aget-object v14, v14, v13

    .line 160
    .line 161
    iget-object v14, v14, Landroidx/media3/common/DrmInitData$SchemeData;->uuid:Ljava/util/UUID;

    .line 162
    .line 163
    sget-object v7, Landroidx/media3/common/C;->WIDEVINE_UUID:Ljava/util/UUID;

    .line 164
    .line 165
    invoke-virtual {v14, v7}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    .line 166
    .line 167
    .line 168
    move-result v7

    .line 169
    if-eqz v7, :cond_8

    .line 170
    .line 171
    const/4 v7, 0x3

    .line 172
    goto :goto_5

    .line 173
    :cond_8
    sget-object v7, Landroidx/media3/common/C;->PLAYREADY_UUID:Ljava/util/UUID;

    .line 174
    .line 175
    invoke-virtual {v14, v7}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    move-result v7

    .line 179
    if-eqz v7, :cond_9

    .line 180
    .line 181
    move v7, v2

    .line 182
    goto :goto_5

    .line 183
    :cond_9
    sget-object v7, Landroidx/media3/common/C;->CLEARKEY_UUID:Ljava/util/UUID;

    .line 184
    .line 185
    invoke-virtual {v14, v7}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result v7

    .line 189
    if-eqz v7, :cond_a

    .line 190
    .line 191
    const/4 v7, 0x6

    .line 192
    goto :goto_5

    .line 193
    :cond_a
    add-int/lit8 v13, v13, 0x1

    .line 194
    .line 195
    const/16 v7, 0xb

    .line 196
    .line 197
    goto :goto_4

    .line 198
    :cond_b
    move v7, v12

    .line 199
    :goto_5
    invoke-virtual {v8, v7}, Landroid/media/metrics/PlaybackMetrics$Builder;->setDrmType(I)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 200
    .line 201
    .line 202
    :cond_c
    const/16 v7, 0x3f3

    .line 203
    .line 204
    invoke-virtual {v1, v7}, Landroidx/core/provider/CallbackWrapper;->contains(I)Z

    .line 205
    .line 206
    .line 207
    move-result v7

    .line 208
    if-eqz v7, :cond_d

    .line 209
    .line 210
    iget v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->audioUnderruns:I

    .line 211
    .line 212
    add-int/2addr v7, v12

    .line 213
    iput v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->audioUnderruns:I

    .line 214
    .line 215
    :cond_d
    iget-object v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingPlayerError:Landroidx/media3/common/PlaybackException;

    .line 216
    .line 217
    iget-object v9, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->context:Landroid/content/Context;

    .line 218
    .line 219
    iget-object v8, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->backgroundExecutor:Ljava/util/concurrent/Executor;

    .line 220
    .line 221
    iget-wide v13, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->startTimeMs:J

    .line 222
    .line 223
    const/4 v10, 0x4

    .line 224
    if-nez v7, :cond_e

    .line 225
    .line 226
    move v15, v12

    .line 227
    const/16 v3, 0xd

    .line 228
    .line 229
    const/16 v16, 0x8

    .line 230
    .line 231
    const/16 v17, 0x7

    .line 232
    .line 233
    const/16 v18, 0x6

    .line 234
    .line 235
    const/16 v19, 0x9

    .line 236
    .line 237
    const/16 v20, 0x5

    .line 238
    .line 239
    :goto_6
    const/4 v2, 0x2

    .line 240
    goto/16 :goto_17

    .line 241
    .line 242
    :cond_e
    iget v11, v7, Landroidx/media3/common/PlaybackException;->errorCode:I

    .line 243
    .line 244
    iget-boolean v15, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->ioErrorType:Z

    .line 245
    .line 246
    if-ne v15, v10, :cond_f

    .line 247
    .line 248
    move v15, v12

    .line 249
    goto :goto_7

    .line 250
    :cond_f
    move v15, v3

    .line 251
    :goto_7
    const/16 v10, 0x3e9

    .line 252
    .line 253
    if-ne v11, v10, :cond_10

    .line 254
    .line 255
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 256
    .line 257
    const/16 v11, 0x14

    .line 258
    .line 259
    invoke-direct {v10, v11, v3}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 260
    .line 261
    .line 262
    const/16 v3, 0xd

    .line 263
    .line 264
    const/16 v16, 0x8

    .line 265
    .line 266
    const/16 v17, 0x7

    .line 267
    .line 268
    const/16 v18, 0x6

    .line 269
    .line 270
    const/16 v19, 0x9

    .line 271
    .line 272
    const/16 v20, 0x5

    .line 273
    .line 274
    goto/16 :goto_16

    .line 275
    .line 276
    :cond_10
    instance-of v10, v7, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 277
    .line 278
    if-eqz v10, :cond_12

    .line 279
    .line 280
    move-object v10, v7

    .line 281
    check-cast v10, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 282
    .line 283
    iget-byte v3, v10, Landroidx/media3/exoplayer/ExoPlaybackException;->type:B

    .line 284
    .line 285
    if-ne v3, v12, :cond_11

    .line 286
    .line 287
    move v3, v12

    .line 288
    goto :goto_8

    .line 289
    :cond_11
    const/4 v3, 0x0

    .line 290
    :goto_8
    iget v10, v10, Landroidx/media3/exoplayer/ExoPlaybackException;->rendererFormatSupport:I

    .line 291
    .line 292
    goto :goto_9

    .line 293
    :cond_12
    const/4 v3, 0x0

    .line 294
    const/4 v10, 0x0

    .line 295
    :goto_9
    invoke-virtual {v7}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 296
    .line 297
    .line 298
    move-result-object v12

    .line 299
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 300
    .line 301
    .line 302
    instance-of v2, v12, Ljava/io/IOException;

    .line 303
    .line 304
    const/16 v21, 0x19

    .line 305
    .line 306
    const/16 v22, 0x1a

    .line 307
    .line 308
    move/from16 v23, v2

    .line 309
    .line 310
    const/16 v2, 0x17

    .line 311
    .line 312
    if-eqz v23, :cond_27

    .line 313
    .line 314
    instance-of v3, v12, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    .line 315
    .line 316
    if-eqz v3, :cond_13

    .line 317
    .line 318
    check-cast v12, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;

    .line 319
    .line 320
    iget v2, v12, Landroidx/media3/datasource/HttpDataSource$InvalidResponseCodeException;->responseCode:I

    .line 321
    .line 322
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 323
    .line 324
    const/4 v3, 0x5

    .line 325
    invoke-direct {v10, v3, v2}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 326
    .line 327
    .line 328
    :goto_a
    move/from16 v20, v3

    .line 329
    .line 330
    :goto_b
    const/16 v3, 0xd

    .line 331
    .line 332
    const/16 v16, 0x8

    .line 333
    .line 334
    const/16 v17, 0x7

    .line 335
    .line 336
    const/16 v18, 0x6

    .line 337
    .line 338
    :goto_c
    const/16 v19, 0x9

    .line 339
    .line 340
    goto/16 :goto_16

    .line 341
    .line 342
    :cond_13
    const/4 v3, 0x5

    .line 343
    instance-of v10, v12, Landroidx/media3/datasource/HttpDataSource$InvalidContentTypeException;

    .line 344
    .line 345
    if-nez v10, :cond_14

    .line 346
    .line 347
    instance-of v10, v12, Landroidx/media3/common/ParserException;

    .line 348
    .line 349
    if-eqz v10, :cond_15

    .line 350
    .line 351
    :cond_14
    const/4 v2, 0x7

    .line 352
    const/4 v11, 0x0

    .line 353
    const/16 v12, 0x8

    .line 354
    .line 355
    const/16 v18, 0x6

    .line 356
    .line 357
    goto/16 :goto_11

    .line 358
    .line 359
    :cond_15
    instance-of v10, v12, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    .line 360
    .line 361
    if-nez v10, :cond_16

    .line 362
    .line 363
    instance-of v15, v12, Landroidx/media3/datasource/UdpDataSource$UdpDataSourceException;

    .line 364
    .line 365
    if-eqz v15, :cond_17

    .line 366
    .line 367
    :cond_16
    const/16 v2, 0x9

    .line 368
    .line 369
    const/4 v11, 0x0

    .line 370
    goto/16 :goto_e

    .line 371
    .line 372
    :cond_17
    const/16 v10, 0x3ea

    .line 373
    .line 374
    if-ne v11, v10, :cond_18

    .line 375
    .line 376
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 377
    .line 378
    const/16 v2, 0x15

    .line 379
    .line 380
    const/4 v11, 0x0

    .line 381
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 382
    .line 383
    .line 384
    goto :goto_a

    .line 385
    :cond_18
    instance-of v10, v12, Landroidx/media3/exoplayer/drm/DrmSession$DrmSessionException;

    .line 386
    .line 387
    if-eqz v10, :cond_1f

    .line 388
    .line 389
    invoke-virtual {v12}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 390
    .line 391
    .line 392
    move-result-object v10

    .line 393
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 394
    .line 395
    .line 396
    instance-of v11, v10, Landroid/media/MediaDrm$MediaDrmStateException;

    .line 397
    .line 398
    if-eqz v11, :cond_19

    .line 399
    .line 400
    check-cast v10, Landroid/media/MediaDrm$MediaDrmStateException;

    .line 401
    .line 402
    invoke-virtual {v10}, Landroid/media/MediaDrm$MediaDrmStateException;->getDiagnosticInfo()Ljava/lang/String;

    .line 403
    .line 404
    .line 405
    move-result-object v2

    .line 406
    invoke-static {v2}, Landroidx/media3/common/util/Util;->getErrorCodeFromPlatformDiagnosticsInfo(Ljava/lang/String;)I

    .line 407
    .line 408
    .line 409
    move-result v2

    .line 410
    invoke-static {v2}, Landroidx/media3/common/util/Util;->getErrorCodeForMediaDrmErrorCode(I)I

    .line 411
    .line 412
    .line 413
    move-result v10

    .line 414
    packed-switch v10, :pswitch_data_0

    .line 415
    .line 416
    .line 417
    const/16 v10, 0x1b

    .line 418
    .line 419
    goto :goto_d

    .line 420
    :pswitch_0
    move/from16 v10, v22

    .line 421
    .line 422
    goto :goto_d

    .line 423
    :pswitch_1
    move/from16 v10, v21

    .line 424
    .line 425
    goto :goto_d

    .line 426
    :pswitch_2
    const/16 v10, 0x1c

    .line 427
    .line 428
    goto :goto_d

    .line 429
    :pswitch_3
    const/16 v10, 0x18

    .line 430
    .line 431
    :goto_d
    new-instance v11, Landroidx/compose/material3/FabPlacement;

    .line 432
    .line 433
    invoke-direct {v11, v10, v2}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 434
    .line 435
    .line 436
    move/from16 v20, v3

    .line 437
    .line 438
    move-object v10, v11

    .line 439
    goto :goto_b

    .line 440
    :cond_19
    instance-of v11, v10, Landroid/media/MediaDrmResetException;

    .line 441
    .line 442
    if-eqz v11, :cond_1a

    .line 443
    .line 444
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 445
    .line 446
    const/16 v11, 0x1b

    .line 447
    .line 448
    const/4 v12, 0x0

    .line 449
    invoke-direct {v10, v11, v12}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 450
    .line 451
    .line 452
    goto :goto_a

    .line 453
    :cond_1a
    const/4 v12, 0x0

    .line 454
    instance-of v11, v10, Landroid/media/NotProvisionedException;

    .line 455
    .line 456
    if-eqz v11, :cond_1b

    .line 457
    .line 458
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 459
    .line 460
    const/16 v15, 0x18

    .line 461
    .line 462
    invoke-direct {v10, v15, v12}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 463
    .line 464
    .line 465
    goto/16 :goto_a

    .line 466
    .line 467
    :cond_1b
    instance-of v11, v10, Landroid/media/DeniedByServerException;

    .line 468
    .line 469
    if-eqz v11, :cond_1c

    .line 470
    .line 471
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 472
    .line 473
    const/16 v2, 0x1d

    .line 474
    .line 475
    invoke-direct {v10, v2, v12}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 476
    .line 477
    .line 478
    goto/16 :goto_a

    .line 479
    .line 480
    :cond_1c
    instance-of v11, v10, Landroidx/media3/exoplayer/drm/UnsupportedDrmException;

    .line 481
    .line 482
    if-eqz v11, :cond_1d

    .line 483
    .line 484
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 485
    .line 486
    invoke-direct {v10, v2, v12}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 487
    .line 488
    .line 489
    goto/16 :goto_a

    .line 490
    .line 491
    :cond_1d
    instance-of v2, v10, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$MissingSchemeDataException;

    .line 492
    .line 493
    if-eqz v2, :cond_1e

    .line 494
    .line 495
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 496
    .line 497
    const/16 v2, 0x1c

    .line 498
    .line 499
    invoke-direct {v10, v2, v12}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 500
    .line 501
    .line 502
    goto/16 :goto_a

    .line 503
    .line 504
    :cond_1e
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 505
    .line 506
    const/16 v2, 0x1e

    .line 507
    .line 508
    invoke-direct {v10, v2, v12}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 509
    .line 510
    .line 511
    goto/16 :goto_a

    .line 512
    .line 513
    :cond_1f
    instance-of v2, v12, Landroidx/media3/datasource/FileDataSource$FileDataSourceException;

    .line 514
    .line 515
    if-eqz v2, :cond_21

    .line 516
    .line 517
    invoke-virtual {v12}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 518
    .line 519
    .line 520
    move-result-object v2

    .line 521
    instance-of v2, v2, Ljava/io/FileNotFoundException;

    .line 522
    .line 523
    if-eqz v2, :cond_21

    .line 524
    .line 525
    invoke-virtual {v12}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 526
    .line 527
    .line 528
    move-result-object v2

    .line 529
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 530
    .line 531
    .line 532
    invoke-virtual {v2}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 533
    .line 534
    .line 535
    move-result-object v2

    .line 536
    instance-of v10, v2, Landroid/system/ErrnoException;

    .line 537
    .line 538
    if-eqz v10, :cond_20

    .line 539
    .line 540
    check-cast v2, Landroid/system/ErrnoException;

    .line 541
    .line 542
    iget v2, v2, Landroid/system/ErrnoException;->errno:I

    .line 543
    .line 544
    sget v10, Landroid/system/OsConstants;->EACCES:I

    .line 545
    .line 546
    if-ne v2, v10, :cond_20

    .line 547
    .line 548
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 549
    .line 550
    const/16 v2, 0x20

    .line 551
    .line 552
    const/4 v11, 0x0

    .line 553
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 554
    .line 555
    .line 556
    goto/16 :goto_a

    .line 557
    .line 558
    :cond_20
    const/4 v11, 0x0

    .line 559
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 560
    .line 561
    const/16 v2, 0x1f

    .line 562
    .line 563
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 564
    .line 565
    .line 566
    goto/16 :goto_a

    .line 567
    .line 568
    :cond_21
    const/4 v11, 0x0

    .line 569
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 570
    .line 571
    const/16 v2, 0x9

    .line 572
    .line 573
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 574
    .line 575
    .line 576
    move/from16 v19, v2

    .line 577
    .line 578
    move/from16 v20, v3

    .line 579
    .line 580
    const/16 v3, 0xd

    .line 581
    .line 582
    const/16 v16, 0x8

    .line 583
    .line 584
    const/16 v17, 0x7

    .line 585
    .line 586
    const/16 v18, 0x6

    .line 587
    .line 588
    goto/16 :goto_16

    .line 589
    .line 590
    :goto_e
    invoke-static {v9}, Landroidx/media3/common/util/NetworkTypeObserver;->getInstance(Landroid/content/Context;)Landroidx/media3/common/util/NetworkTypeObserver;

    .line 591
    .line 592
    .line 593
    move-result-object v15

    .line 594
    invoke-virtual {v15}, Landroidx/media3/common/util/NetworkTypeObserver;->getNetworkType()I

    .line 595
    .line 596
    .line 597
    move-result v15

    .line 598
    const/4 v2, 0x1

    .line 599
    if-ne v15, v2, :cond_22

    .line 600
    .line 601
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 602
    .line 603
    const/4 v2, 0x3

    .line 604
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 605
    .line 606
    .line 607
    goto/16 :goto_a

    .line 608
    .line 609
    :cond_22
    invoke-virtual {v12}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 610
    .line 611
    .line 612
    move-result-object v2

    .line 613
    instance-of v15, v2, Ljava/net/UnknownHostException;

    .line 614
    .line 615
    if-eqz v15, :cond_23

    .line 616
    .line 617
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 618
    .line 619
    const/4 v15, 0x6

    .line 620
    invoke-direct {v10, v15, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 621
    .line 622
    .line 623
    move/from16 v20, v3

    .line 624
    .line 625
    move/from16 v18, v15

    .line 626
    .line 627
    const/16 v3, 0xd

    .line 628
    .line 629
    const/16 v16, 0x8

    .line 630
    .line 631
    const/16 v17, 0x7

    .line 632
    .line 633
    goto/16 :goto_c

    .line 634
    .line 635
    :cond_23
    const/4 v15, 0x6

    .line 636
    instance-of v2, v2, Ljava/net/SocketTimeoutException;

    .line 637
    .line 638
    if-eqz v2, :cond_24

    .line 639
    .line 640
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 641
    .line 642
    const/4 v2, 0x7

    .line 643
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 644
    .line 645
    .line 646
    :goto_f
    move/from16 v17, v2

    .line 647
    .line 648
    move/from16 v20, v3

    .line 649
    .line 650
    move/from16 v18, v15

    .line 651
    .line 652
    const/16 v3, 0xd

    .line 653
    .line 654
    const/16 v16, 0x8

    .line 655
    .line 656
    goto/16 :goto_c

    .line 657
    .line 658
    :cond_24
    const/4 v2, 0x7

    .line 659
    if-eqz v10, :cond_25

    .line 660
    .line 661
    check-cast v12, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;

    .line 662
    .line 663
    iget-byte v10, v12, Landroidx/media3/datasource/HttpDataSource$HttpDataSourceException;->type:B

    .line 664
    .line 665
    const/4 v12, 0x1

    .line 666
    if-ne v10, v12, :cond_25

    .line 667
    .line 668
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 669
    .line 670
    const/4 v12, 0x4

    .line 671
    invoke-direct {v10, v12, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 672
    .line 673
    .line 674
    goto :goto_f

    .line 675
    :cond_25
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 676
    .line 677
    const/16 v12, 0x8

    .line 678
    .line 679
    invoke-direct {v10, v12, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 680
    .line 681
    .line 682
    move/from16 v17, v2

    .line 683
    .line 684
    move/from16 v20, v3

    .line 685
    .line 686
    move/from16 v16, v12

    .line 687
    .line 688
    move/from16 v18, v15

    .line 689
    .line 690
    :goto_10
    const/16 v3, 0xd

    .line 691
    .line 692
    goto/16 :goto_c

    .line 693
    .line 694
    :goto_11
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 695
    .line 696
    if-eqz v15, :cond_26

    .line 697
    .line 698
    const/16 v15, 0xa

    .line 699
    .line 700
    goto :goto_12

    .line 701
    :cond_26
    const/16 v15, 0xb

    .line 702
    .line 703
    :goto_12
    invoke-direct {v10, v15, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 704
    .line 705
    .line 706
    move/from16 v17, v2

    .line 707
    .line 708
    move/from16 v20, v3

    .line 709
    .line 710
    move/from16 v16, v12

    .line 711
    .line 712
    goto :goto_10

    .line 713
    :cond_27
    const/4 v11, 0x0

    .line 714
    const/16 v15, 0x18

    .line 715
    .line 716
    const/16 v16, 0x8

    .line 717
    .line 718
    const/16 v17, 0x7

    .line 719
    .line 720
    const/16 v18, 0x6

    .line 721
    .line 722
    const/16 v19, 0x9

    .line 723
    .line 724
    const/16 v20, 0x5

    .line 725
    .line 726
    const/16 v24, 0x1c

    .line 727
    .line 728
    if-eqz v3, :cond_29

    .line 729
    .line 730
    if-eqz v10, :cond_28

    .line 731
    .line 732
    const/4 v15, 0x1

    .line 733
    if-ne v10, v15, :cond_29

    .line 734
    .line 735
    :cond_28
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 736
    .line 737
    const/16 v2, 0x23

    .line 738
    .line 739
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 740
    .line 741
    .line 742
    :goto_13
    const/16 v3, 0xd

    .line 743
    .line 744
    goto/16 :goto_16

    .line 745
    .line 746
    :cond_29
    if-eqz v3, :cond_2a

    .line 747
    .line 748
    const/4 v15, 0x3

    .line 749
    if-ne v10, v15, :cond_2a

    .line 750
    .line 751
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 752
    .line 753
    const/16 v2, 0xf

    .line 754
    .line 755
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 756
    .line 757
    .line 758
    goto :goto_13

    .line 759
    :cond_2a
    if-eqz v3, :cond_2b

    .line 760
    .line 761
    const/4 v3, 0x2

    .line 762
    if-ne v10, v3, :cond_2b

    .line 763
    .line 764
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 765
    .line 766
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 767
    .line 768
    .line 769
    goto :goto_13

    .line 770
    :cond_2b
    instance-of v2, v12, Landroidx/media3/exoplayer/mediacodec/MediaCodecRenderer$DecoderInitializationException;

    .line 771
    .line 772
    if-eqz v2, :cond_2c

    .line 773
    .line 774
    check-cast v12, Landroidx/media3/exoplayer/mediacodec/MediaCodecRenderer$DecoderInitializationException;

    .line 775
    .line 776
    iget-object v2, v12, Landroidx/media3/exoplayer/mediacodec/MediaCodecRenderer$DecoderInitializationException;->diagnosticInfo:Ljava/lang/String;

    .line 777
    .line 778
    invoke-static {v2}, Landroidx/media3/common/util/Util;->getErrorCodeFromPlatformDiagnosticsInfo(Ljava/lang/String;)I

    .line 779
    .line 780
    .line 781
    move-result v2

    .line 782
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 783
    .line 784
    const/16 v3, 0xd

    .line 785
    .line 786
    invoke-direct {v10, v3, v2}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 787
    .line 788
    .line 789
    goto/16 :goto_16

    .line 790
    .line 791
    :cond_2c
    const/16 v3, 0xd

    .line 792
    .line 793
    instance-of v2, v12, Landroidx/media3/exoplayer/mediacodec/MediaCodecDecoderException;

    .line 794
    .line 795
    const/16 v10, 0xe

    .line 796
    .line 797
    if-eqz v2, :cond_2d

    .line 798
    .line 799
    check-cast v12, Landroidx/media3/exoplayer/mediacodec/MediaCodecDecoderException;

    .line 800
    .line 801
    iget v2, v12, Landroidx/media3/exoplayer/mediacodec/MediaCodecDecoderException;->errorCode:I

    .line 802
    .line 803
    new-instance v11, Landroidx/compose/material3/FabPlacement;

    .line 804
    .line 805
    invoke-direct {v11, v10, v2}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 806
    .line 807
    .line 808
    :goto_14
    move-object v10, v11

    .line 809
    goto :goto_16

    .line 810
    :cond_2d
    instance-of v2, v12, Ljava/lang/OutOfMemoryError;

    .line 811
    .line 812
    if-eqz v2, :cond_2e

    .line 813
    .line 814
    new-instance v2, Landroidx/compose/material3/FabPlacement;

    .line 815
    .line 816
    const/4 v11, 0x0

    .line 817
    invoke-direct {v2, v10, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 818
    .line 819
    .line 820
    move-object v10, v2

    .line 821
    goto :goto_16

    .line 822
    :cond_2e
    const/4 v11, 0x0

    .line 823
    instance-of v2, v12, Landroidx/media3/exoplayer/audio/AudioSink$InitializationException;

    .line 824
    .line 825
    if-eqz v2, :cond_2f

    .line 826
    .line 827
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 828
    .line 829
    const/16 v2, 0x11

    .line 830
    .line 831
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 832
    .line 833
    .line 834
    goto :goto_16

    .line 835
    :cond_2f
    instance-of v2, v12, Landroidx/media3/exoplayer/audio/AudioSink$WriteException;

    .line 836
    .line 837
    if-eqz v2, :cond_30

    .line 838
    .line 839
    check-cast v12, Landroidx/media3/exoplayer/audio/AudioSink$WriteException;

    .line 840
    .line 841
    iget v2, v12, Landroidx/media3/exoplayer/audio/AudioSink$WriteException;->errorCode:I

    .line 842
    .line 843
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 844
    .line 845
    const/16 v11, 0x12

    .line 846
    .line 847
    invoke-direct {v10, v11, v2}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 848
    .line 849
    .line 850
    goto :goto_16

    .line 851
    :cond_30
    instance-of v2, v12, Landroid/media/MediaCodec$CryptoException;

    .line 852
    .line 853
    if-eqz v2, :cond_31

    .line 854
    .line 855
    check-cast v12, Landroid/media/MediaCodec$CryptoException;

    .line 856
    .line 857
    invoke-virtual {v12}, Landroid/media/MediaCodec$CryptoException;->getErrorCode()I

    .line 858
    .line 859
    .line 860
    move-result v2

    .line 861
    invoke-static {v2}, Landroidx/media3/common/util/Util;->getErrorCodeForMediaDrmErrorCode(I)I

    .line 862
    .line 863
    .line 864
    move-result v10

    .line 865
    packed-switch v10, :pswitch_data_1

    .line 866
    .line 867
    .line 868
    const/16 v10, 0x1b

    .line 869
    .line 870
    goto :goto_15

    .line 871
    :pswitch_4
    move/from16 v10, v22

    .line 872
    .line 873
    goto :goto_15

    .line 874
    :pswitch_5
    move/from16 v10, v21

    .line 875
    .line 876
    goto :goto_15

    .line 877
    :pswitch_6
    move/from16 v10, v24

    .line 878
    .line 879
    goto :goto_15

    .line 880
    :pswitch_7
    const/16 v10, 0x18

    .line 881
    .line 882
    :goto_15
    new-instance v11, Landroidx/compose/material3/FabPlacement;

    .line 883
    .line 884
    invoke-direct {v11, v10, v2}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 885
    .line 886
    .line 887
    goto :goto_14

    .line 888
    :cond_31
    new-instance v10, Landroidx/compose/material3/FabPlacement;

    .line 889
    .line 890
    const/16 v2, 0x16

    .line 891
    .line 892
    const/4 v11, 0x0

    .line 893
    invoke-direct {v10, v2, v11}, Landroidx/compose/material3/FabPlacement;-><init>(II)V

    .line 894
    .line 895
    .line 896
    :goto_16
    new-instance v2, Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 897
    .line 898
    invoke-direct {v2}, Landroid/media/metrics/PlaybackErrorEvent$Builder;-><init>()V

    .line 899
    .line 900
    .line 901
    sub-long v11, v4, v13

    .line 902
    .line 903
    invoke-virtual {v2, v11, v12}, Landroid/media/metrics/PlaybackErrorEvent$Builder;->setTimeSinceCreatedMillis(J)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 904
    .line 905
    .line 906
    move-result-object v2

    .line 907
    iget v11, v10, Landroidx/compose/material3/FabPlacement;->left:I

    .line 908
    .line 909
    invoke-virtual {v2, v11}, Landroid/media/metrics/PlaybackErrorEvent$Builder;->setErrorCode(I)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 910
    .line 911
    .line 912
    move-result-object v2

    .line 913
    iget v10, v10, Landroidx/compose/material3/FabPlacement;->height:I

    .line 914
    .line 915
    invoke-virtual {v2, v10}, Landroid/media/metrics/PlaybackErrorEvent$Builder;->setSubErrorCode(I)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 916
    .line 917
    .line 918
    move-result-object v2

    .line 919
    invoke-virtual {v2, v7}, Landroid/media/metrics/PlaybackErrorEvent$Builder;->setException(Ljava/lang/Exception;)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 920
    .line 921
    .line 922
    move-result-object v2

    .line 923
    invoke-virtual {v2}, Landroid/media/metrics/PlaybackErrorEvent$Builder;->build()Landroid/media/metrics/PlaybackErrorEvent;

    .line 924
    .line 925
    .line 926
    move-result-object v2

    .line 927
    new-instance v7, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 928
    .line 929
    const/16 v10, 0x10

    .line 930
    .line 931
    invoke-direct {v7, v0, v2, v10}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 932
    .line 933
    .line 934
    invoke-interface {v8, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 935
    .line 936
    .line 937
    const/4 v15, 0x1

    .line 938
    iput-boolean v15, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportedEventsForCurrentSession:Z

    .line 939
    .line 940
    const/4 v2, 0x0

    .line 941
    iput-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingPlayerError:Landroidx/media3/common/PlaybackException;

    .line 942
    .line 943
    goto/16 :goto_6

    .line 944
    .line 945
    :goto_17
    invoke-virtual {v1, v2}, Landroidx/core/provider/CallbackWrapper;->contains(I)Z

    .line 946
    .line 947
    .line 948
    move-result v7

    .line 949
    if-eqz v7, :cond_38

    .line 950
    .line 951
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getCurrentTracks()Landroidx/media3/common/Tracks;

    .line 952
    .line 953
    .line 954
    move-result-object v7

    .line 955
    invoke-virtual {v7, v2}, Landroidx/media3/common/Tracks;->isTypeSelected(I)Z

    .line 956
    .line 957
    .line 958
    move-result v10

    .line 959
    invoke-virtual {v7, v15}, Landroidx/media3/common/Tracks;->isTypeSelected(I)Z

    .line 960
    .line 961
    .line 962
    move-result v2

    .line 963
    const/4 v15, 0x3

    .line 964
    invoke-virtual {v7, v15}, Landroidx/media3/common/Tracks;->isTypeSelected(I)Z

    .line 965
    .line 966
    .line 967
    move-result v7

    .line 968
    if-nez v10, :cond_32

    .line 969
    .line 970
    if-nez v2, :cond_32

    .line 971
    .line 972
    if-eqz v7, :cond_38

    .line 973
    .line 974
    :cond_32
    if-nez v10, :cond_34

    .line 975
    .line 976
    iget-object v10, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentVideoFormat:Landroidx/media3/common/Format;

    .line 977
    .line 978
    const/4 v11, 0x0

    .line 979
    invoke-static {v10, v11}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 980
    .line 981
    .line 982
    move-result v10

    .line 983
    if-eqz v10, :cond_33

    .line 984
    .line 985
    goto :goto_18

    .line 986
    :cond_33
    iput-object v11, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentVideoFormat:Landroidx/media3/common/Format;

    .line 987
    .line 988
    const/4 v15, 0x1

    .line 989
    invoke-virtual {v0, v15, v4, v5, v11}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportTrackChangeEvent(IJLandroidx/media3/common/Format;)V

    .line 990
    .line 991
    .line 992
    goto :goto_18

    .line 993
    :cond_34
    const/4 v11, 0x0

    .line 994
    :goto_18
    if-nez v2, :cond_36

    .line 995
    .line 996
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentAudioFormat:Landroidx/media3/common/Format;

    .line 997
    .line 998
    invoke-static {v2, v11}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 999
    .line 1000
    .line 1001
    move-result v2

    .line 1002
    if-eqz v2, :cond_35

    .line 1003
    .line 1004
    goto :goto_19

    .line 1005
    :cond_35
    iput-object v11, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentAudioFormat:Landroidx/media3/common/Format;

    .line 1006
    .line 1007
    const/4 v12, 0x0

    .line 1008
    invoke-virtual {v0, v12, v4, v5, v11}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportTrackChangeEvent(IJLandroidx/media3/common/Format;)V

    .line 1009
    .line 1010
    .line 1011
    :cond_36
    :goto_19
    if-nez v7, :cond_38

    .line 1012
    .line 1013
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentTextFormat:Landroidx/media3/common/Format;

    .line 1014
    .line 1015
    invoke-static {v2, v11}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1016
    .line 1017
    .line 1018
    move-result v2

    .line 1019
    if-eqz v2, :cond_37

    .line 1020
    .line 1021
    goto :goto_1a

    .line 1022
    :cond_37
    iput-object v11, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentTextFormat:Landroidx/media3/common/Format;

    .line 1023
    .line 1024
    const/4 v2, 0x2

    .line 1025
    invoke-virtual {v0, v2, v4, v5, v11}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportTrackChangeEvent(IJLandroidx/media3/common/Format;)V

    .line 1026
    .line 1027
    .line 1028
    :cond_38
    :goto_1a
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingVideoFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1029
    .line 1030
    invoke-virtual {v0, v2}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->canReportPendingFormatUpdate(Landroidx/compose/ui/platform/WeakCache;)Z

    .line 1031
    .line 1032
    .line 1033
    move-result v2

    .line 1034
    if-eqz v2, :cond_3a

    .line 1035
    .line 1036
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingVideoFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1037
    .line 1038
    iget-object v2, v2, Landroidx/compose/ui/platform/WeakCache;->values:Ljava/lang/Object;

    .line 1039
    .line 1040
    check-cast v2, Landroidx/media3/common/Format;

    .line 1041
    .line 1042
    iget v7, v2, Landroidx/media3/common/Format;->height:I

    .line 1043
    .line 1044
    const/4 v10, -0x1

    .line 1045
    if-eq v7, v10, :cond_3a

    .line 1046
    .line 1047
    iget-object v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentVideoFormat:Landroidx/media3/common/Format;

    .line 1048
    .line 1049
    invoke-static {v7, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1050
    .line 1051
    .line 1052
    move-result v7

    .line 1053
    if-eqz v7, :cond_39

    .line 1054
    .line 1055
    :goto_1b
    const/4 v2, 0x0

    .line 1056
    goto :goto_1c

    .line 1057
    :cond_39
    iput-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentVideoFormat:Landroidx/media3/common/Format;

    .line 1058
    .line 1059
    const/4 v15, 0x1

    .line 1060
    invoke-virtual {v0, v15, v4, v5, v2}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportTrackChangeEvent(IJLandroidx/media3/common/Format;)V

    .line 1061
    .line 1062
    .line 1063
    goto :goto_1b

    .line 1064
    :goto_1c
    iput-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingVideoFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1065
    .line 1066
    :cond_3a
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingAudioFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1067
    .line 1068
    invoke-virtual {v0, v2}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->canReportPendingFormatUpdate(Landroidx/compose/ui/platform/WeakCache;)Z

    .line 1069
    .line 1070
    .line 1071
    move-result v2

    .line 1072
    if-eqz v2, :cond_3c

    .line 1073
    .line 1074
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingAudioFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1075
    .line 1076
    iget-object v2, v2, Landroidx/compose/ui/platform/WeakCache;->values:Ljava/lang/Object;

    .line 1077
    .line 1078
    check-cast v2, Landroidx/media3/common/Format;

    .line 1079
    .line 1080
    iget-object v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentAudioFormat:Landroidx/media3/common/Format;

    .line 1081
    .line 1082
    invoke-static {v7, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1083
    .line 1084
    .line 1085
    move-result v7

    .line 1086
    if-eqz v7, :cond_3b

    .line 1087
    .line 1088
    :goto_1d
    const/4 v2, 0x0

    .line 1089
    goto :goto_1e

    .line 1090
    :cond_3b
    iput-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentAudioFormat:Landroidx/media3/common/Format;

    .line 1091
    .line 1092
    const/4 v11, 0x0

    .line 1093
    invoke-virtual {v0, v11, v4, v5, v2}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportTrackChangeEvent(IJLandroidx/media3/common/Format;)V

    .line 1094
    .line 1095
    .line 1096
    goto :goto_1d

    .line 1097
    :goto_1e
    iput-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingAudioFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1098
    .line 1099
    :cond_3c
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingTextFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1100
    .line 1101
    invoke-virtual {v0, v2}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->canReportPendingFormatUpdate(Landroidx/compose/ui/platform/WeakCache;)Z

    .line 1102
    .line 1103
    .line 1104
    move-result v2

    .line 1105
    if-eqz v2, :cond_3e

    .line 1106
    .line 1107
    iget-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingTextFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1108
    .line 1109
    iget-object v2, v2, Landroidx/compose/ui/platform/WeakCache;->values:Ljava/lang/Object;

    .line 1110
    .line 1111
    check-cast v2, Landroidx/media3/common/Format;

    .line 1112
    .line 1113
    iget-object v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentTextFormat:Landroidx/media3/common/Format;

    .line 1114
    .line 1115
    invoke-static {v7, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1116
    .line 1117
    .line 1118
    move-result v7

    .line 1119
    if-eqz v7, :cond_3d

    .line 1120
    .line 1121
    :goto_1f
    const/4 v2, 0x0

    .line 1122
    goto :goto_20

    .line 1123
    :cond_3d
    iput-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentTextFormat:Landroidx/media3/common/Format;

    .line 1124
    .line 1125
    const/4 v7, 0x2

    .line 1126
    invoke-virtual {v0, v7, v4, v5, v2}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportTrackChangeEvent(IJLandroidx/media3/common/Format;)V

    .line 1127
    .line 1128
    .line 1129
    goto :goto_1f

    .line 1130
    :goto_20
    iput-object v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingTextFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 1131
    .line 1132
    :cond_3e
    invoke-static {v9}, Landroidx/media3/common/util/NetworkTypeObserver;->getInstance(Landroid/content/Context;)Landroidx/media3/common/util/NetworkTypeObserver;

    .line 1133
    .line 1134
    .line 1135
    move-result-object v2

    .line 1136
    invoke-virtual {v2}, Landroidx/media3/common/util/NetworkTypeObserver;->getNetworkType()I

    .line 1137
    .line 1138
    .line 1139
    move-result v2

    .line 1140
    packed-switch v2, :pswitch_data_2

    .line 1141
    .line 1142
    .line 1143
    :pswitch_8
    const/4 v15, 0x1

    .line 1144
    goto :goto_21

    .line 1145
    :pswitch_9
    move/from16 v15, v17

    .line 1146
    .line 1147
    goto :goto_21

    .line 1148
    :pswitch_a
    move/from16 v15, v16

    .line 1149
    .line 1150
    goto :goto_21

    .line 1151
    :pswitch_b
    const/4 v15, 0x3

    .line 1152
    goto :goto_21

    .line 1153
    :pswitch_c
    move/from16 v15, v18

    .line 1154
    .line 1155
    goto :goto_21

    .line 1156
    :pswitch_d
    move/from16 v15, v20

    .line 1157
    .line 1158
    goto :goto_21

    .line 1159
    :pswitch_e
    const/4 v15, 0x4

    .line 1160
    goto :goto_21

    .line 1161
    :pswitch_f
    const/4 v15, 0x2

    .line 1162
    goto :goto_21

    .line 1163
    :pswitch_10
    move/from16 v15, v19

    .line 1164
    .line 1165
    goto :goto_21

    .line 1166
    :pswitch_11
    const/4 v15, 0x0

    .line 1167
    :goto_21
    iget v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentNetworkType:I

    .line 1168
    .line 1169
    if-eq v15, v2, :cond_3f

    .line 1170
    .line 1171
    iput v15, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentNetworkType:I

    .line 1172
    .line 1173
    new-instance v2, Landroid/media/metrics/NetworkEvent$Builder;

    .line 1174
    .line 1175
    invoke-direct {v2}, Landroid/media/metrics/NetworkEvent$Builder;-><init>()V

    .line 1176
    .line 1177
    .line 1178
    invoke-virtual {v2, v15}, Landroid/media/metrics/NetworkEvent$Builder;->setNetworkType(I)Landroid/media/metrics/NetworkEvent$Builder;

    .line 1179
    .line 1180
    .line 1181
    move-result-object v2

    .line 1182
    sub-long v9, v4, v13

    .line 1183
    .line 1184
    invoke-virtual {v2, v9, v10}, Landroid/media/metrics/NetworkEvent$Builder;->setTimeSinceCreatedMillis(J)Landroid/media/metrics/NetworkEvent$Builder;

    .line 1185
    .line 1186
    .line 1187
    move-result-object v2

    .line 1188
    invoke-virtual {v2}, Landroid/media/metrics/NetworkEvent$Builder;->build()Landroid/media/metrics/NetworkEvent;

    .line 1189
    .line 1190
    .line 1191
    move-result-object v2

    .line 1192
    new-instance v7, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 1193
    .line 1194
    const/16 v9, 0xf

    .line 1195
    .line 1196
    invoke-direct {v7, v0, v2, v9}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1197
    .line 1198
    .line 1199
    invoke-interface {v8, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 1200
    .line 1201
    .line 1202
    :cond_3f
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getPlaybackState()I

    .line 1203
    .line 1204
    .line 1205
    move-result v2

    .line 1206
    const/4 v7, 0x2

    .line 1207
    const/4 v11, 0x0

    .line 1208
    if-eq v2, v7, :cond_40

    .line 1209
    .line 1210
    iput-boolean v11, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->isSeeking:Z

    .line 1211
    .line 1212
    :cond_40
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getPlayerError()Landroidx/media3/common/PlaybackException;

    .line 1213
    .line 1214
    .line 1215
    move-result-object v2

    .line 1216
    if-nez v2, :cond_41

    .line 1217
    .line 1218
    iput-boolean v11, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->hasFatalError:Z

    .line 1219
    .line 1220
    const/16 v2, 0xa

    .line 1221
    .line 1222
    goto :goto_22

    .line 1223
    :cond_41
    const/16 v2, 0xa

    .line 1224
    .line 1225
    invoke-virtual {v1, v2}, Landroidx/core/provider/CallbackWrapper;->contains(I)Z

    .line 1226
    .line 1227
    .line 1228
    move-result v7

    .line 1229
    if-eqz v7, :cond_42

    .line 1230
    .line 1231
    const/4 v15, 0x1

    .line 1232
    iput-boolean v15, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->hasFatalError:Z

    .line 1233
    .line 1234
    :cond_42
    :goto_22
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getPlaybackState()I

    .line 1235
    .line 1236
    .line 1237
    move-result v7

    .line 1238
    iget-boolean v9, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->isSeeking:Z

    .line 1239
    .line 1240
    if-eqz v9, :cond_43

    .line 1241
    .line 1242
    move/from16 v7, v20

    .line 1243
    .line 1244
    :goto_23
    const/4 v15, 0x1

    .line 1245
    goto/16 :goto_25

    .line 1246
    .line 1247
    :cond_43
    iget-boolean v9, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->hasFatalError:Z

    .line 1248
    .line 1249
    if-eqz v9, :cond_44

    .line 1250
    .line 1251
    move v7, v3

    .line 1252
    goto :goto_23

    .line 1253
    :cond_44
    const/4 v12, 0x4

    .line 1254
    if-ne v7, v12, :cond_45

    .line 1255
    .line 1256
    const/16 v7, 0xb

    .line 1257
    .line 1258
    goto :goto_23

    .line 1259
    :cond_45
    const/16 v3, 0xc

    .line 1260
    .line 1261
    const/4 v9, 0x2

    .line 1262
    if-ne v7, v9, :cond_4a

    .line 1263
    .line 1264
    iget v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentPlaybackState:I

    .line 1265
    .line 1266
    if-eqz v7, :cond_49

    .line 1267
    .line 1268
    if-eq v7, v9, :cond_49

    .line 1269
    .line 1270
    if-ne v7, v3, :cond_46

    .line 1271
    .line 1272
    goto :goto_24

    .line 1273
    :cond_46
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    .line 1274
    .line 1275
    .line 1276
    move-result v3

    .line 1277
    if-nez v3, :cond_47

    .line 1278
    .line 1279
    move/from16 v7, v17

    .line 1280
    .line 1281
    goto :goto_23

    .line 1282
    :cond_47
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getPlaybackSuppressionReason()I

    .line 1283
    .line 1284
    .line 1285
    move-result v3

    .line 1286
    if-eqz v3, :cond_48

    .line 1287
    .line 1288
    move v7, v2

    .line 1289
    goto :goto_23

    .line 1290
    :cond_48
    move/from16 v7, v18

    .line 1291
    .line 1292
    goto :goto_23

    .line 1293
    :cond_49
    :goto_24
    move v7, v9

    .line 1294
    goto :goto_23

    .line 1295
    :cond_4a
    const/4 v15, 0x3

    .line 1296
    if-ne v7, v15, :cond_4d

    .line 1297
    .line 1298
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    .line 1299
    .line 1300
    .line 1301
    move-result v2

    .line 1302
    if-nez v2, :cond_4b

    .line 1303
    .line 1304
    move v7, v12

    .line 1305
    goto :goto_23

    .line 1306
    :cond_4b
    invoke-interface/range {p1 .. p1}, Landroidx/media3/common/Player;->getPlaybackSuppressionReason()I

    .line 1307
    .line 1308
    .line 1309
    move-result v2

    .line 1310
    if-eqz v2, :cond_4c

    .line 1311
    .line 1312
    move/from16 v7, v19

    .line 1313
    .line 1314
    goto :goto_23

    .line 1315
    :cond_4c
    move v7, v15

    .line 1316
    goto :goto_23

    .line 1317
    :cond_4d
    const/4 v15, 0x1

    .line 1318
    if-ne v7, v15, :cond_4e

    .line 1319
    .line 1320
    iget v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentPlaybackState:I

    .line 1321
    .line 1322
    if-eqz v2, :cond_4e

    .line 1323
    .line 1324
    move v7, v3

    .line 1325
    goto :goto_25

    .line 1326
    :cond_4e
    iget v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentPlaybackState:I

    .line 1327
    .line 1328
    :goto_25
    iget v2, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentPlaybackState:I

    .line 1329
    .line 1330
    if-eq v2, v7, :cond_4f

    .line 1331
    .line 1332
    iput v7, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentPlaybackState:I

    .line 1333
    .line 1334
    iput-boolean v15, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportedEventsForCurrentSession:Z

    .line 1335
    .line 1336
    new-instance v2, Landroid/media/metrics/PlaybackStateEvent$Builder;

    .line 1337
    .line 1338
    invoke-direct {v2}, Landroid/media/metrics/PlaybackStateEvent$Builder;-><init>()V

    .line 1339
    .line 1340
    .line 1341
    iget v3, v0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->currentPlaybackState:I

    .line 1342
    .line 1343
    invoke-virtual {v2, v3}, Landroid/media/metrics/PlaybackStateEvent$Builder;->setState(I)Landroid/media/metrics/PlaybackStateEvent$Builder;

    .line 1344
    .line 1345
    .line 1346
    move-result-object v2

    .line 1347
    sub-long/2addr v4, v13

    .line 1348
    invoke-virtual {v2, v4, v5}, Landroid/media/metrics/PlaybackStateEvent$Builder;->setTimeSinceCreatedMillis(J)Landroid/media/metrics/PlaybackStateEvent$Builder;

    .line 1349
    .line 1350
    .line 1351
    move-result-object v2

    .line 1352
    invoke-virtual {v2}, Landroid/media/metrics/PlaybackStateEvent$Builder;->build()Landroid/media/metrics/PlaybackStateEvent;

    .line 1353
    .line 1354
    .line 1355
    move-result-object v2

    .line 1356
    new-instance v3, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 1357
    .line 1358
    const/16 v11, 0x12

    .line 1359
    .line 1360
    invoke-direct {v3, v0, v2, v11}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1361
    .line 1362
    .line 1363
    invoke-interface {v8, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 1364
    .line 1365
    .line 1366
    :cond_4f
    const/16 v0, 0x404

    .line 1367
    .line 1368
    invoke-virtual {v1, v0}, Landroidx/core/provider/CallbackWrapper;->contains(I)Z

    .line 1369
    .line 1370
    .line 1371
    move-result v2

    .line 1372
    if-eqz v2, :cond_50

    .line 1373
    .line 1374
    invoke-virtual {v1, v0}, Landroidx/core/provider/CallbackWrapper;->getEventTime(I)Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;

    .line 1375
    .line 1376
    .line 1377
    move-result-object v0

    .line 1378
    invoke-virtual {v6, v0}, Landroidx/media3/exoplayer/analytics/DefaultPlaybackSessionManager;->finishAllSessions(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;)V

    .line 1379
    .line 1380
    .line 1381
    :cond_50
    :goto_26
    return-void

    .line 1382
    nop

    .line 1383
    :pswitch_data_0
    .packed-switch 0x1772
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    :pswitch_data_1
    .packed-switch 0x1772
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch

    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_8
        :pswitch_b
        :pswitch_8
        :pswitch_a
        :pswitch_9
    .end packed-switch
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
    .line 2190
    .line 2191
    .line 2192
    .line 2193
    .line 2194
    .line 2195
    .line 2196
    .line 2197
    .line 2198
    .line 2199
    .line 2200
    .line 2201
    .line 2202
    .line 2203
    .line 2204
    .line 2205
    .line 2206
    .line 2207
    .line 2208
    .line 2209
    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    .line 2224
    .line 2225
    .line 2226
    .line 2227
    .line 2228
    .line 2229
    .line 2230
    .line 2231
    .line 2232
    .line 2233
    .line 2234
    .line 2235
    .line 2236
    .line 2237
    .line 2238
    .line 2239
    .line 2240
    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    .line 2246
    .line 2247
    .line 2248
    .line 2249
    .line 2250
    .line 2251
    .line 2252
    .line 2253
    .line 2254
    .line 2255
    .line 2256
    .line 2257
    .line 2258
    .line 2259
    .line 2260
    .line 2261
    .line 2262
    .line 2263
    .line 2264
    .line 2265
    .line 2266
    .line 2267
    .line 2268
    .line 2269
    .line 2270
    .line 2271
    .line 2272
    .line 2273
    .line 2274
    .line 2275
    .line 2276
    .line 2277
    .line 2278
    .line 2279
    .line 2280
    .line 2281
    .line 2282
    .line 2283
    .line 2284
    .line 2285
    .line 2286
    .line 2287
    .line 2288
    .line 2289
    .line 2290
    .line 2291
    .line 2292
    .line 2293
    .line 2294
    .line 2295
    .line 2296
    .line 2297
    .line 2298
    .line 2299
    .line 2300
    .line 2301
    .line 2302
    .line 2303
    .line 2304
    .line 2305
    .line 2306
    .line 2307
    .line 2308
    .line 2309
    .line 2310
    .line 2311
    .line 2312
    .line 2313
    .line 2314
    .line 2315
    .line 2316
    .line 2317
    .line 2318
    .line 2319
    .line 2320
    .line 2321
    .line 2322
    .line 2323
    .line 2324
    .line 2325
    .line 2326
    .line 2327
    .line 2328
    .line 2329
    .line 2330
    .line 2331
    .line 2332
    .line 2333
    .line 2334
    .line 2335
    .line 2336
    .line 2337
    .line 2338
    .line 2339
    .line 2340
    .line 2341
    .line 2342
    .line 2343
    .line 2344
    .line 2345
    .line 2346
    .line 2347
    .line 2348
    .line 2349
    .line 2350
    .line 2351
    .line 2352
    .line 2353
    .line 2354
    .line 2355
    .line 2356
    .line 2357
    .line 2358
    .line 2359
    .line 2360
    .line 2361
    .line 2362
    .line 2363
    .line 2364
    .line 2365
    .line 2366
    .line 2367
    .line 2368
    .line 2369
    .line 2370
    .line 2371
    .line 2372
    .line 2373
    .line 2374
    .line 2375
    .line 2376
    .line 2377
    .line 2378
    .line 2379
    .line 2380
    .line 2381
    .line 2382
    .line 2383
    .line 2384
    .line 2385
    .line 2386
    .line 2387
    .line 2388
    .line 2389
    .line 2390
    .line 2391
    .line 2392
    .line 2393
    .line 2394
    .line 2395
    .line 2396
    .line 2397
    .line 2398
    .line 2399
    .line 2400
    .line 2401
    .line 2402
    .line 2403
    .line 2404
    .line 2405
    .line 2406
    .line 2407
    .line 2408
    .line 2409
    .line 2410
    .line 2411
    .line 2412
    .line 2413
    .line 2414
    .line 2415
    .line 2416
    .line 2417
    .line 2418
    .line 2419
    .line 2420
    .line 2421
    .line 2422
    .line 2423
    .line 2424
    .line 2425
    .line 2426
    .line 2427
    .line 2428
    .line 2429
    .line 2430
    .line 2431
    .line 2432
    .line 2433
    .line 2434
    .line 2435
    .line 2436
    .line 2437
    .line 2438
    .line 2439
    .line 2440
    .line 2441
    .line 2442
    .line 2443
    .line 2444
    .line 2445
    .line 2446
    .line 2447
    .line 2448
    .line 2449
    .line 2450
    .line 2451
    .line 2452
    .line 2453
    .line 2454
    .line 2455
    .line 2456
    .line 2457
    .line 2458
    .line 2459
    .line 2460
    .line 2461
    .line 2462
    .line 2463
    .line 2464
    .line 2465
    .line 2466
    .line 2467
    .line 2468
    .line 2469
    .line 2470
    .line 2471
    .line 2472
    .line 2473
    .line 2474
    .line 2475
    .line 2476
    .line 2477
    .line 2478
    .line 2479
    .line 2480
    .line 2481
    .line 2482
    .line 2483
    .line 2484
    .line 2485
    .line 2486
    .line 2487
    .line 2488
    .line 2489
    .line 2490
    .line 2491
    .line 2492
    .line 2493
    .line 2494
    .line 2495
    .line 2496
    .line 2497
    .line 2498
    .line 2499
    .line 2500
    .line 2501
    .line 2502
    .line 2503
    .line 2504
    .line 2505
    .line 2506
    .line 2507
    .line 2508
    .line 2509
    .line 2510
    .line 2511
    .line 2512
    .line 2513
    .line 2514
    .line 2515
    .line 2516
    .line 2517
    .line 2518
    .line 2519
    .line 2520
    .line 2521
    .line 2522
    .line 2523
    .line 2524
    .line 2525
    .line 2526
    .line 2527
    .line 2528
    .line 2529
    .line 2530
    .line 2531
    .line 2532
    .line 2533
    .line 2534
    .line 2535
    .line 2536
    .line 2537
    .line 2538
    .line 2539
    .line 2540
    .line 2541
    .line 2542
    .line 2543
    .line 2544
    .line 2545
    .line 2546
    .line 2547
    .line 2548
    .line 2549
    .line 2550
    .line 2551
    .line 2552
    .line 2553
    .line 2554
    .line 2555
    .line 2556
    .line 2557
    .line 2558
    .line 2559
    .line 2560
    .line 2561
    .line 2562
    .line 2563
    .line 2564
    .line 2565
    .line 2566
    .line 2567
    .line 2568
    .line 2569
    .line 2570
    .line 2571
    .line 2572
    .line 2573
    .line 2574
    .line 2575
    .line 2576
    .line 2577
    .line 2578
    .line 2579
    .line 2580
    .line 2581
    .line 2582
    .line 2583
    .line 2584
    .line 2585
    .line 2586
    .line 2587
    .line 2588
    .line 2589
    .line 2590
    .line 2591
    .line 2592
    .line 2593
    .line 2594
    .line 2595
    .line 2596
    .line 2597
    .line 2598
    .line 2599
    .line 2600
    .line 2601
    .line 2602
    .line 2603
    .line 2604
    .line 2605
    .line 2606
    .line 2607
    .line 2608
    .line 2609
    .line 2610
    .line 2611
    .line 2612
    .line 2613
    .line 2614
    .line 2615
    .line 2616
    .line 2617
    .line 2618
    .line 2619
    .line 2620
    .line 2621
    .line 2622
    .line 2623
    .line 2624
    .line 2625
    .line 2626
    .line 2627
    .line 2628
    .line 2629
    .line 2630
    .line 2631
    .line 2632
    .line 2633
    .line 2634
    .line 2635
    .line 2636
    .line 2637
    .line 2638
    .line 2639
    .line 2640
    .line 2641
    .line 2642
    .line 2643
    .line 2644
    .line 2645
    .line 2646
    .line 2647
    .line 2648
    .line 2649
    .line 2650
    .line 2651
    .line 2652
    .line 2653
    .line 2654
    .line 2655
    .line 2656
    .line 2657
    .line 2658
    .line 2659
    .line 2660
    .line 2661
    .line 2662
    .line 2663
    .line 2664
    .line 2665
    .line 2666
    .line 2667
    .line 2668
    .line 2669
    .line 2670
    .line 2671
    .line 2672
    .line 2673
    .line 2674
    .line 2675
    .line 2676
    .line 2677
    .line 2678
    .line 2679
    .line 2680
    .line 2681
    .line 2682
    .line 2683
    .line 2684
    .line 2685
    .line 2686
    .line 2687
    .line 2688
    .line 2689
    .line 2690
    .line 2691
    .line 2692
    .line 2693
    .line 2694
    .line 2695
    .line 2696
    .line 2697
    .line 2698
    .line 2699
    .line 2700
    .line 2701
    .line 2702
    .line 2703
    .line 2704
    .line 2705
    .line 2706
    .line 2707
    .line 2708
    .line 2709
    .line 2710
    .line 2711
    .line 2712
    .line 2713
    .line 2714
    .line 2715
    .line 2716
    .line 2717
    .line 2718
    .line 2719
    .line 2720
    .line 2721
    .line 2722
    .line 2723
    .line 2724
    .line 2725
    .line 2726
    .line 2727
    .line 2728
    .line 2729
    .line 2730
    .line 2731
    .line 2732
    .line 2733
    .line 2734
    .line 2735
    .line 2736
    .line 2737
    .line 2738
    .line 2739
    .line 2740
    .line 2741
    .line 2742
    .line 2743
    .line 2744
    .line 2745
    .line 2746
    .line 2747
    .line 2748
    .line 2749
    .line 2750
    .line 2751
    .line 2752
    .line 2753
    .line 2754
    .line 2755
    .line 2756
    .line 2757
    .line 2758
    .line 2759
    .line 2760
    .line 2761
    .line 2762
    .line 2763
    .line 2764
    .line 2765
    .line 2766
    .line 2767
    .line 2768
    .line 2769
    .line 2770
    .line 2771
    .line 2772
    .line 2773
    .line 2774
    .line 2775
    .line 2776
    .line 2777
    .line 2778
    .line 2779
    .line 2780
    .line 2781
    .line 2782
    .line 2783
    .line 2784
    .line 2785
    .line 2786
    .line 2787
    .line 2788
    .line 2789
    .line 2790
    .line 2791
    .line 2792
    .line 2793
    .line 2794
    .line 2795
    .line 2796
    .line 2797
    .line 2798
    .line 2799
    .line 2800
    .line 2801
    .line 2802
    .line 2803
    .line 2804
    .line 2805
    .line 2806
    .line 2807
    .line 2808
    .line 2809
    .line 2810
    .line 2811
    .line 2812
    .line 2813
    .line 2814
.end method

.method public final onLoadError(Landroidx/compose/animation/core/FloatTweenSpec;Ljava/io/IOException;)V
    .locals 0

    .line 1
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->ioErrorType:Z

    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
.end method

.method public final onPlayerError(Landroidx/media3/common/PlaybackException;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingPlayerError:Landroidx/media3/common/PlaybackException;

    .line 2
    .line 3
    return-void
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final onPositionDiscontinuity(Landroidx/media3/common/Player$PositionInfo;I)V
    .locals 0

    .line 1
    const/4 p1, 0x1

    .line 2
    if-ne p2, p1, :cond_0

    .line 3
    .line 4
    iput-boolean p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->isSeeking:Z

    .line 5
    .line 6
    :cond_0
    iput p2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->discontinuityReason:I

    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
.end method

.method public final onSessionActive(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p1, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->mediaPeriodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;->isAd()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    invoke-virtual {p0}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->finishCurrentSession()V

    .line 13
    .line 14
    .line 15
    iput-object p2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->activeSessionId:Ljava/lang/String;

    .line 16
    .line 17
    new-instance p2, Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 18
    .line 19
    invoke-direct {p2}, Landroid/media/metrics/PlaybackMetrics$Builder;-><init>()V

    .line 20
    .line 21
    .line 22
    const-string v1, "AndroidXMedia3"

    .line 23
    .line 24
    invoke-virtual {p2, v1}, Landroid/media/metrics/PlaybackMetrics$Builder;->setPlayerName(Ljava/lang/String;)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    const-string v1, "1.10.1"

    .line 29
    .line 30
    invoke-virtual {p2, v1}, Landroid/media/metrics/PlaybackMetrics$Builder;->setPlayerVersion(Ljava/lang/String;)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 31
    .line 32
    .line 33
    move-result-object p2

    .line 34
    iput-object p2, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->metricsBuilder:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 35
    .line 36
    iget-object p1, p1, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->timeline:Landroidx/media3/common/Timeline;

    .line 37
    .line 38
    invoke-virtual {p0, p1, v0}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->maybeUpdateTimelineMetadata(Landroidx/media3/common/Timeline;Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;)V

    .line 39
    .line 40
    .line 41
    return-void
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
.end method

.method public final onSessionCreated(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
.end method

.method public final onSessionFinished(Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;Ljava/lang/String;Z)V
    .locals 0

    .line 1
    iget-object p1, p1, Landroidx/media3/exoplayer/analytics/AnalyticsListener$EventTime;->mediaPeriodId:Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, Landroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;->isAd()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-nez p1, :cond_2

    .line 10
    .line 11
    :cond_0
    iget-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->activeSessionId:Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-nez p1, :cond_1

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_1
    invoke-virtual {p0}, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->finishCurrentSession()V

    .line 21
    .line 22
    .line 23
    :cond_2
    :goto_0
    iget-object p1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthTimeMs:Ljava/util/HashMap;

    .line 24
    .line 25
    invoke-virtual {p1, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->bandwidthBytes:Ljava/util/HashMap;

    .line 29
    .line 30
    invoke-virtual {p0, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    return-void
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
.end method

.method public final onVideoDisabled(Landroidx/media3/exoplayer/DecoderCounters;)V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->droppedFrames:I

    .line 2
    .line 3
    iget v1, p1, Landroidx/media3/exoplayer/DecoderCounters;->droppedBufferCount:I

    .line 4
    .line 5
    add-int/2addr v0, v1

    .line 6
    iput v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->droppedFrames:I

    .line 7
    .line 8
    iget v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playedFrames:I

    .line 9
    .line 10
    iget p1, p1, Landroidx/media3/exoplayer/DecoderCounters;->renderedOutputBufferCount:I

    .line 11
    .line 12
    add-int/2addr v0, p1

    .line 13
    iput v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->playedFrames:I

    .line 14
    .line 15
    return-void
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method

.method public final onVideoSizeChanged(Landroidx/media3/common/VideoSize;)V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingVideoFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/compose/ui/platform/WeakCache;->values:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Landroidx/media3/common/Format;

    .line 8
    .line 9
    iget v2, v1, Landroidx/media3/common/Format;->height:I

    .line 10
    .line 11
    const/4 v3, -0x1

    .line 12
    if-ne v2, v3, :cond_0

    .line 13
    .line 14
    invoke-virtual {v1}, Landroidx/media3/common/Format;->buildUpon()Landroidx/media3/common/Format$Builder;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iget v2, p1, Landroidx/media3/common/VideoSize;->width:I

    .line 19
    .line 20
    iput v2, v1, Landroidx/media3/common/Format$Builder;->width:I

    .line 21
    .line 22
    iget p1, p1, Landroidx/media3/common/VideoSize;->height:I

    .line 23
    .line 24
    iput p1, v1, Landroidx/media3/common/Format$Builder;->height:I

    .line 25
    .line 26
    new-instance p1, Landroidx/media3/common/Format;

    .line 27
    .line 28
    invoke-direct {p1, v1}, Landroidx/media3/common/Format;-><init>(Landroidx/media3/common/Format$Builder;)V

    .line 29
    .line 30
    .line 31
    new-instance v1, Landroidx/compose/ui/platform/WeakCache;

    .line 32
    .line 33
    iget-object v0, v0, Landroidx/compose/ui/platform/WeakCache;->referenceQueue:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v0, Ljava/lang/String;

    .line 36
    .line 37
    const/16 v2, 0x17

    .line 38
    .line 39
    invoke-direct {v1, p1, v0, v2}, Landroidx/compose/ui/platform/WeakCache;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 40
    .line 41
    .line 42
    iput-object v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->pendingVideoFormat:Landroidx/compose/ui/platform/WeakCache;

    .line 43
    .line 44
    :cond_0
    return-void
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
.end method

.method public final reportTrackChangeEvent(IJLandroidx/media3/common/Format;)V
    .locals 4

    .line 1
    new-instance v0, Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Landroid/media/metrics/TrackChangeEvent$Builder;-><init>(I)V

    .line 4
    .line 5
    .line 6
    iget-wide v1, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->startTimeMs:J

    .line 7
    .line 8
    sub-long/2addr p2, v1

    .line 9
    invoke-virtual {v0, p2, p3}, Landroid/media/metrics/TrackChangeEvent$Builder;->setTimeSinceCreatedMillis(J)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    const/4 p2, 0x0

    .line 14
    const/4 p3, 0x1

    .line 15
    if-eqz p4, :cond_a

    .line 16
    .line 17
    invoke-virtual {p1, p3}, Landroid/media/metrics/TrackChangeEvent$Builder;->setTrackState(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    invoke-virtual {p1, v0}, Landroid/media/metrics/TrackChangeEvent$Builder;->setTrackChangeReason(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 22
    .line 23
    .line 24
    iget-object v1, p4, Landroidx/media3/common/Format;->containerMimeType:Ljava/lang/String;

    .line 25
    .line 26
    if-eqz v1, :cond_0

    .line 27
    .line 28
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setContainerMimeType(Ljava/lang/String;)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 29
    .line 30
    .line 31
    :cond_0
    iget-object v1, p4, Landroidx/media3/common/Format;->sampleMimeType:Ljava/lang/String;

    .line 32
    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setSampleMimeType(Ljava/lang/String;)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 36
    .line 37
    .line 38
    :cond_1
    iget-object v1, p4, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    .line 39
    .line 40
    if-eqz v1, :cond_2

    .line 41
    .line 42
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setCodecName(Ljava/lang/String;)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 43
    .line 44
    .line 45
    :cond_2
    iget v1, p4, Landroidx/media3/common/Format;->bitrate:I

    .line 46
    .line 47
    const/4 v2, -0x1

    .line 48
    if-eq v1, v2, :cond_3

    .line 49
    .line 50
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setBitrate(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 51
    .line 52
    .line 53
    :cond_3
    iget v1, p4, Landroidx/media3/common/Format;->width:I

    .line 54
    .line 55
    if-eq v1, v2, :cond_4

    .line 56
    .line 57
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setWidth(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 58
    .line 59
    .line 60
    :cond_4
    iget v1, p4, Landroidx/media3/common/Format;->height:I

    .line 61
    .line 62
    if-eq v1, v2, :cond_5

    .line 63
    .line 64
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setHeight(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 65
    .line 66
    .line 67
    :cond_5
    iget v1, p4, Landroidx/media3/common/Format;->channelCount:I

    .line 68
    .line 69
    if-eq v1, v2, :cond_6

    .line 70
    .line 71
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setChannelCount(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 72
    .line 73
    .line 74
    :cond_6
    iget v1, p4, Landroidx/media3/common/Format;->sampleRate:I

    .line 75
    .line 76
    if-eq v1, v2, :cond_7

    .line 77
    .line 78
    invoke-virtual {p1, v1}, Landroid/media/metrics/TrackChangeEvent$Builder;->setAudioSampleRate(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 79
    .line 80
    .line 81
    :cond_7
    iget-object v1, p4, Landroidx/media3/common/Format;->language:Ljava/lang/String;

    .line 82
    .line 83
    if-eqz v1, :cond_9

    .line 84
    .line 85
    sget-object v3, Landroidx/media3/common/util/Util;->DEVICE_DEBUG_INFO:Ljava/lang/String;

    .line 86
    .line 87
    const-string v3, "-"

    .line 88
    .line 89
    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    aget-object p2, v1, p2

    .line 94
    .line 95
    array-length v2, v1

    .line 96
    if-lt v2, v0, :cond_8

    .line 97
    .line 98
    aget-object v0, v1, p3

    .line 99
    .line 100
    goto :goto_0

    .line 101
    :cond_8
    const/4 v0, 0x0

    .line 102
    :goto_0
    invoke-static {p2, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    iget-object v0, p2, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast v0, Ljava/lang/String;

    .line 109
    .line 110
    invoke-virtual {p1, v0}, Landroid/media/metrics/TrackChangeEvent$Builder;->setLanguage(Ljava/lang/String;)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 111
    .line 112
    .line 113
    iget-object p2, p2, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 114
    .line 115
    if-eqz p2, :cond_9

    .line 116
    .line 117
    check-cast p2, Ljava/lang/String;

    .line 118
    .line 119
    invoke-virtual {p1, p2}, Landroid/media/metrics/TrackChangeEvent$Builder;->setLanguageRegion(Ljava/lang/String;)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 120
    .line 121
    .line 122
    :cond_9
    iget p2, p4, Landroidx/media3/common/Format;->frameRate:F

    .line 123
    .line 124
    const/high16 p4, -0x40800000    # -1.0f

    .line 125
    .line 126
    cmpl-float p4, p2, p4

    .line 127
    .line 128
    if-eqz p4, :cond_b

    .line 129
    .line 130
    invoke-virtual {p1, p2}, Landroid/media/metrics/TrackChangeEvent$Builder;->setVideoFrameRate(F)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 131
    .line 132
    .line 133
    goto :goto_1

    .line 134
    :cond_a
    invoke-virtual {p1, p2}, Landroid/media/metrics/TrackChangeEvent$Builder;->setTrackState(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 135
    .line 136
    .line 137
    :cond_b
    :goto_1
    iput-boolean p3, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->reportedEventsForCurrentSession:Z

    .line 138
    .line 139
    invoke-virtual {p1}, Landroid/media/metrics/TrackChangeEvent$Builder;->build()Landroid/media/metrics/TrackChangeEvent;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    new-instance p2, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 144
    .line 145
    const/16 p3, 0xe

    .line 146
    .line 147
    invoke-direct {p2, p0, p1, p3}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 148
    .line 149
    .line 150
    iget-object p0, p0, Landroidx/media3/exoplayer/analytics/MediaMetricsListener;->backgroundExecutor:Ljava/util/concurrent/Executor;

    .line 151
    .line 152
    invoke-interface {p0, p2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 153
    .line 154
    .line 155
    return-void
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
.end method
