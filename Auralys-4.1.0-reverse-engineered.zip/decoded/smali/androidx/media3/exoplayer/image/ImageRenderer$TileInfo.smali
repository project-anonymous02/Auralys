.class public final Landroidx/media3/exoplayer/image/ImageRenderer$TileInfo;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public presentationTimeUs:J

.field public tileBitmap:Ljava/lang/Object;

.field public tileIndex:I
