.class public final Landroidx/media3/exoplayer/audio/AudioOutputProvider$OutputConfig$Builder;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public audioAttributes:Landroidx/media3/common/AudioAttributes;

.field public audioSessionId:I

.field public bufferSize:I

.field public channelMask:I

.field public encoding:I

.field public isOffload:Z

.field public isTunneling:Z

.field public sampleRate:I

.field public useOffloadGapless:Z

.field public usePlaybackParameters:Z

.field public virtualDeviceId:I
