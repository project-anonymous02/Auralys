.class public final Landroidx/media3/exoplayer/audio/AudioOutputProvider$FormatSupport;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public isFormatSupportedForOffload:Z

.field public isGaplessSupportedForOffload:Z

.field public isSpeedChangeSupportedForOffload:Z

.field public supportLevel:I
