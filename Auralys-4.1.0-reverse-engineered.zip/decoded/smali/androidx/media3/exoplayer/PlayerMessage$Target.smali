.class public interface abstract Landroidx/media3/exoplayer/PlayerMessage$Target;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# virtual methods
.method public abstract handleMessage(ILjava/lang/Object;)V
.end method
