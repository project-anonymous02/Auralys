.class public interface abstract Landroidx/media3/exoplayer/mediacodec/MediaCodecBufferEnqueuer;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# virtual methods
.method public abstract flush()V
.end method

.method public abstract maybeThrowException()V
.end method

.method public abstract queueInputBuffer(IIIJ)V
.end method

.method public abstract queueSecureInputBuffer(ILandroidx/media3/decoder/CryptoInfo;JI)V
.end method

.method public abstract setParameters(Landroid/os/Bundle;)V
.end method

.method public abstract shutdown()V
.end method

.method public abstract start()V
.end method
