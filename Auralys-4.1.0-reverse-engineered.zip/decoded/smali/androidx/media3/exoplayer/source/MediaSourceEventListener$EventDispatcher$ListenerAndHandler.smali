.class public final Landroidx/media3/exoplayer/source/MediaSourceEventListener$EventDispatcher$ListenerAndHandler;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public handler:Landroid/os/Handler;

.field public listener:Landroidx/media3/exoplayer/source/MediaSourceEventListener;
