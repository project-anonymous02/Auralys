.class public interface abstract Landroidx/media3/exoplayer/source/MediaSourceEventListener;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# virtual methods
.method public abstract onDownstreamFormatChanged(ILandroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;Landroidx/compose/animation/core/FloatTweenSpec;)V
.end method

.method public abstract onLoadCanceled(ILandroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/compose/animation/core/FloatTweenSpec;)V
.end method

.method public abstract onLoadCompleted(ILandroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/compose/animation/core/FloatTweenSpec;)V
.end method

.method public abstract onLoadError(ILandroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/compose/animation/core/FloatTweenSpec;Ljava/io/IOException;Z)V
.end method

.method public abstract onLoadStarted(ILandroidx/media3/exoplayer/source/MediaSource$MediaPeriodId;Landroidx/media3/exoplayer/source/LoadEventInfo;Landroidx/compose/animation/core/FloatTweenSpec;I)V
.end method
