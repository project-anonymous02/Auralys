.class public final Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"

# interfaces
.implements Landroidx/media3/exoplayer/source/MediaSource$Factory;


# static fields
.field public static final synthetic $r8$clinit:I


# instance fields
.field public final dataSourceFactory:Landroidx/media3/datasource/DataSource$Factory;

.field public final delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

.field public final liveMaxOffsetMs:J

.field public final liveMaxSpeed:F

.field public final liveMinOffsetMs:J

.field public final liveMinSpeed:F

.field public final liveTargetOffsetMs:J

.field public parseSubtitlesDuringExtraction:Z

.field public subtitleParserFactory:Landroidx/media3/extractor/text/CueDecoder;


# direct methods
.method public constructor <init>(Landroidx/media3/datasource/DataSource$Factory;Landroidx/media3/extractor/ExtractorsFactory;)V
    .locals 2

    .line 1
    new-instance v0, Landroidx/media3/extractor/text/CueDecoder;

    .line 2
    .line 3
    const/16 v1, 0xf

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroidx/media3/extractor/text/CueDecoder;-><init>(B)V

    .line 6
    .line 7
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->dataSourceFactory:Landroidx/media3/datasource/DataSource$Factory;

    .line 12
    .line 13
    iput-object v0, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->subtitleParserFactory:Landroidx/media3/extractor/text/CueDecoder;

    .line 14
    .line 15
    new-instance v1, Lcoil3/ImageLoader$Builder;

    .line 16
    .line 17
    invoke-direct {v1, p2, v0}, Lcoil3/ImageLoader$Builder;-><init>(Landroidx/media3/extractor/ExtractorsFactory;Landroidx/media3/extractor/text/CueDecoder;)V

    .line 18
    .line 19
    .line 20
    iput-object v1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

    .line 21
    .line 22
    iget-object p2, v1, Lcoil3/ImageLoader$Builder;->diskCacheLazy:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast p2, Landroidx/media3/datasource/DataSource$Factory;

    .line 25
    .line 26
    if-eq p1, p2, :cond_0

    .line 27
    .line 28
    iput-object p1, v1, Lcoil3/ImageLoader$Builder;->diskCacheLazy:Ljava/lang/Object;

    .line 29
    .line 30
    iget-object p1, v1, Lcoil3/ImageLoader$Builder;->defaults:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p1, Ljava/util/HashMap;

    .line 33
    .line 34
    invoke-virtual {p1}, Ljava/util/HashMap;->clear()V

    .line 35
    .line 36
    .line 37
    iget-object p1, v1, Lcoil3/ImageLoader$Builder;->memoryCacheLazy:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast p1, Ljava/util/HashMap;

    .line 40
    .line 41
    invoke-virtual {p1}, Ljava/util/HashMap;->clear()V

    .line 42
    .line 43
    .line 44
    :cond_0
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    iput-wide p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveTargetOffsetMs:J

    .line 50
    .line 51
    iput-wide p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMinOffsetMs:J

    .line 52
    .line 53
    iput-wide p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMaxOffsetMs:J

    .line 54
    .line 55
    const p1, -0x800001

    .line 56
    .line 57
    .line 58
    iput p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMinSpeed:F

    .line 59
    .line 60
    iput p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMaxSpeed:F

    .line 61
    .line 62
    const/4 p1, 0x1

    .line 63
    iput-boolean p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->parseSubtitlesDuringExtraction:Z

    .line 64
    .line 65
    return-void
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
.end method

.method public static newInstance(Ljava/lang/Class;Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/exoplayer/source/MediaSource$Factory;
    .locals 1

    .line 1
    :try_start_0
    const-class v0, Landroidx/media3/datasource/DataSource$Factory;

    .line 2
    .line 3
    filled-new-array {v0}, [Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {p0, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p0, p1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    check-cast p0, Landroidx/media3/exoplayer/source/MediaSource$Factory;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 20
    .line 21
    return-object p0

    .line 22
    :catch_0
    move-exception p0

    .line 23
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 24
    .line 25
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 26
    .line 27
    .line 28
    throw p1
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
.end method


# virtual methods
.method public final createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/source/BaseMediaSource;
    .locals 11

    .line 1
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 7
    .line 8
    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    const-string/jumbo v2, "ssai"

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    throw v1

    .line 28
    :cond_1
    :goto_0
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 29
    .line 30
    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->mimeType:Ljava/lang/String;

    .line 31
    .line 32
    const-string v2, "application/x-image-uri"

    .line 33
    .line 34
    invoke-static {v0, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    iget-object v2, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 39
    .line 40
    if-nez v0, :cond_13

    .line 41
    .line 42
    iget-object v0, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 43
    .line 44
    iget-object v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->mimeType:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v0, v2}, Landroidx/media3/common/util/Util;->inferContentTypeForUriAndMimeType(Landroid/net/Uri;Ljava/lang/String;)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    iget-object v2, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 51
    .line 52
    iget-wide v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->imageDurationMs:J

    .line 53
    .line 54
    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    cmp-long v2, v2, v4

    .line 60
    .line 61
    const/4 v3, 0x1

    .line 62
    if-eqz v2, :cond_3

    .line 63
    .line 64
    iget-object v2, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

    .line 65
    .line 66
    iget-object v2, v2, Lcoil3/ImageLoader$Builder;->application:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v2, Landroidx/media3/extractor/ExtractorsFactory;

    .line 69
    .line 70
    instance-of v6, v2, Landroidx/media3/extractor/DefaultExtractorsFactory;

    .line 71
    .line 72
    if-eqz v6, :cond_2

    .line 73
    .line 74
    check-cast v2, Landroidx/media3/extractor/DefaultExtractorsFactory;

    .line 75
    .line 76
    monitor-enter v2

    .line 77
    :try_start_0
    iput-boolean v3, v2, Landroidx/media3/extractor/DefaultExtractorsFactory;->jpegFlags:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 78
    .line 79
    monitor-exit v2

    .line 80
    goto :goto_1

    .line 81
    :catchall_0
    move-exception p0

    .line 82
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 83
    throw p0

    .line 84
    :cond_2
    :goto_1
    iget-object v2, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

    .line 85
    .line 86
    iget-object v2, v2, Lcoil3/ImageLoader$Builder;->application:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v2, Landroidx/media3/extractor/ExtractorsFactory;

    .line 89
    .line 90
    instance-of v6, v2, Landroidx/media3/extractor/DefaultExtractorsFactory;

    .line 91
    .line 92
    if-eqz v6, :cond_3

    .line 93
    .line 94
    check-cast v2, Landroidx/media3/extractor/DefaultExtractorsFactory;

    .line 95
    .line 96
    monitor-enter v2

    .line 97
    :try_start_2
    iput-boolean v3, v2, Landroidx/media3/extractor/DefaultExtractorsFactory;->heifFlags:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 98
    .line 99
    monitor-exit v2

    .line 100
    goto :goto_2

    .line 101
    :catchall_1
    move-exception p0

    .line 102
    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 103
    throw p0

    .line 104
    :cond_3
    :goto_2
    :try_start_4
    iget-object v2, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

    .line 105
    .line 106
    iget-object v6, v2, Lcoil3/ImageLoader$Builder;->memoryCacheLazy:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast v6, Ljava/util/HashMap;

    .line 109
    .line 110
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 111
    .line 112
    .line 113
    move-result-object v7

    .line 114
    invoke-virtual {v6, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v7

    .line 118
    check-cast v7, Landroidx/media3/exoplayer/source/MediaSource$Factory;

    .line 119
    .line 120
    if-eqz v7, :cond_4

    .line 121
    .line 122
    goto :goto_3

    .line 123
    :cond_4
    invoke-virtual {v2, v0}, Lcoil3/ImageLoader$Builder;->loadSupplier(I)Lcom/google/common/base/Supplier;

    .line 124
    .line 125
    .line 126
    move-result-object v7

    .line 127
    invoke-interface {v7}, Lcom/google/common/base/Supplier;->get()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v7

    .line 131
    check-cast v7, Landroidx/media3/exoplayer/source/MediaSource$Factory;

    .line 132
    .line 133
    iget-object v2, v2, Lcoil3/ImageLoader$Builder;->extras:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v2, Landroidx/media3/extractor/text/CueDecoder;

    .line 136
    .line 137
    invoke-interface {v7, v2}, Landroidx/media3/exoplayer/source/MediaSource$Factory;->setSubtitleParserFactory(Landroidx/media3/extractor/text/CueDecoder;)V

    .line 138
    .line 139
    .line 140
    invoke-interface {v7}, Landroidx/media3/exoplayer/source/MediaSource$Factory;->experimentalParseSubtitlesDuringExtraction()V

    .line 141
    .line 142
    .line 143
    invoke-interface {v7}, Landroidx/media3/exoplayer/source/MediaSource$Factory;->experimentalSetCodecsToParseWithinGopSampleDependencies()V

    .line 144
    .line 145
    .line 146
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    invoke-virtual {v6, v0, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_4
    .catch Ljava/lang/ClassNotFoundException; {:try_start_4 .. :try_end_4} :catch_0

    .line 151
    .line 152
    .line 153
    :goto_3
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->liveConfiguration:Landroidx/media3/common/MediaItem$LiveConfiguration;

    .line 154
    .line 155
    invoke-virtual {v0}, Landroidx/media3/common/MediaItem$LiveConfiguration;->buildUpon()Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    iget-object v2, p1, Landroidx/media3/common/MediaItem;->liveConfiguration:Landroidx/media3/common/MediaItem$LiveConfiguration;

    .line 160
    .line 161
    iget-wide v8, v2, Landroidx/media3/common/MediaItem$LiveConfiguration;->targetOffsetMs:J

    .line 162
    .line 163
    cmp-long v6, v8, v4

    .line 164
    .line 165
    if-nez v6, :cond_5

    .line 166
    .line 167
    iget-wide v8, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveTargetOffsetMs:J

    .line 168
    .line 169
    iput-wide v8, v0, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->targetOffsetMs:J

    .line 170
    .line 171
    :cond_5
    iget v6, v2, Landroidx/media3/common/MediaItem$LiveConfiguration;->minPlaybackSpeed:F

    .line 172
    .line 173
    const v8, -0x800001

    .line 174
    .line 175
    .line 176
    cmpl-float v6, v6, v8

    .line 177
    .line 178
    if-nez v6, :cond_6

    .line 179
    .line 180
    iget v6, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMinSpeed:F

    .line 181
    .line 182
    iput v6, v0, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->minPlaybackSpeed:F

    .line 183
    .line 184
    :cond_6
    iget v6, v2, Landroidx/media3/common/MediaItem$LiveConfiguration;->maxPlaybackSpeed:F

    .line 185
    .line 186
    cmpl-float v6, v6, v8

    .line 187
    .line 188
    if-nez v6, :cond_7

    .line 189
    .line 190
    iget v6, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMaxSpeed:F

    .line 191
    .line 192
    iput v6, v0, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->maxPlaybackSpeed:F

    .line 193
    .line 194
    :cond_7
    iget-wide v8, v2, Landroidx/media3/common/MediaItem$LiveConfiguration;->minOffsetMs:J

    .line 195
    .line 196
    cmp-long v6, v8, v4

    .line 197
    .line 198
    if-nez v6, :cond_8

    .line 199
    .line 200
    iget-wide v8, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMinOffsetMs:J

    .line 201
    .line 202
    iput-wide v8, v0, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->minOffsetMs:J

    .line 203
    .line 204
    :cond_8
    iget-wide v8, v2, Landroidx/media3/common/MediaItem$LiveConfiguration;->maxOffsetMs:J

    .line 205
    .line 206
    cmp-long v2, v8, v4

    .line 207
    .line 208
    if-nez v2, :cond_9

    .line 209
    .line 210
    iget-wide v4, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->liveMaxOffsetMs:J

    .line 211
    .line 212
    iput-wide v4, v0, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->maxOffsetMs:J

    .line 213
    .line 214
    :cond_9
    new-instance v2, Landroidx/media3/common/MediaItem$LiveConfiguration;

    .line 215
    .line 216
    invoke-direct {v2, v0}, Landroidx/media3/common/MediaItem$LiveConfiguration;-><init>(Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;)V

    .line 217
    .line 218
    .line 219
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->liveConfiguration:Landroidx/media3/common/MediaItem$LiveConfiguration;

    .line 220
    .line 221
    invoke-virtual {v2, v0}, Landroidx/media3/common/MediaItem$LiveConfiguration;->equals(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    move-result v0

    .line 225
    if-nez v0, :cond_a

    .line 226
    .line 227
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem;->buildUpon()Landroidx/media3/common/MediaItem$Builder;

    .line 228
    .line 229
    .line 230
    move-result-object p1

    .line 231
    invoke-virtual {v2}, Landroidx/media3/common/MediaItem$LiveConfiguration;->buildUpon()Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    iput-object v0, p1, Landroidx/media3/common/MediaItem$Builder;->liveConfiguration:Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;

    .line 236
    .line 237
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 238
    .line 239
    .line 240
    move-result-object p1

    .line 241
    :cond_a
    invoke-interface {v7, p1}, Landroidx/media3/exoplayer/source/MediaSource$Factory;->createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/source/BaseMediaSource;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    iget-object v2, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 246
    .line 247
    iget-object v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->subtitleConfigurations:Lcom/google/common/collect/ImmutableList;

    .line 248
    .line 249
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 250
    .line 251
    .line 252
    move-result v4

    .line 253
    const/4 v5, 0x0

    .line 254
    if-nez v4, :cond_f

    .line 255
    .line 256
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 257
    .line 258
    .line 259
    move-result v4

    .line 260
    add-int/2addr v4, v3

    .line 261
    new-array v4, v4, [Landroidx/media3/exoplayer/source/BaseMediaSource;

    .line 262
    .line 263
    aput-object v0, v4, v5

    .line 264
    .line 265
    move v0, v5

    .line 266
    :goto_4
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 267
    .line 268
    .line 269
    move-result v6

    .line 270
    if-ge v0, v6, :cond_e

    .line 271
    .line 272
    iget-boolean v6, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->parseSubtitlesDuringExtraction:Z

    .line 273
    .line 274
    const/4 v7, 0x6

    .line 275
    if-eqz v6, :cond_d

    .line 276
    .line 277
    new-instance v6, Landroidx/media3/common/Format$Builder;

    .line 278
    .line 279
    invoke-direct {v6}, Landroidx/media3/common/Format$Builder;-><init>()V

    .line 280
    .line 281
    .line 282
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v8

    .line 286
    check-cast v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 287
    .line 288
    iget-object v8, v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->mimeType:Ljava/lang/String;

    .line 289
    .line 290
    invoke-static {v8}, Landroidx/media3/common/MimeTypes;->normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v8

    .line 294
    iput-object v8, v6, Landroidx/media3/common/Format$Builder;->sampleMimeType:Ljava/lang/String;

    .line 295
    .line 296
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v8

    .line 300
    check-cast v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 301
    .line 302
    iget-object v8, v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->language:Ljava/lang/String;

    .line 303
    .line 304
    iput-object v8, v6, Landroidx/media3/common/Format$Builder;->language:Ljava/lang/String;

    .line 305
    .line 306
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v8

    .line 310
    check-cast v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 311
    .line 312
    iget v8, v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->selectionFlags:I

    .line 313
    .line 314
    iput v8, v6, Landroidx/media3/common/Format$Builder;->selectionFlags:I

    .line 315
    .line 316
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 317
    .line 318
    .line 319
    move-result-object v8

    .line 320
    check-cast v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 321
    .line 322
    iget v8, v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->roleFlags:I

    .line 323
    .line 324
    iput v8, v6, Landroidx/media3/common/Format$Builder;->roleFlags:I

    .line 325
    .line 326
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 327
    .line 328
    .line 329
    move-result-object v8

    .line 330
    check-cast v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 331
    .line 332
    iget-object v8, v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->label:Ljava/lang/String;

    .line 333
    .line 334
    iput-object v8, v6, Landroidx/media3/common/Format$Builder;->label:Ljava/lang/String;

    .line 335
    .line 336
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    move-result-object v8

    .line 340
    check-cast v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 341
    .line 342
    iget-object v8, v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->id:Ljava/lang/String;

    .line 343
    .line 344
    iput-object v8, v6, Landroidx/media3/common/Format$Builder;->id:Ljava/lang/String;

    .line 345
    .line 346
    new-instance v8, Landroidx/media3/common/Format;

    .line 347
    .line 348
    invoke-direct {v8, v6}, Landroidx/media3/common/Format;-><init>(Landroidx/media3/common/Format$Builder;)V

    .line 349
    .line 350
    .line 351
    new-instance v6, Landroidx/compose/foundation/text/TextLinkScope$$ExternalSyntheticLambda10;

    .line 352
    .line 353
    invoke-direct {v6, p0, v8, v7}, Landroidx/compose/foundation/text/TextLinkScope$$ExternalSyntheticLambda10;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 354
    .line 355
    .line 356
    new-instance v7, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;

    .line 357
    .line 358
    iget-object v9, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->dataSourceFactory:Landroidx/media3/datasource/DataSource$Factory;

    .line 359
    .line 360
    invoke-direct {v7, v9, v6}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;-><init>(Landroidx/media3/datasource/DataSource$Factory;Landroidx/media3/extractor/ExtractorsFactory;)V

    .line 361
    .line 362
    .line 363
    iget-object v6, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->subtitleParserFactory:Landroidx/media3/extractor/text/CueDecoder;

    .line 364
    .line 365
    invoke-virtual {v6, v8}, Landroidx/media3/extractor/text/CueDecoder;->supportsFormat(Landroidx/media3/common/Format;)Z

    .line 366
    .line 367
    .line 368
    move-result v6

    .line 369
    if-eqz v6, :cond_b

    .line 370
    .line 371
    invoke-virtual {v8}, Landroidx/media3/common/Format;->buildUpon()Landroidx/media3/common/Format$Builder;

    .line 372
    .line 373
    .line 374
    move-result-object v6

    .line 375
    const-string v9, "application/x-media3-cues"

    .line 376
    .line 377
    invoke-static {v9}, Landroidx/media3/common/MimeTypes;->normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object v9

    .line 381
    iput-object v9, v6, Landroidx/media3/common/Format$Builder;->sampleMimeType:Ljava/lang/String;

    .line 382
    .line 383
    iget-object v9, v8, Landroidx/media3/common/Format;->sampleMimeType:Ljava/lang/String;

    .line 384
    .line 385
    iput-object v9, v6, Landroidx/media3/common/Format$Builder;->codecs:Ljava/lang/String;

    .line 386
    .line 387
    iget-object v9, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->subtitleParserFactory:Landroidx/media3/extractor/text/CueDecoder;

    .line 388
    .line 389
    invoke-virtual {v9, v8}, Landroidx/media3/extractor/text/CueDecoder;->getCueReplacementBehavior(Landroidx/media3/common/Format;)I

    .line 390
    .line 391
    .line 392
    move-result v8

    .line 393
    iput v8, v6, Landroidx/media3/common/Format$Builder;->cueReplacementBehavior:I

    .line 394
    .line 395
    new-instance v8, Landroidx/media3/common/Format;

    .line 396
    .line 397
    invoke-direct {v8, v6}, Landroidx/media3/common/Format;-><init>(Landroidx/media3/common/Format$Builder;)V

    .line 398
    .line 399
    .line 400
    :cond_b
    iput-object v8, v7, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;->singleTrackFormat:Landroidx/media3/common/Format;

    .line 401
    .line 402
    add-int/lit8 v6, v0, 0x1

    .line 403
    .line 404
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 405
    .line 406
    .line 407
    move-result-object v8

    .line 408
    check-cast v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 409
    .line 410
    iget-object v8, v8, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->uri:Landroid/net/Uri;

    .line 411
    .line 412
    invoke-virtual {v8}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object v8

    .line 416
    new-instance v9, Landroidx/media3/common/MediaItem$Builder;

    .line 417
    .line 418
    invoke-direct {v9}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 419
    .line 420
    .line 421
    if-nez v8, :cond_c

    .line 422
    .line 423
    move-object v8, v1

    .line 424
    goto :goto_5

    .line 425
    :cond_c
    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 426
    .line 427
    .line 428
    move-result-object v8

    .line 429
    :goto_5
    iput-object v8, v9, Landroidx/media3/common/MediaItem$Builder;->uri:Landroid/net/Uri;

    .line 430
    .line 431
    invoke-virtual {v9}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 432
    .line 433
    .line 434
    move-result-object v8

    .line 435
    invoke-virtual {v7, v8}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;->createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/source/ProgressiveMediaSource;

    .line 436
    .line 437
    .line 438
    move-result-object v7

    .line 439
    aput-object v7, v4, v6

    .line 440
    .line 441
    goto :goto_6

    .line 442
    :cond_d
    iget-object v6, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->dataSourceFactory:Landroidx/media3/datasource/DataSource$Factory;

    .line 443
    .line 444
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 445
    .line 446
    .line 447
    new-instance v8, Landroidx/media3/extractor/text/CueDecoder;

    .line 448
    .line 449
    invoke-direct {v8, v7}, Landroidx/media3/extractor/text/CueDecoder;-><init>(B)V

    .line 450
    .line 451
    .line 452
    add-int/lit8 v7, v0, 0x1

    .line 453
    .line 454
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 455
    .line 456
    .line 457
    move-result-object v9

    .line 458
    check-cast v9, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 459
    .line 460
    new-instance v10, Landroidx/media3/exoplayer/source/SingleSampleMediaSource;

    .line 461
    .line 462
    invoke-direct {v10, v9, v6, v8}, Landroidx/media3/exoplayer/source/SingleSampleMediaSource;-><init>(Landroidx/media3/common/MediaItem$SubtitleConfiguration;Landroidx/media3/datasource/DataSource$Factory;Landroidx/media3/extractor/text/CueDecoder;)V

    .line 463
    .line 464
    .line 465
    aput-object v10, v4, v7

    .line 466
    .line 467
    :goto_6
    add-int/lit8 v0, v0, 0x1

    .line 468
    .line 469
    goto/16 :goto_4

    .line 470
    .line 471
    :cond_e
    new-instance v0, Landroidx/media3/exoplayer/source/MergingMediaSource;

    .line 472
    .line 473
    invoke-direct {v0, v4}, Landroidx/media3/exoplayer/source/MergingMediaSource;-><init>([Landroidx/media3/exoplayer/source/BaseMediaSource;)V

    .line 474
    .line 475
    .line 476
    :cond_f
    iget-object p0, p1, Landroidx/media3/common/MediaItem;->clippingConfiguration:Landroidx/media3/common/MediaItem$ClippingProperties;

    .line 477
    .line 478
    iget-wide v1, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->startPositionUs:J

    .line 479
    .line 480
    const-wide/16 v6, 0x0

    .line 481
    .line 482
    cmp-long v1, v1, v6

    .line 483
    .line 484
    if-nez v1, :cond_10

    .line 485
    .line 486
    iget-wide v1, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->endPositionUs:J

    .line 487
    .line 488
    const-wide/high16 v8, -0x8000000000000000L

    .line 489
    .line 490
    cmp-long v1, v1, v8

    .line 491
    .line 492
    if-nez v1, :cond_10

    .line 493
    .line 494
    iget-boolean v1, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->relativeToDefaultPosition:Z

    .line 495
    .line 496
    if-nez v1, :cond_10

    .line 497
    .line 498
    goto :goto_7

    .line 499
    :cond_10
    new-instance v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;

    .line 500
    .line 501
    invoke-direct {v1, v0}, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;-><init>(Landroidx/media3/exoplayer/source/BaseMediaSource;)V

    .line 502
    .line 503
    .line 504
    iget-wide v8, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->startPositionUs:J

    .line 505
    .line 506
    cmp-long v0, v8, v6

    .line 507
    .line 508
    if-ltz v0, :cond_11

    .line 509
    .line 510
    move v5, v3

    .line 511
    :cond_11
    invoke-static {v5}, Lcoil3/util/UtilsKt;->checkArgument(Z)V

    .line 512
    .line 513
    .line 514
    iget-boolean v0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 515
    .line 516
    xor-int/2addr v0, v3

    .line 517
    invoke-static {v0}, Lcoil3/util/UtilsKt;->checkState(Z)V

    .line 518
    .line 519
    .line 520
    iput-wide v8, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->startPositionUs:J

    .line 521
    .line 522
    iget-wide v4, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->endPositionUs:J

    .line 523
    .line 524
    iget-boolean v0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 525
    .line 526
    xor-int/2addr v0, v3

    .line 527
    invoke-static {v0}, Lcoil3/util/UtilsKt;->checkState(Z)V

    .line 528
    .line 529
    .line 530
    iput-wide v4, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->endPositionUs:J

    .line 531
    .line 532
    iget-boolean v0, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->startsAtKeyFrame:Z

    .line 533
    .line 534
    xor-int/2addr v0, v3

    .line 535
    iget-boolean v2, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 536
    .line 537
    xor-int/2addr v2, v3

    .line 538
    invoke-static {v2}, Lcoil3/util/UtilsKt;->checkState(Z)V

    .line 539
    .line 540
    .line 541
    iput-boolean v0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->enableInitialDiscontinuity:Z

    .line 542
    .line 543
    iget-boolean v0, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->relativeToLiveWindow:Z

    .line 544
    .line 545
    iget-boolean v2, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 546
    .line 547
    xor-int/2addr v2, v3

    .line 548
    invoke-static {v2}, Lcoil3/util/UtilsKt;->checkState(Z)V

    .line 549
    .line 550
    .line 551
    iput-boolean v0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->allowDynamicClippingUpdates:Z

    .line 552
    .line 553
    iget-boolean v0, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->relativeToDefaultPosition:Z

    .line 554
    .line 555
    iget-boolean v2, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 556
    .line 557
    xor-int/2addr v2, v3

    .line 558
    invoke-static {v2}, Lcoil3/util/UtilsKt;->checkState(Z)V

    .line 559
    .line 560
    .line 561
    iput-boolean v0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->relativeToDefaultPosition:Z

    .line 562
    .line 563
    iget-boolean p0, p0, Landroidx/media3/common/MediaItem$ClippingConfiguration;->allowUnseekableMedia:Z

    .line 564
    .line 565
    iget-boolean v0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 566
    .line 567
    xor-int/2addr v0, v3

    .line 568
    invoke-static {v0}, Lcoil3/util/UtilsKt;->checkState(Z)V

    .line 569
    .line 570
    .line 571
    iput-boolean p0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->allowUnseekableMedia:Z

    .line 572
    .line 573
    iget-boolean p0, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 574
    .line 575
    xor-int/2addr p0, v3

    .line 576
    invoke-static {p0}, Lcoil3/util/UtilsKt;->checkState(Z)V

    .line 577
    .line 578
    .line 579
    iput-boolean v3, v1, Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;->buildCalled:Z

    .line 580
    .line 581
    new-instance v0, Landroidx/media3/exoplayer/source/ClippingMediaSource;

    .line 582
    .line 583
    invoke-direct {v0, v1}, Landroidx/media3/exoplayer/source/ClippingMediaSource;-><init>(Landroidx/media3/exoplayer/source/ClippingMediaSource$Builder;)V

    .line 584
    .line 585
    .line 586
    :goto_7
    iget-object p0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 587
    .line 588
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 589
    .line 590
    .line 591
    iget-object p0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 592
    .line 593
    iget-object p0, p0, Landroidx/media3/common/MediaItem$LocalConfiguration;->adsConfiguration:Landroidx/media3/common/MediaItem$AdsConfiguration;

    .line 594
    .line 595
    if-nez p0, :cond_12

    .line 596
    .line 597
    return-object v0

    .line 598
    :cond_12
    const-string p0, "DMediaSourceFactory"

    .line 599
    .line 600
    const-string p1, "Playing media without ads. Configure ad support by calling setAdsLoaderProvider and setAdViewProvider."

    .line 601
    .line 602
    invoke-static {p0, p1}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 603
    .line 604
    .line 605
    return-object v0

    .line 606
    :catch_0
    move-exception p0

    .line 607
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 608
    .line 609
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 610
    .line 611
    .line 612
    throw p1

    .line 613
    :cond_13
    iget-wide p0, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->imageDurationMs:J

    .line 614
    .line 615
    sget-object p0, Landroidx/media3/common/util/Util;->DEVICE_DEBUG_INFO:Ljava/lang/String;

    .line 616
    .line 617
    throw v1
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
.end method

.method public final experimentalParseSubtitlesDuringExtraction()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->parseSubtitlesDuringExtraction:Z

    .line 3
    .line 4
    iget-object p0, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

    .line 5
    .line 6
    iget-object v0, p0, Lcoil3/ImageLoader$Builder;->application:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroidx/media3/extractor/ExtractorsFactory;

    .line 9
    .line 10
    invoke-interface {v0}, Landroidx/media3/extractor/ExtractorsFactory;->experimentalSetTextTrackTranscodingEnabled()V

    .line 11
    .line 12
    .line 13
    iget-object p0, p0, Lcoil3/ImageLoader$Builder;->memoryCacheLazy:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p0, Ljava/util/HashMap;

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Landroidx/media3/exoplayer/source/MediaSource$Factory;

    .line 36
    .line 37
    invoke-interface {v0}, Landroidx/media3/exoplayer/source/MediaSource$Factory;->experimentalParseSubtitlesDuringExtraction()V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    return-void
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method

.method public final experimentalSetCodecsToParseWithinGopSampleDependencies()V
    .locals 0

    .line 1
    iget-object p0, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

    .line 2
    .line 3
    iget-object p0, p0, Lcoil3/ImageLoader$Builder;->application:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Landroidx/media3/extractor/ExtractorsFactory;

    .line 6
    .line 7
    invoke-interface {p0}, Landroidx/media3/extractor/ExtractorsFactory;->experimentalSetCodecsToParseWithinGopSampleDependencies()V

    .line 8
    .line 9
    .line 10
    return-void
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
.end method

.method public final setSubtitleParserFactory(Landroidx/media3/extractor/text/CueDecoder;)V
    .locals 1

    .line 1
    iput-object p1, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->subtitleParserFactory:Landroidx/media3/extractor/text/CueDecoder;

    .line 2
    .line 3
    iget-object p0, p0, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->delegateFactoryLoader:Lcoil3/ImageLoader$Builder;

    .line 4
    .line 5
    iput-object p1, p0, Lcoil3/ImageLoader$Builder;->extras:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v0, p0, Lcoil3/ImageLoader$Builder;->application:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Landroidx/media3/extractor/ExtractorsFactory;

    .line 10
    .line 11
    invoke-interface {v0, p1}, Landroidx/media3/extractor/ExtractorsFactory;->setSubtitleParserFactory(Landroidx/media3/extractor/text/CueDecoder;)V

    .line 12
    .line 13
    .line 14
    iget-object p0, p0, Lcoil3/ImageLoader$Builder;->memoryCacheLazy:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p0, Ljava/util/HashMap;

    .line 17
    .line 18
    invoke-virtual {p0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroidx/media3/exoplayer/source/MediaSource$Factory;

    .line 37
    .line 38
    invoke-interface {v0, p1}, Landroidx/media3/exoplayer/source/MediaSource$Factory;->setSubtitleParserFactory(Landroidx/media3/extractor/text/CueDecoder;)V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    return-void
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
.end method
