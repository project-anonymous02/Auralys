.class public final Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;
.super Landroid/os/Handler;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public final synthetic $r8$classId:B

.field public isReleased:Z

.field public final synthetic this$0:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroidx/media3/exoplayer/drm/DefaultDrmSession;Landroid/os/Looper;)V
    .locals 1

    const/4 v0, 0x0

    iput-byte v0, p0, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->$r8$classId:B

    .line 13
    iput-object p1, p0, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 14
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method

.method public constructor <init>(Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;Landroid/os/Looper;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->$r8$classId:B

    .line 3
    .line 4
    iput-object p1, p0, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 7
    .line 8
    .line 9
    const/4 p1, 0x0

    .line 10
    iput-boolean p1, p0, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->isReleased:Z

    .line 11
    .line 12
    return-void
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    iget-byte v0, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->$r8$classId:B

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    const/4 v4, 0x2

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    const-string v5, "MediaControllerCompat"

    .line 13
    .line 14
    iget-object v0, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 15
    .line 16
    move-object v6, v0

    .line 17
    check-cast v6, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;

    .line 18
    .line 19
    iget-object v7, v6, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;->this$0:Landroidx/media3/session/MediaControllerImplLegacy;

    .line 20
    .line 21
    iget-boolean v0, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->isReleased:Z

    .line 22
    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    goto/16 :goto_7

    .line 26
    .line 27
    :cond_0
    iget v0, v2, Landroid/os/Message;->what:I

    .line 28
    .line 29
    if-eq v0, v4, :cond_7

    .line 30
    .line 31
    const/16 v1, 0x8

    .line 32
    .line 33
    if-eq v0, v1, :cond_6

    .line 34
    .line 35
    const/16 v1, 0x9

    .line 36
    .line 37
    if-eq v0, v1, :cond_5

    .line 38
    .line 39
    packed-switch v0, :pswitch_data_1

    .line 40
    .line 41
    .line 42
    goto/16 :goto_7

    .line 43
    .line 44
    :pswitch_0
    iget-boolean v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->connected:Z

    .line 45
    .line 46
    if-nez v0, :cond_1

    .line 47
    .line 48
    invoke-virtual {v7}, Landroidx/media3/session/MediaControllerImplLegacy;->onConnected()V

    .line 49
    .line 50
    .line 51
    goto/16 :goto_7

    .line 52
    .line 53
    :cond_1
    iget-object v1, v7, Landroidx/media3/session/MediaControllerImplLegacy;->pendingLegacyPlayerInfo:Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 54
    .line 55
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->controllerCompat:Landroidx/core/provider/CallbackWrapper;

    .line 56
    .line 57
    invoke-virtual {v0}, Landroidx/core/provider/CallbackWrapper;->getPlaybackState()Landroidx/media3/session/legacy/PlaybackStateCompat;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-static {v0}, Landroidx/media3/session/MediaControllerImplLegacy;->convertToSafePlaybackStateCompat(Landroidx/media3/session/legacy/PlaybackStateCompat;)Landroidx/media3/session/legacy/PlaybackStateCompat;

    .line 62
    .line 63
    .line 64
    move-result-object v10

    .line 65
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->controllerCompat:Landroidx/core/provider/CallbackWrapper;

    .line 66
    .line 67
    iget-object v0, v0, Landroidx/core/provider/CallbackWrapper;->mCallback:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast v0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;

    .line 70
    .line 71
    iget-object v0, v0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;->sessionToken:Landroidx/media3/session/legacy/MediaSessionCompat$Token;

    .line 72
    .line 73
    invoke-virtual {v0}, Landroidx/media3/session/legacy/MediaSessionCompat$Token;->getExtraBinder()Landroidx/media3/session/legacy/IMediaSession;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    const/4 v2, -0x1

    .line 78
    if-eqz v0, :cond_2

    .line 79
    .line 80
    :try_start_0
    invoke-interface {v0}, Landroidx/media3/session/legacy/IMediaSession;->getRepeatMode()I

    .line 81
    .line 82
    .line 83
    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 84
    move v14, v0

    .line 85
    goto :goto_1

    .line 86
    :catch_0
    move-exception v0

    .line 87
    goto :goto_0

    .line 88
    :catch_1
    move-exception v0

    .line 89
    :goto_0
    const-string v4, "Dead object in getRepeatMode."

    .line 90
    .line 91
    invoke-static {v5, v4, v0}, Landroidx/media3/common/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 92
    .line 93
    .line 94
    :cond_2
    move v14, v2

    .line 95
    :goto_1
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->controllerCompat:Landroidx/core/provider/CallbackWrapper;

    .line 96
    .line 97
    iget-object v0, v0, Landroidx/core/provider/CallbackWrapper;->mCallback:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;

    .line 100
    .line 101
    iget-object v0, v0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;->sessionToken:Landroidx/media3/session/legacy/MediaSessionCompat$Token;

    .line 102
    .line 103
    invoke-virtual {v0}, Landroidx/media3/session/legacy/MediaSessionCompat$Token;->getExtraBinder()Landroidx/media3/session/legacy/IMediaSession;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    if-eqz v0, :cond_3

    .line 108
    .line 109
    :try_start_1
    invoke-interface {v0}, Landroidx/media3/session/legacy/IMediaSession;->getShuffleMode()I

    .line 110
    .line 111
    .line 112
    move-result v2
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_2

    .line 113
    :cond_3
    :goto_2
    move v15, v2

    .line 114
    goto :goto_4

    .line 115
    :catch_2
    move-exception v0

    .line 116
    goto :goto_3

    .line 117
    :catch_3
    move-exception v0

    .line 118
    :goto_3
    const-string v4, "Dead object in getShuffleMode."

    .line 119
    .line 120
    invoke-static {v5, v4, v0}, Landroidx/media3/common/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 121
    .line 122
    .line 123
    goto :goto_2

    .line 124
    :goto_4
    new-instance v8, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 125
    .line 126
    iget-object v9, v1, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->playbackInfoCompat:Landroidx/media3/session/legacy/MediaControllerCompat$PlaybackInfo;

    .line 127
    .line 128
    iget-object v11, v1, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->mediaMetadataCompat:Landroidx/media3/session/legacy/MediaMetadataCompat;

    .line 129
    .line 130
    iget-object v12, v1, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->queue:Ljava/util/List;

    .line 131
    .line 132
    iget-object v13, v1, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->queueTitle:Ljava/lang/CharSequence;

    .line 133
    .line 134
    iget-object v0, v1, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->sessionExtras:Landroid/os/Bundle;

    .line 135
    .line 136
    move-object/from16 v16, v0

    .line 137
    .line 138
    invoke-direct/range {v8 .. v16}, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;-><init>(Landroidx/media3/session/legacy/MediaControllerCompat$PlaybackInfo;Landroidx/media3/session/legacy/PlaybackStateCompat;Landroidx/media3/session/legacy/MediaMetadataCompat;Ljava/util/List;Ljava/lang/CharSequence;IILandroid/os/Bundle;)V

    .line 139
    .line 140
    .line 141
    iput-object v8, v7, Landroidx/media3/session/MediaControllerImplLegacy;->pendingLegacyPlayerInfo:Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 142
    .line 143
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->controllerCompat:Landroidx/core/provider/CallbackWrapper;

    .line 144
    .line 145
    iget-object v0, v0, Landroidx/core/provider/CallbackWrapper;->mCallback:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast v0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;

    .line 148
    .line 149
    iget-object v0, v0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;->sessionToken:Landroidx/media3/session/legacy/MediaSessionCompat$Token;

    .line 150
    .line 151
    invoke-virtual {v0}, Landroidx/media3/session/legacy/MediaSessionCompat$Token;->getExtraBinder()Landroidx/media3/session/legacy/IMediaSession;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    const/4 v1, 0x0

    .line 156
    if-eqz v0, :cond_4

    .line 157
    .line 158
    :try_start_2
    invoke-interface {v0}, Landroidx/media3/session/legacy/IMediaSession;->isCaptioningEnabled()Z

    .line 159
    .line 160
    .line 161
    move-result v0
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_4

    .line 162
    goto :goto_6

    .line 163
    :catch_4
    move-exception v0

    .line 164
    goto :goto_5

    .line 165
    :catch_5
    move-exception v0

    .line 166
    :goto_5
    const-string v2, "Dead object in isCaptioningEnabled."

    .line 167
    .line 168
    invoke-static {v5, v2, v0}, Landroidx/media3/common/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 169
    .line 170
    .line 171
    :cond_4
    move v0, v1

    .line 172
    :goto_6
    invoke-virtual {v6, v0}, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;->onCaptioningEnabledChanged(Z)V

    .line 173
    .line 174
    .line 175
    iget-object v0, v6, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;->pendingChangesHandler:Landroid/os/Handler;

    .line 176
    .line 177
    invoke-virtual {v0, v3}, Landroid/os/Handler;->removeMessages(I)V

    .line 178
    .line 179
    .line 180
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->pendingLegacyPlayerInfo:Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 181
    .line 182
    invoke-virtual {v7, v1, v0}, Landroidx/media3/session/MediaControllerImplLegacy;->handleNewLegacyParameters(ZLandroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;)V

    .line 183
    .line 184
    .line 185
    goto :goto_7

    .line 186
    :pswitch_1
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 187
    .line 188
    check-cast v0, Ljava/lang/Integer;

    .line 189
    .line 190
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 191
    .line 192
    .line 193
    move-result v15

    .line 194
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->pendingLegacyPlayerInfo:Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 195
    .line 196
    new-instance v8, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 197
    .line 198
    iget-object v9, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->playbackInfoCompat:Landroidx/media3/session/legacy/MediaControllerCompat$PlaybackInfo;

    .line 199
    .line 200
    iget-object v10, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->playbackStateCompat:Landroidx/media3/session/legacy/PlaybackStateCompat;

    .line 201
    .line 202
    iget-object v11, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->mediaMetadataCompat:Landroidx/media3/session/legacy/MediaMetadataCompat;

    .line 203
    .line 204
    iget-object v12, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->queue:Ljava/util/List;

    .line 205
    .line 206
    iget-object v13, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->queueTitle:Ljava/lang/CharSequence;

    .line 207
    .line 208
    iget v14, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->repeatMode:I

    .line 209
    .line 210
    iget-object v0, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->sessionExtras:Landroid/os/Bundle;

    .line 211
    .line 212
    move-object/from16 v16, v0

    .line 213
    .line 214
    invoke-direct/range {v8 .. v16}, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;-><init>(Landroidx/media3/session/legacy/MediaControllerCompat$PlaybackInfo;Landroidx/media3/session/legacy/PlaybackStateCompat;Landroidx/media3/session/legacy/MediaMetadataCompat;Ljava/util/List;Ljava/lang/CharSequence;IILandroid/os/Bundle;)V

    .line 215
    .line 216
    .line 217
    iput-object v8, v7, Landroidx/media3/session/MediaControllerImplLegacy;->pendingLegacyPlayerInfo:Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 218
    .line 219
    invoke-virtual {v6}, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;->startWaitingForPendingChanges()V

    .line 220
    .line 221
    .line 222
    goto :goto_7

    .line 223
    :pswitch_2
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v0, Ljava/lang/Boolean;

    .line 226
    .line 227
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 228
    .line 229
    .line 230
    move-result v0

    .line 231
    invoke-virtual {v6, v0}, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;->onCaptioningEnabledChanged(Z)V

    .line 232
    .line 233
    .line 234
    goto :goto_7

    .line 235
    :cond_5
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 236
    .line 237
    check-cast v0, Ljava/lang/Integer;

    .line 238
    .line 239
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 240
    .line 241
    .line 242
    move-result v14

    .line 243
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->pendingLegacyPlayerInfo:Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 244
    .line 245
    new-instance v8, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 246
    .line 247
    iget-object v9, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->playbackInfoCompat:Landroidx/media3/session/legacy/MediaControllerCompat$PlaybackInfo;

    .line 248
    .line 249
    iget-object v10, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->playbackStateCompat:Landroidx/media3/session/legacy/PlaybackStateCompat;

    .line 250
    .line 251
    iget-object v11, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->mediaMetadataCompat:Landroidx/media3/session/legacy/MediaMetadataCompat;

    .line 252
    .line 253
    iget-object v12, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->queue:Ljava/util/List;

    .line 254
    .line 255
    iget-object v13, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->queueTitle:Ljava/lang/CharSequence;

    .line 256
    .line 257
    iget v15, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->shuffleMode:I

    .line 258
    .line 259
    iget-object v0, v0, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;->sessionExtras:Landroid/os/Bundle;

    .line 260
    .line 261
    move-object/from16 v16, v0

    .line 262
    .line 263
    invoke-direct/range {v8 .. v16}, Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;-><init>(Landroidx/media3/session/legacy/MediaControllerCompat$PlaybackInfo;Landroidx/media3/session/legacy/PlaybackStateCompat;Landroidx/media3/session/legacy/MediaMetadataCompat;Ljava/util/List;Ljava/lang/CharSequence;IILandroid/os/Bundle;)V

    .line 264
    .line 265
    .line 266
    iput-object v8, v7, Landroidx/media3/session/MediaControllerImplLegacy;->pendingLegacyPlayerInfo:Landroidx/media3/session/MediaControllerImplLegacy$LegacyPlayerInfo;

    .line 267
    .line 268
    invoke-virtual {v6}, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;->startWaitingForPendingChanges()V

    .line 269
    .line 270
    .line 271
    goto :goto_7

    .line 272
    :cond_6
    iget-object v0, v7, Landroidx/media3/session/MediaControllerImplLegacy;->instance:Landroidx/media3/session/MediaController;

    .line 273
    .line 274
    invoke-virtual {v0}, Landroidx/media3/session/MediaController;->release()V

    .line 275
    .line 276
    .line 277
    goto :goto_7

    .line 278
    :cond_7
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 279
    .line 280
    check-cast v0, Landroidx/media3/session/legacy/PlaybackStateCompat;

    .line 281
    .line 282
    invoke-virtual {v6, v0}, Landroidx/media3/session/MediaControllerImplLegacy$ControllerCompatCallback;->onPlaybackStateChanged(Landroidx/media3/session/legacy/PlaybackStateCompat;)V

    .line 283
    .line 284
    .line 285
    :goto_7
    return-void

    .line 286
    :pswitch_3
    iget-object v0, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 287
    .line 288
    move-object v5, v0

    .line 289
    check-cast v5, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;

    .line 290
    .line 291
    :try_start_3
    iget v0, v2, Landroid/os/Message;->what:I

    .line 292
    .line 293
    if-eq v0, v3, :cond_a

    .line 294
    .line 295
    if-ne v0, v4, :cond_9

    .line 296
    .line 297
    iget-object v0, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 298
    .line 299
    check-cast v0, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 300
    .line 301
    iget-object v4, v0, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->callback:Landroidx/compose/runtime/Latch;

    .line 302
    .line 303
    iget-object v0, v0, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->uuid:Ljava/util/UUID;

    .line 304
    .line 305
    iget-object v6, v5, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->request:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast v6, Landroidx/media3/exoplayer/drm/ExoMediaDrm$KeyRequest;

    .line 308
    .line 309
    invoke-virtual {v4, v0, v6}, Landroidx/compose/runtime/Latch;->executeKeyRequest(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$KeyRequest;)Landroidx/media3/exoplayer/drm/MediaDrmCallback$Response;

    .line 310
    .line 311
    .line 312
    move-result-object v0

    .line 313
    iget-object v4, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 314
    .line 315
    check-cast v4, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 316
    .line 317
    iget-object v4, v4, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->keyRequestInfoLock:Ljava/lang/Object;

    .line 318
    .line 319
    monitor-enter v4
    :try_end_3
    .catch Landroidx/media3/exoplayer/drm/MediaDrmCallbackException; {:try_start_3 .. :try_end_3} :catch_7
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_6

    .line 320
    :try_start_4
    iget-object v6, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 321
    .line 322
    check-cast v6, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 323
    .line 324
    iget-object v6, v6, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->currentKeyRequestInfo:Landroidx/datastore/core/AtomicInt;

    .line 325
    .line 326
    if-eqz v6, :cond_8

    .line 327
    .line 328
    iget-object v7, v0, Landroidx/media3/exoplayer/drm/MediaDrmCallback$Response;->loadEventInfo:Landroidx/media3/exoplayer/source/LoadEventInfo;

    .line 329
    .line 330
    if-eqz v7, :cond_8

    .line 331
    .line 332
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 333
    .line 334
    .line 335
    new-instance v8, Landroidx/media3/exoplayer/source/LoadEventInfo;

    .line 336
    .line 337
    iget-object v9, v7, Landroidx/media3/exoplayer/source/LoadEventInfo;->dataSpec:Landroidx/media3/datasource/DataSpec;

    .line 338
    .line 339
    iget-object v10, v7, Landroidx/media3/exoplayer/source/LoadEventInfo;->uri:Landroid/net/Uri;

    .line 340
    .line 341
    iget-object v11, v7, Landroidx/media3/exoplayer/source/LoadEventInfo;->responseHeaders:Ljava/util/Map;

    .line 342
    .line 343
    iget-wide v12, v7, Landroidx/media3/exoplayer/source/LoadEventInfo;->elapsedRealtimeMs:J

    .line 344
    .line 345
    iget-wide v14, v7, Landroidx/media3/exoplayer/source/LoadEventInfo;->bytesLoaded:J

    .line 346
    .line 347
    invoke-direct/range {v8 .. v15}, Landroidx/media3/exoplayer/source/LoadEventInfo;-><init>(Landroidx/media3/datasource/DataSpec;Landroid/net/Uri;Ljava/util/Map;JJ)V

    .line 348
    .line 349
    .line 350
    iget-object v6, v6, Landroidx/datastore/core/AtomicInt;->delegate:Ljava/lang/Object;

    .line 351
    .line 352
    check-cast v6, Lcom/google/common/collect/ImmutableList$Builder;

    .line 353
    .line 354
    invoke-virtual {v6, v8}, Lcom/google/common/collect/ImmutableCollection$ArrayBasedBuilder;->add(Ljava/lang/Object;)V

    .line 355
    .line 356
    .line 357
    goto :goto_8

    .line 358
    :catchall_0
    move-exception v0

    .line 359
    goto :goto_9

    .line 360
    :cond_8
    :goto_8
    monitor-exit v4

    .line 361
    goto/16 :goto_10

    .line 362
    .line 363
    :goto_9
    monitor-exit v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 364
    :try_start_5
    throw v0

    .line 365
    :catch_6
    move-exception v0

    .line 366
    goto :goto_a

    .line 367
    :catch_7
    move-exception v0

    .line 368
    goto :goto_b

    .line 369
    :cond_9
    new-instance v0, Ljava/lang/RuntimeException;

    .line 370
    .line 371
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 372
    .line 373
    .line 374
    throw v0

    .line 375
    :cond_a
    iget-object v0, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 376
    .line 377
    check-cast v0, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 378
    .line 379
    iget-object v0, v0, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->callback:Landroidx/compose/runtime/Latch;

    .line 380
    .line 381
    iget-object v4, v5, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->request:Ljava/lang/Object;

    .line 382
    .line 383
    check-cast v4, Landroidx/media3/exoplayer/drm/ExoMediaDrm$ProvisionRequest;

    .line 384
    .line 385
    invoke-virtual {v0, v4}, Landroidx/compose/runtime/Latch;->executeProvisionRequest(Landroidx/media3/exoplayer/drm/ExoMediaDrm$ProvisionRequest;)Landroidx/media3/exoplayer/drm/MediaDrmCallback$Response;

    .line 386
    .line 387
    .line 388
    move-result-object v0
    :try_end_5
    .catch Landroidx/media3/exoplayer/drm/MediaDrmCallbackException; {:try_start_5 .. :try_end_5} :catch_7
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_6

    .line 389
    goto/16 :goto_10

    .line 390
    .line 391
    :goto_a
    const-string v3, "DefaultDrmSession"

    .line 392
    .line 393
    const-string v4, "Key/provisioning request produced an unexpected exception. Not retrying."

    .line 394
    .line 395
    invoke-static {v3, v4, v0}, Landroidx/media3/common/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 396
    .line 397
    .line 398
    goto/16 :goto_10

    .line 399
    .line 400
    :goto_b
    iget-object v4, v2, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 401
    .line 402
    check-cast v4, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;

    .line 403
    .line 404
    iget-boolean v6, v4, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->allowRetry:Z

    .line 405
    .line 406
    if-nez v6, :cond_b

    .line 407
    .line 408
    goto/16 :goto_10

    .line 409
    .line 410
    :cond_b
    iget v6, v4, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->errorCount:I

    .line 411
    .line 412
    add-int/2addr v6, v3

    .line 413
    iput v6, v4, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->errorCount:I

    .line 414
    .line 415
    iget-object v7, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 416
    .line 417
    check-cast v7, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 418
    .line 419
    iget-object v7, v7, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->loadErrorHandlingPolicy:Landroidx/media3/extractor/text/CueDecoder;

    .line 420
    .line 421
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 422
    .line 423
    .line 424
    const/4 v7, 0x3

    .line 425
    if-le v6, v7, :cond_c

    .line 426
    .line 427
    goto/16 :goto_10

    .line 428
    .line 429
    :cond_c
    new-instance v8, Landroidx/media3/exoplayer/source/LoadEventInfo;

    .line 430
    .line 431
    iget-object v9, v0, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->dataSpec:Landroidx/media3/datasource/DataSpec;

    .line 432
    .line 433
    iget-object v10, v0, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->uriAfterRedirects:Landroid/net/Uri;

    .line 434
    .line 435
    iget-object v11, v0, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->responseHeaders:Ljava/util/Map;

    .line 436
    .line 437
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 438
    .line 439
    .line 440
    move-result-wide v12

    .line 441
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 442
    .line 443
    .line 444
    iget-wide v14, v0, Landroidx/media3/exoplayer/drm/MediaDrmCallbackException;->bytesLoaded:J

    .line 445
    .line 446
    invoke-direct/range {v8 .. v15}, Landroidx/media3/exoplayer/source/LoadEventInfo;-><init>(Landroidx/media3/datasource/DataSpec;Landroid/net/Uri;Ljava/util/Map;JJ)V

    .line 447
    .line 448
    .line 449
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 450
    .line 451
    .line 452
    move-result-object v6

    .line 453
    instance-of v6, v6, Ljava/io/IOException;

    .line 454
    .line 455
    if-eqz v6, :cond_d

    .line 456
    .line 457
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 458
    .line 459
    .line 460
    move-result-object v6

    .line 461
    check-cast v6, Ljava/io/IOException;

    .line 462
    .line 463
    goto :goto_c

    .line 464
    :cond_d
    new-instance v6, Lkotlin/io/FileSystemException;

    .line 465
    .line 466
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 467
    .line 468
    .line 469
    move-result-object v7

    .line 470
    invoke-direct {v6, v7}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 471
    .line 472
    .line 473
    :goto_c
    iget-object v7, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 474
    .line 475
    check-cast v7, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 476
    .line 477
    iget-object v7, v7, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->loadErrorHandlingPolicy:Landroidx/media3/extractor/text/CueDecoder;

    .line 478
    .line 479
    iget v4, v4, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->errorCount:I

    .line 480
    .line 481
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 482
    .line 483
    .line 484
    :goto_d
    const-wide v9, -0x7fffffffffffffffL    # -4.9E-324

    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    if-eqz v6, :cond_10

    .line 490
    .line 491
    instance-of v7, v6, Landroidx/media3/common/ParserException;

    .line 492
    .line 493
    if-nez v7, :cond_f

    .line 494
    .line 495
    instance-of v7, v6, Ljava/io/FileNotFoundException;

    .line 496
    .line 497
    if-nez v7, :cond_f

    .line 498
    .line 499
    instance-of v7, v6, Landroidx/media3/datasource/HttpDataSource$CleartextNotPermittedException;

    .line 500
    .line 501
    if-nez v7, :cond_f

    .line 502
    .line 503
    instance-of v7, v6, Landroidx/media3/exoplayer/upstream/Loader$UnexpectedLoaderException;

    .line 504
    .line 505
    if-nez v7, :cond_f

    .line 506
    .line 507
    instance-of v7, v6, Landroidx/media3/datasource/DataSourceException;

    .line 508
    .line 509
    if-eqz v7, :cond_e

    .line 510
    .line 511
    move-object v7, v6

    .line 512
    check-cast v7, Landroidx/media3/datasource/DataSourceException;

    .line 513
    .line 514
    iget v7, v7, Landroidx/media3/datasource/DataSourceException;->reason:I

    .line 515
    .line 516
    const/16 v11, 0x7d8

    .line 517
    .line 518
    if-ne v7, v11, :cond_e

    .line 519
    .line 520
    goto :goto_e

    .line 521
    :cond_e
    invoke-virtual {v6}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 522
    .line 523
    .line 524
    move-result-object v6

    .line 525
    goto :goto_d

    .line 526
    :cond_f
    :goto_e
    move-wide v3, v9

    .line 527
    goto :goto_f

    .line 528
    :cond_10
    sub-int/2addr v4, v3

    .line 529
    mul-int/lit16 v4, v4, 0x3e8

    .line 530
    .line 531
    const/16 v3, 0x1388

    .line 532
    .line 533
    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    .line 534
    .line 535
    .line 536
    move-result v3

    .line 537
    int-to-long v3, v3

    .line 538
    :goto_f
    cmp-long v6, v3, v9

    .line 539
    .line 540
    if-nez v6, :cond_11

    .line 541
    .line 542
    goto :goto_10

    .line 543
    :cond_11
    iget-object v6, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 544
    .line 545
    check-cast v6, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 546
    .line 547
    iget-object v6, v6, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->keyRequestInfoLock:Ljava/lang/Object;

    .line 548
    .line 549
    monitor-enter v6

    .line 550
    :try_start_6
    iget-object v7, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 551
    .line 552
    check-cast v7, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 553
    .line 554
    iget-object v7, v7, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->currentKeyRequestInfo:Landroidx/datastore/core/AtomicInt;

    .line 555
    .line 556
    if-eqz v7, :cond_12

    .line 557
    .line 558
    iget-object v7, v7, Landroidx/datastore/core/AtomicInt;->delegate:Ljava/lang/Object;

    .line 559
    .line 560
    check-cast v7, Lcom/google/common/collect/ImmutableList$Builder;

    .line 561
    .line 562
    invoke-virtual {v7, v8}, Lcom/google/common/collect/ImmutableCollection$ArrayBasedBuilder;->add(Ljava/lang/Object;)V

    .line 563
    .line 564
    .line 565
    :cond_12
    monitor-exit v6
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 566
    monitor-enter p0

    .line 567
    :try_start_7
    iget-boolean v6, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->isReleased:Z

    .line 568
    .line 569
    if-nez v6, :cond_13

    .line 570
    .line 571
    invoke-static {v2}, Landroid/os/Message;->obtain(Landroid/os/Message;)Landroid/os/Message;

    .line 572
    .line 573
    .line 574
    move-result-object v0

    .line 575
    invoke-virtual {v1, v0, v3, v4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 576
    .line 577
    .line 578
    monitor-exit p0

    .line 579
    goto :goto_12

    .line 580
    :catchall_1
    move-exception v0

    .line 581
    goto :goto_14

    .line 582
    :cond_13
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 583
    :goto_10
    iget-object v3, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 584
    .line 585
    check-cast v3, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 586
    .line 587
    iget-object v3, v3, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->loadErrorHandlingPolicy:Landroidx/media3/extractor/text/CueDecoder;

    .line 588
    .line 589
    iget-wide v6, v5, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->taskId:J

    .line 590
    .line 591
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 592
    .line 593
    .line 594
    monitor-enter p0

    .line 595
    :try_start_8
    iget-boolean v3, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->isReleased:Z

    .line 596
    .line 597
    if-nez v3, :cond_14

    .line 598
    .line 599
    iget-object v3, v1, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestHandler;->this$0:Ljava/lang/Object;

    .line 600
    .line 601
    check-cast v3, Landroidx/media3/exoplayer/drm/DefaultDrmSession;

    .line 602
    .line 603
    iget-object v3, v3, Landroidx/media3/exoplayer/drm/DefaultDrmSession;->responseHandler:Landroidx/appcompat/app/AlertController$ButtonHandler;

    .line 604
    .line 605
    iget v2, v2, Landroid/os/Message;->what:I

    .line 606
    .line 607
    iget-object v4, v5, Landroidx/media3/exoplayer/drm/DefaultDrmSession$RequestTask;->request:Ljava/lang/Object;

    .line 608
    .line 609
    invoke-static {v4, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 610
    .line 611
    .line 612
    move-result-object v0

    .line 613
    invoke-virtual {v3, v2, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    .line 614
    .line 615
    .line 616
    move-result-object v0

    .line 617
    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 618
    .line 619
    .line 620
    goto :goto_11

    .line 621
    :catchall_2
    move-exception v0

    .line 622
    goto :goto_13

    .line 623
    :cond_14
    :goto_11
    monitor-exit p0

    .line 624
    :goto_12
    return-void

    .line 625
    :goto_13
    monitor-exit p0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 626
    throw v0

    .line 627
    :goto_14
    :try_start_9
    monitor-exit p0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    .line 628
    throw v0

    .line 629
    :catchall_3
    move-exception v0

    .line 630
    :try_start_a
    monitor-exit v6
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    .line 631
    throw v0

    .line 632
    nop

    .line 633
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
    .end packed-switch

    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    :pswitch_data_1
    .packed-switch 0xb
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
.end method
