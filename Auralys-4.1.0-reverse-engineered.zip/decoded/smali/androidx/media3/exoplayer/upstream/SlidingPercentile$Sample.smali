.class public final Landroidx/media3/exoplayer/upstream/SlidingPercentile$Sample;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public index:I

.field public value:F

.field public weight:I
