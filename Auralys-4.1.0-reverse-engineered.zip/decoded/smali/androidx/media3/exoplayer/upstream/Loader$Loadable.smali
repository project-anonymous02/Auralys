.class public interface abstract Landroidx/media3/exoplayer/upstream/Loader$Loadable;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# virtual methods
.method public abstract cancelLoad()V
.end method

.method public abstract load()V
.end method
