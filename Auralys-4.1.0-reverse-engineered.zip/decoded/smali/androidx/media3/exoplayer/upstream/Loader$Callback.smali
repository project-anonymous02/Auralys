.class public interface abstract Landroidx/media3/exoplayer/upstream/Loader$Callback;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# virtual methods
.method public abstract onLoadCanceled(Landroidx/media3/exoplayer/upstream/Loader$Loadable;JJZ)V
.end method

.method public abstract onLoadCompleted(Landroidx/media3/exoplayer/upstream/Loader$Loadable;JJ)V
.end method

.method public abstract onLoadError(Landroidx/media3/exoplayer/upstream/Loader$Loadable;JJLjava/io/IOException;I)Lkotlin/time/InstantParseResult$Success;
.end method

.method public abstract onLoadStarted(Landroidx/media3/exoplayer/upstream/Loader$Loadable;JJI)V
.end method
