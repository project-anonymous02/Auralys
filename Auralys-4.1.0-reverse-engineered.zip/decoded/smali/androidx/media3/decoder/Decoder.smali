.class public interface abstract Landroidx/media3/decoder/Decoder;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# virtual methods
.method public abstract dequeueInputBuffer()Ljava/lang/Object;
.end method

.method public abstract dequeueOutputBuffer()Ljava/lang/Object;
.end method

.method public abstract flush()V
.end method

.method public abstract queueInputBuffer(Landroidx/media3/extractor/text/SubtitleInputBuffer;)V
.end method

.method public abstract release()V
.end method

.method public abstract setOutputStartTimeUs(J)V
.end method
