.class public abstract Landroidx/media3/decoder/DecoderOutputBuffer;
.super Landroidx/media3/decoder/Buffer;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public shouldBeSkipped:Z

.field public timeUs:J


# virtual methods
.method public abstract clear()V
.end method

.method public abstract release()V
.end method
