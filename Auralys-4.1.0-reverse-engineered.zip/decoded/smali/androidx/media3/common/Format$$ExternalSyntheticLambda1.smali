.class public final synthetic Landroidx/media3/common/Format$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"

# interfaces
.implements Lcom/google/common/base/Function;


# instance fields
.field public final synthetic $r8$classId:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 9
    iput-byte p1, p0, Landroidx/media3/common/Format$$ExternalSyntheticLambda1;->$r8$classId:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/media3/extractor/mp4/FragmentedMp4Extractor;)V
    .locals 0

    .line 1
    const/16 p1, 0x10

    .line 2
    .line 3
    iput-byte p1, p0, Landroidx/media3/common/Format$$ExternalSyntheticLambda1;->$r8$classId:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-byte p0, p0, Landroidx/media3/common/Format$$ExternalSyntheticLambda1;->$r8$classId:B

    .line 2
    .line 3
    const/4 v0, -0x1

    .line 4
    const/4 v1, 0x1

    .line 5
    const/4 v2, 0x0

    .line 6
    packed-switch p0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p1, Ljava/util/Collection;

    .line 10
    .line 11
    sget p0, Lcom/google/common/collect/ImmutableMultiset;->$r8$clinit:I

    .line 12
    .line 13
    instance-of p0, p1, Lcom/google/common/collect/ImmutableMultiset;

    .line 14
    .line 15
    if-eqz p0, :cond_0

    .line 16
    .line 17
    check-cast p1, Lcom/google/common/collect/ImmutableMultiset;

    .line 18
    .line 19
    goto/16 :goto_5

    .line 20
    .line 21
    :cond_0
    new-instance p0, Lcom/google/common/collect/ImmutableMultiset$Builder;

    .line 22
    .line 23
    instance-of v3, p1, Lcom/google/common/collect/ImmutableMultiset;

    .line 24
    .line 25
    if-eqz v3, :cond_2

    .line 26
    .line 27
    move-object v4, p1

    .line 28
    check-cast v4, Lcom/google/common/collect/ImmutableMultiset;

    .line 29
    .line 30
    check-cast v4, Lcom/google/common/collect/RegularImmutableMultiset;

    .line 31
    .line 32
    iget-object v5, v4, Lcom/google/common/collect/RegularImmutableMultiset;->elementSet:Lcom/google/common/collect/RegularImmutableMultiset$ElementSet;

    .line 33
    .line 34
    if-nez v5, :cond_1

    .line 35
    .line 36
    new-instance v5, Lcom/google/common/collect/RegularImmutableMultiset$ElementSet;

    .line 37
    .line 38
    invoke-direct {v5, v4}, Lcom/google/common/collect/RegularImmutableMultiset$ElementSet;-><init>(Lcom/google/common/collect/RegularImmutableMultiset;)V

    .line 39
    .line 40
    .line 41
    iput-object v5, v4, Lcom/google/common/collect/RegularImmutableMultiset;->elementSet:Lcom/google/common/collect/RegularImmutableMultiset$ElementSet;

    .line 42
    .line 43
    :cond_1
    invoke-virtual {v5}, Lcom/google/common/collect/RegularImmutableMultiset$ElementSet;->size()I

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    goto :goto_0

    .line 48
    :cond_2
    const/16 v4, 0xb

    .line 49
    .line 50
    :goto_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 51
    .line 52
    .line 53
    iput-boolean v2, p0, Lcom/google/common/collect/ImmutableMultiset$Builder;->buildInvoked:Z

    .line 54
    .line 55
    new-instance v5, Lcom/google/common/collect/ObjectCountHashMap;

    .line 56
    .line 57
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v5, v4}, Lcom/google/common/collect/ObjectCountHashMap;->init(I)V

    .line 61
    .line 62
    .line 63
    iput-object v5, p0, Lcom/google/common/collect/ImmutableMultiset$Builder;->contents:Lcom/google/common/collect/ObjectCountHashMap;

    .line 64
    .line 65
    if-eqz v3, :cond_7

    .line 66
    .line 67
    check-cast p1, Lcom/google/common/collect/ImmutableMultiset;

    .line 68
    .line 69
    instance-of v3, p1, Lcom/google/common/collect/RegularImmutableMultiset;

    .line 70
    .line 71
    if-eqz v3, :cond_3

    .line 72
    .line 73
    move-object v3, p1

    .line 74
    check-cast v3, Lcom/google/common/collect/RegularImmutableMultiset;

    .line 75
    .line 76
    iget-object v3, v3, Lcom/google/common/collect/RegularImmutableMultiset;->contents:Lcom/google/common/collect/ObjectCountHashMap;

    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_3
    const/4 v3, 0x0

    .line 80
    :goto_1
    if-eqz v3, :cond_6

    .line 81
    .line 82
    iget p1, v5, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 83
    .line 84
    iget v4, v3, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 85
    .line 86
    invoke-static {p1, v4}, Ljava/lang/Math;->max(II)I

    .line 87
    .line 88
    .line 89
    move-result p1

    .line 90
    invoke-virtual {v5, p1}, Lcom/google/common/collect/ObjectCountHashMap;->ensureCapacity(I)V

    .line 91
    .line 92
    .line 93
    iget p1, v3, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 94
    .line 95
    if-nez p1, :cond_5

    .line 96
    .line 97
    :cond_4
    move v2, v0

    .line 98
    :cond_5
    :goto_2
    if-ltz v2, :cond_8

    .line 99
    .line 100
    iget p1, v3, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 101
    .line 102
    invoke-static {v2, p1}, Lcoil3/util/UtilsKt;->checkElementIndex(II)V

    .line 103
    .line 104
    .line 105
    iget-object p1, v3, Lcom/google/common/collect/ObjectCountHashMap;->keys:[Ljava/lang/Object;

    .line 106
    .line 107
    aget-object p1, p1, v2

    .line 108
    .line 109
    iget v4, v3, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 110
    .line 111
    invoke-static {v2, v4}, Lcoil3/util/UtilsKt;->checkElementIndex(II)V

    .line 112
    .line 113
    .line 114
    iget-object v4, v3, Lcom/google/common/collect/ObjectCountHashMap;->values:[I

    .line 115
    .line 116
    aget v4, v4, v2

    .line 117
    .line 118
    invoke-virtual {p0, v4, p1}, Lcom/google/common/collect/ImmutableMultiset$Builder;->addCopies(ILjava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    add-int/lit8 v2, v2, 0x1

    .line 122
    .line 123
    iget p1, v3, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 124
    .line 125
    if-ge v2, p1, :cond_4

    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_6
    invoke-virtual {p1}, Lcom/google/common/collect/ImmutableMultiset;->entrySet()Lcom/google/common/collect/ImmutableSet;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    iget-object v2, p0, Lcom/google/common/collect/ImmutableMultiset$Builder;->contents:Lcom/google/common/collect/ObjectCountHashMap;

    .line 133
    .line 134
    iget v3, v2, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 135
    .line 136
    invoke-interface {v0}, Ljava/util/Set;->size()I

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    invoke-virtual {v2, v0}, Lcom/google/common/collect/ObjectCountHashMap;->ensureCapacity(I)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p1}, Lcom/google/common/collect/ImmutableMultiset;->entrySet()Lcom/google/common/collect/ImmutableSet;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    :goto_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 156
    .line 157
    .line 158
    move-result v0

    .line 159
    if-eqz v0, :cond_8

    .line 160
    .line 161
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    check-cast v0, Lcom/google/common/collect/ObjectCountHashMap$MapEntry;

    .line 166
    .line 167
    iget-object v2, v0, Lcom/google/common/collect/ObjectCountHashMap$MapEntry;->key:Ljava/lang/Object;

    .line 168
    .line 169
    invoke-virtual {v0}, Lcom/google/common/collect/ObjectCountHashMap$MapEntry;->getCount()I

    .line 170
    .line 171
    .line 172
    move-result v0

    .line 173
    invoke-virtual {p0, v0, v2}, Lcom/google/common/collect/ImmutableMultiset$Builder;->addCopies(ILjava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    goto :goto_3

    .line 177
    :cond_7
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 182
    .line 183
    .line 184
    move-result v0

    .line 185
    if-eqz v0, :cond_8

    .line 186
    .line 187
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    invoke-virtual {p0, v0}, Lcom/google/common/collect/ImmutableMultiset$Builder;->add(Ljava/lang/Object;)Lcom/google/common/collect/ImmutableCollection$Builder;

    .line 192
    .line 193
    .line 194
    goto :goto_4

    .line 195
    :cond_8
    iget-object p1, p0, Lcom/google/common/collect/ImmutableMultiset$Builder;->contents:Lcom/google/common/collect/ObjectCountHashMap;

    .line 196
    .line 197
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    iget-object p1, p0, Lcom/google/common/collect/ImmutableMultiset$Builder;->contents:Lcom/google/common/collect/ObjectCountHashMap;

    .line 201
    .line 202
    iget p1, p1, Lcom/google/common/collect/ObjectCountHashMap;->size:I

    .line 203
    .line 204
    if-nez p1, :cond_9

    .line 205
    .line 206
    sget-object p1, Lcom/google/common/collect/RegularImmutableMultiset;->EMPTY:Lcom/google/common/collect/RegularImmutableMultiset;

    .line 207
    .line 208
    goto :goto_5

    .line 209
    :cond_9
    iput-boolean v1, p0, Lcom/google/common/collect/ImmutableMultiset$Builder;->buildInvoked:Z

    .line 210
    .line 211
    new-instance p1, Lcom/google/common/collect/RegularImmutableMultiset;

    .line 212
    .line 213
    iget-object p0, p0, Lcom/google/common/collect/ImmutableMultiset$Builder;->contents:Lcom/google/common/collect/ObjectCountHashMap;

    .line 214
    .line 215
    invoke-direct {p1, p0}, Lcom/google/common/collect/RegularImmutableMultiset;-><init>(Lcom/google/common/collect/ObjectCountHashMap;)V

    .line 216
    .line 217
    .line 218
    :goto_5
    return-object p1

    .line 219
    :pswitch_0
    check-cast p1, Ljava/lang/String;

    .line 220
    .line 221
    sget-object p0, Lcom/google/common/net/MediaType;->TOKEN_MATCHER:Lcom/google/common/base/CharMatcher$And;

    .line 222
    .line 223
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 224
    .line 225
    .line 226
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 227
    .line 228
    .line 229
    move-result v0

    .line 230
    sub-int/2addr v0, v1

    .line 231
    :goto_6
    if-ltz v0, :cond_b

    .line 232
    .line 233
    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    .line 234
    .line 235
    .line 236
    move-result v3

    .line 237
    invoke-virtual {p0, v3}, Lcom/google/common/base/CharMatcher$And;->matches(C)Z

    .line 238
    .line 239
    .line 240
    move-result v3

    .line 241
    if-nez v3, :cond_a

    .line 242
    .line 243
    move v1, v2

    .line 244
    goto :goto_7

    .line 245
    :cond_a
    add-int/lit8 v0, v0, -0x1

    .line 246
    .line 247
    goto :goto_6

    .line 248
    :cond_b
    :goto_7
    if-eqz v1, :cond_c

    .line 249
    .line 250
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 251
    .line 252
    .line 253
    move-result p0

    .line 254
    if-nez p0, :cond_c

    .line 255
    .line 256
    goto :goto_9

    .line 257
    :cond_c
    new-instance p0, Ljava/lang/StringBuilder;

    .line 258
    .line 259
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 260
    .line 261
    .line 262
    move-result v0

    .line 263
    add-int/lit8 v0, v0, 0x10

    .line 264
    .line 265
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 266
    .line 267
    .line 268
    const/16 v0, 0x22

    .line 269
    .line 270
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 271
    .line 272
    .line 273
    :goto_8
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 274
    .line 275
    .line 276
    move-result v1

    .line 277
    if-ge v2, v1, :cond_f

    .line 278
    .line 279
    invoke-virtual {p1, v2}, Ljava/lang/String;->charAt(I)C

    .line 280
    .line 281
    .line 282
    move-result v1

    .line 283
    const/16 v3, 0xd

    .line 284
    .line 285
    const/16 v4, 0x5c

    .line 286
    .line 287
    if-eq v1, v3, :cond_d

    .line 288
    .line 289
    if-eq v1, v4, :cond_d

    .line 290
    .line 291
    if-ne v1, v0, :cond_e

    .line 292
    .line 293
    :cond_d
    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 294
    .line 295
    .line 296
    :cond_e
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 297
    .line 298
    .line 299
    add-int/lit8 v2, v2, 0x1

    .line 300
    .line 301
    goto :goto_8

    .line 302
    :cond_f
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 303
    .line 304
    .line 305
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    :goto_9
    return-object p1

    .line 310
    :pswitch_1
    check-cast p1, Landroidx/media3/extractor/text/CuesWithTiming;

    .line 311
    .line 312
    iget-wide p0, p1, Landroidx/media3/extractor/text/CuesWithTiming;->startTimeUs:J

    .line 313
    .line 314
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    cmp-long v0, p0, v0

    .line 320
    .line 321
    if-nez v0, :cond_10

    .line 322
    .line 323
    const-wide/16 p0, 0x0

    .line 324
    .line 325
    :cond_10
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 326
    .line 327
    .line 328
    move-result-object p0

    .line 329
    return-object p0

    .line 330
    :pswitch_2
    check-cast p1, Landroidx/media3/extractor/mp4/Track;

    .line 331
    .line 332
    return-object p1

    .line 333
    :pswitch_3
    check-cast p1, Landroidx/media3/extractor/mp4/Track;

    .line 334
    .line 335
    return-object p1

    .line 336
    :pswitch_4
    check-cast p1, Landroidx/media3/exoplayer/source/TrackGroupArray;

    .line 337
    .line 338
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 339
    .line 340
    .line 341
    new-instance p0, Landroid/os/Bundle;

    .line 342
    .line 343
    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    .line 344
    .line 345
    .line 346
    sget-object v0, Landroidx/media3/exoplayer/source/TrackGroupArray;->FIELD_TRACK_GROUPS:Ljava/lang/String;

    .line 347
    .line 348
    iget-object p1, p1, Landroidx/media3/exoplayer/source/TrackGroupArray;->trackGroups:Lcom/google/common/collect/RegularImmutableList;

    .line 349
    .line 350
    new-instance v1, Ljava/util/ArrayList;

    .line 351
    .line 352
    iget v3, p1, Lcom/google/common/collect/RegularImmutableList;->size:I

    .line 353
    .line 354
    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 355
    .line 356
    .line 357
    invoke-virtual {p1, v2}, Lcom/google/common/collect/ImmutableList;->listIterator(I)Lcom/google/common/collect/ImmutableList$Itr;

    .line 358
    .line 359
    .line 360
    move-result-object p1

    .line 361
    :goto_a
    invoke-virtual {p1}, Lcom/google/common/collect/AbstractIndexedListIterator;->hasNext()Z

    .line 362
    .line 363
    .line 364
    move-result v2

    .line 365
    if-eqz v2, :cond_11

    .line 366
    .line 367
    invoke-virtual {p1}, Lcom/google/common/collect/AbstractIndexedListIterator;->next()Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v2

    .line 371
    check-cast v2, Landroidx/media3/common/TrackGroup;

    .line 372
    .line 373
    invoke-virtual {v2}, Landroidx/media3/common/TrackGroup;->toBundle()Landroid/os/Bundle;

    .line 374
    .line 375
    .line 376
    move-result-object v2

    .line 377
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 378
    .line 379
    .line 380
    goto :goto_a

    .line 381
    :cond_11
    invoke-virtual {p0, v0, v1}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 382
    .line 383
    .line 384
    return-object p0

    .line 385
    :pswitch_5
    check-cast p1, Landroidx/media3/extractor/text/CuesWithTiming;

    .line 386
    .line 387
    iget-wide p0, p1, Landroidx/media3/extractor/text/CuesWithTiming;->durationUs:J

    .line 388
    .line 389
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 390
    .line 391
    .line 392
    move-result-object p0

    .line 393
    return-object p0

    .line 394
    :pswitch_6
    check-cast p1, Landroidx/media3/extractor/text/CuesWithTiming;

    .line 395
    .line 396
    iget-wide p0, p1, Landroidx/media3/extractor/text/CuesWithTiming;->startTimeUs:J

    .line 397
    .line 398
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 399
    .line 400
    .line 401
    move-result-object p0

    .line 402
    return-object p0

    .line 403
    :pswitch_7
    check-cast p1, Landroidx/media3/common/TrackGroup;

    .line 404
    .line 405
    iget p0, p1, Landroidx/media3/common/TrackGroup;->type:I

    .line 406
    .line 407
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 408
    .line 409
    .line 410
    move-result-object p0

    .line 411
    return-object p0

    .line 412
    :pswitch_8
    check-cast p1, Landroidx/media3/exoplayer/source/MediaPeriod;

    .line 413
    .line 414
    invoke-interface {p1}, Landroidx/media3/exoplayer/source/MediaPeriod;->getTrackGroups()Landroidx/media3/exoplayer/source/TrackGroupArray;

    .line 415
    .line 416
    .line 417
    move-result-object p0

    .line 418
    iget-object p0, p0, Landroidx/media3/exoplayer/source/TrackGroupArray;->trackGroups:Lcom/google/common/collect/RegularImmutableList;

    .line 419
    .line 420
    new-instance p1, Landroidx/media3/common/Format$$ExternalSyntheticLambda1;

    .line 421
    .line 422
    const/16 v0, 0xc

    .line 423
    .line 424
    invoke-direct {p1, v0}, Landroidx/media3/common/Format$$ExternalSyntheticLambda1;-><init>(B)V

    .line 425
    .line 426
    .line 427
    invoke-static {p1, p0}, Lcom/google/common/collect/Maps;->transform(Lcom/google/common/base/Function;Ljava/util/List;)Ljava/util/AbstractList;

    .line 428
    .line 429
    .line 430
    move-result-object p0

    .line 431
    invoke-static {p0}, Lcom/google/common/collect/ImmutableList;->copyOf(Ljava/util/Collection;)Lcom/google/common/collect/ImmutableList;

    .line 432
    .line 433
    .line 434
    move-result-object p0

    .line 435
    return-object p0

    .line 436
    :pswitch_9
    check-cast p1, Landroidx/media3/extractor/Extractor;

    .line 437
    .line 438
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 439
    .line 440
    .line 441
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 442
    .line 443
    .line 444
    move-result-object p0

    .line 445
    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 446
    .line 447
    .line 448
    move-result-object p0

    .line 449
    return-object p0

    .line 450
    :pswitch_a
    check-cast p1, Landroidx/media3/exoplayer/StreamVolumeManager$StreamVolumeState;

    .line 451
    .line 452
    new-instance v3, Landroidx/media3/exoplayer/StreamVolumeManager$StreamVolumeState;

    .line 453
    .line 454
    iget v5, p1, Landroidx/media3/exoplayer/StreamVolumeManager$StreamVolumeState;->streamType:I

    .line 455
    .line 456
    iget p0, p1, Landroidx/media3/exoplayer/StreamVolumeManager$StreamVolumeState;->volume:I

    .line 457
    .line 458
    iget v7, p1, Landroidx/media3/exoplayer/StreamVolumeManager$StreamVolumeState;->minVolume:I

    .line 459
    .line 460
    if-le p0, v7, :cond_12

    .line 461
    .line 462
    add-int/lit8 v0, p0, -0x1

    .line 463
    .line 464
    move v6, v0

    .line 465
    goto :goto_b

    .line 466
    :cond_12
    move v6, v7

    .line 467
    :goto_b
    if-gt p0, v1, :cond_13

    .line 468
    .line 469
    move v4, v1

    .line 470
    goto :goto_c

    .line 471
    :cond_13
    move v4, v2

    .line 472
    :goto_c
    iget v8, p1, Landroidx/media3/exoplayer/StreamVolumeManager$StreamVolumeState;->maxVolume:I

    .line 473
    .line 474
    invoke-direct/range {v3 .. v8}, Landroidx/media3/exoplayer/StreamVolumeManager$StreamVolumeState;-><init>(ZIIII)V

    .line 475
    .line 476
    .line 477
    return-object v3

    .line 478
    :pswitch_b
    new-instance p0, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;

    .line 479
    .line 480
    check-cast p1, Landroidx/media3/common/util/SystemClock;

    .line 481
    .line 482
    invoke-direct {p0, p1}, Landroidx/media3/exoplayer/analytics/DefaultAnalyticsCollector;-><init>(Landroidx/media3/common/util/SystemClock;)V

    .line 483
    .line 484
    .line 485
    return-object p0

    .line 486
    :pswitch_c
    check-cast p1, Landroidx/media3/common/text/Cue;

    .line 487
    .line 488
    iget p0, p1, Landroidx/media3/common/text/Cue;->zIndex:I

    .line 489
    .line 490
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 491
    .line 492
    .line 493
    move-result-object p0

    .line 494
    return-object p0

    .line 495
    :pswitch_d
    check-cast p1, Landroid/os/Bundle;

    .line 496
    .line 497
    sget-object p0, Landroidx/media3/common/Tracks$Group;->FIELD_TRACK_GROUP:Ljava/lang/String;

    .line 498
    .line 499
    invoke-virtual {p1, p0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 500
    .line 501
    .line 502
    move-result-object p0

    .line 503
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 504
    .line 505
    .line 506
    invoke-static {p0}, Landroidx/media3/common/TrackGroup;->fromBundle(Landroid/os/Bundle;)Landroidx/media3/common/TrackGroup;

    .line 507
    .line 508
    .line 509
    move-result-object p0

    .line 510
    sget-object v0, Landroidx/media3/common/Tracks$Group;->FIELD_TRACK_SUPPORT:Ljava/lang/String;

    .line 511
    .line 512
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getIntArray(Ljava/lang/String;)[I

    .line 513
    .line 514
    .line 515
    move-result-object v0

    .line 516
    iget v1, p0, Landroidx/media3/common/TrackGroup;->length:I

    .line 517
    .line 518
    new-array v3, v1, [I

    .line 519
    .line 520
    if-eqz v0, :cond_14

    .line 521
    .line 522
    goto :goto_d

    .line 523
    :cond_14
    move-object v0, v3

    .line 524
    :goto_d
    sget-object v3, Landroidx/media3/common/Tracks$Group;->FIELD_TRACK_SELECTED:Ljava/lang/String;

    .line 525
    .line 526
    invoke-virtual {p1, v3}, Landroid/os/BaseBundle;->getBooleanArray(Ljava/lang/String;)[Z

    .line 527
    .line 528
    .line 529
    move-result-object v3

    .line 530
    new-array v1, v1, [Z

    .line 531
    .line 532
    if-eqz v3, :cond_15

    .line 533
    .line 534
    goto :goto_e

    .line 535
    :cond_15
    move-object v3, v1

    .line 536
    :goto_e
    sget-object v1, Landroidx/media3/common/Tracks$Group;->FIELD_ADAPTIVE_SUPPORTED:Ljava/lang/String;

    .line 537
    .line 538
    invoke-virtual {p1, v1, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 539
    .line 540
    .line 541
    move-result p1

    .line 542
    new-instance v1, Landroidx/media3/common/Tracks$Group;

    .line 543
    .line 544
    invoke-direct {v1, p0, p1, v0, v3}, Landroidx/media3/common/Tracks$Group;-><init>(Landroidx/media3/common/TrackGroup;Z[I[Z)V

    .line 545
    .line 546
    .line 547
    return-object v1

    .line 548
    :pswitch_e
    check-cast p1, Landroidx/media3/common/Tracks$Group;

    .line 549
    .line 550
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 551
    .line 552
    .line 553
    new-instance p0, Landroid/os/Bundle;

    .line 554
    .line 555
    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    .line 556
    .line 557
    .line 558
    sget-object v0, Landroidx/media3/common/Tracks$Group;->FIELD_TRACK_GROUP:Ljava/lang/String;

    .line 559
    .line 560
    iget-object v1, p1, Landroidx/media3/common/Tracks$Group;->mediaTrackGroup:Landroidx/media3/common/TrackGroup;

    .line 561
    .line 562
    invoke-virtual {v1}, Landroidx/media3/common/TrackGroup;->toBundle()Landroid/os/Bundle;

    .line 563
    .line 564
    .line 565
    move-result-object v1

    .line 566
    invoke-virtual {p0, v0, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 567
    .line 568
    .line 569
    sget-object v0, Landroidx/media3/common/Tracks$Group;->FIELD_TRACK_SUPPORT:Ljava/lang/String;

    .line 570
    .line 571
    iget-object v1, p1, Landroidx/media3/common/Tracks$Group;->trackSupport:[I

    .line 572
    .line 573
    invoke-virtual {p0, v0, v1}, Landroid/os/BaseBundle;->putIntArray(Ljava/lang/String;[I)V

    .line 574
    .line 575
    .line 576
    sget-object v0, Landroidx/media3/common/Tracks$Group;->FIELD_TRACK_SELECTED:Ljava/lang/String;

    .line 577
    .line 578
    iget-object v1, p1, Landroidx/media3/common/Tracks$Group;->trackSelected:[Z

    .line 579
    .line 580
    invoke-virtual {p0, v0, v1}, Landroid/os/BaseBundle;->putBooleanArray(Ljava/lang/String;[Z)V

    .line 581
    .line 582
    .line 583
    sget-object v0, Landroidx/media3/common/Tracks$Group;->FIELD_ADAPTIVE_SUPPORTED:Ljava/lang/String;

    .line 584
    .line 585
    iget-boolean p1, p1, Landroidx/media3/common/Tracks$Group;->adaptiveSupported:Z

    .line 586
    .line 587
    invoke-virtual {p0, v0, p1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 588
    .line 589
    .line 590
    return-object p0

    .line 591
    :pswitch_f
    move-object p0, p1

    .line 592
    check-cast p0, Landroid/os/Bundle;

    .line 593
    .line 594
    sget-object v1, Landroidx/media3/common/Format;->DEFAULT:Landroidx/media3/common/Format;

    .line 595
    .line 596
    new-instance v3, Landroidx/media3/common/Format$Builder;

    .line 597
    .line 598
    invoke-direct {v3}, Landroidx/media3/common/Format$Builder;-><init>()V

    .line 599
    .line 600
    .line 601
    if-eqz p0, :cond_16

    .line 602
    .line 603
    const-class p1, Landroidx/media3/common/util/GlUtil;

    .line 604
    .line 605
    invoke-virtual {p1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 606
    .line 607
    .line 608
    move-result-object p1

    .line 609
    sget-object v4, Landroidx/media3/common/util/Util;->DEVICE_DEBUG_INFO:Ljava/lang/String;

    .line 610
    .line 611
    invoke-virtual {p0, p1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 612
    .line 613
    .line 614
    :cond_16
    sget-object p1, Landroidx/media3/common/Format;->FIELD_ID:Ljava/lang/String;

    .line 615
    .line 616
    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 617
    .line 618
    .line 619
    move-result-object p1

    .line 620
    iget-object v4, v1, Landroidx/media3/common/Format;->id:Ljava/lang/String;

    .line 621
    .line 622
    if-eqz p1, :cond_17

    .line 623
    .line 624
    goto :goto_f

    .line 625
    :cond_17
    move-object p1, v4

    .line 626
    :goto_f
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->id:Ljava/lang/String;

    .line 627
    .line 628
    sget-object p1, Landroidx/media3/common/Format;->FIELD_LABEL:Ljava/lang/String;

    .line 629
    .line 630
    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 631
    .line 632
    .line 633
    move-result-object p1

    .line 634
    iget-object v4, v1, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    .line 635
    .line 636
    if-eqz p1, :cond_18

    .line 637
    .line 638
    goto :goto_10

    .line 639
    :cond_18
    move-object p1, v4

    .line 640
    :goto_10
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->label:Ljava/lang/String;

    .line 641
    .line 642
    sget-object p1, Landroidx/media3/common/Format;->FIELD_LABELS:Ljava/lang/String;

    .line 643
    .line 644
    invoke-virtual {p0, p1}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 645
    .line 646
    .line 647
    move-result-object p1

    .line 648
    if-nez p1, :cond_19

    .line 649
    .line 650
    sget-object p1, Lcom/google/common/collect/ImmutableList;->EMPTY_ITR:Lcom/google/common/collect/ImmutableList$Itr;

    .line 651
    .line 652
    sget-object p1, Lcom/google/common/collect/RegularImmutableList;->EMPTY:Lcom/google/common/collect/RegularImmutableList;

    .line 653
    .line 654
    goto :goto_12

    .line 655
    :cond_19
    invoke-static {}, Lcom/google/common/collect/ImmutableList;->builder()Lcom/google/common/collect/ImmutableList$Builder;

    .line 656
    .line 657
    .line 658
    move-result-object v4

    .line 659
    move v5, v2

    .line 660
    :goto_11
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 661
    .line 662
    .line 663
    move-result v6

    .line 664
    if-ge v5, v6, :cond_1a

    .line 665
    .line 666
    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    move-result-object v6

    .line 670
    check-cast v6, Landroid/os/Bundle;

    .line 671
    .line 672
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 673
    .line 674
    .line 675
    new-instance v7, Landroidx/media3/common/Label;

    .line 676
    .line 677
    sget-object v8, Landroidx/media3/common/Label;->FIELD_LANGUAGE_INDEX:Ljava/lang/String;

    .line 678
    .line 679
    invoke-virtual {v6, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 680
    .line 681
    .line 682
    move-result-object v8

    .line 683
    sget-object v9, Landroidx/media3/common/Label;->FIELD_VALUE_INDEX:Ljava/lang/String;

    .line 684
    .line 685
    invoke-virtual {v6, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 686
    .line 687
    .line 688
    move-result-object v6

    .line 689
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 690
    .line 691
    .line 692
    invoke-direct {v7, v8, v6}, Landroidx/media3/common/Label;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 693
    .line 694
    .line 695
    invoke-virtual {v4, v7}, Lcom/google/common/collect/ImmutableCollection$ArrayBasedBuilder;->add(Ljava/lang/Object;)V

    .line 696
    .line 697
    .line 698
    add-int/lit8 v5, v5, 0x1

    .line 699
    .line 700
    goto :goto_11

    .line 701
    :cond_1a
    invoke-virtual {v4}, Lcom/google/common/collect/ImmutableList$Builder;->build()Lcom/google/common/collect/RegularImmutableList;

    .line 702
    .line 703
    .line 704
    move-result-object p1

    .line 705
    :goto_12
    invoke-static {p1}, Lcom/google/common/collect/ImmutableList;->copyOf(Ljava/util/Collection;)Lcom/google/common/collect/ImmutableList;

    .line 706
    .line 707
    .line 708
    move-result-object p1

    .line 709
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->labels:Lcom/google/common/collect/ImmutableList;

    .line 710
    .line 711
    sget-object p1, Landroidx/media3/common/Format;->FIELD_LANGUAGE:Ljava/lang/String;

    .line 712
    .line 713
    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 714
    .line 715
    .line 716
    move-result-object p1

    .line 717
    iget-object v4, v1, Landroidx/media3/common/Format;->language:Ljava/lang/String;

    .line 718
    .line 719
    if-eqz p1, :cond_1b

    .line 720
    .line 721
    goto :goto_13

    .line 722
    :cond_1b
    move-object p1, v4

    .line 723
    :goto_13
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->language:Ljava/lang/String;

    .line 724
    .line 725
    sget-object p1, Landroidx/media3/common/Format;->FIELD_SELECTION_FLAGS:Ljava/lang/String;

    .line 726
    .line 727
    iget v4, v1, Landroidx/media3/common/Format;->selectionFlags:I

    .line 728
    .line 729
    invoke-virtual {p0, p1, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 730
    .line 731
    .line 732
    move-result p1

    .line 733
    iput p1, v3, Landroidx/media3/common/Format$Builder;->selectionFlags:I

    .line 734
    .line 735
    sget-object p1, Landroidx/media3/common/Format;->FIELD_ROLE_FLAGS:Ljava/lang/String;

    .line 736
    .line 737
    iget v4, v1, Landroidx/media3/common/Format;->roleFlags:I

    .line 738
    .line 739
    invoke-virtual {p0, p1, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 740
    .line 741
    .line 742
    move-result p1

    .line 743
    iput p1, v3, Landroidx/media3/common/Format$Builder;->roleFlags:I

    .line 744
    .line 745
    sget-object p1, Landroidx/media3/common/Format;->FIELD_AUXILIARY_TRACK_TYPE:Ljava/lang/String;

    .line 746
    .line 747
    iget v4, v1, Landroidx/media3/common/Format;->auxiliaryTrackType:I

    .line 748
    .line 749
    invoke-virtual {p0, p1, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 750
    .line 751
    .line 752
    move-result p1

    .line 753
    iput p1, v3, Landroidx/media3/common/Format$Builder;->auxiliaryTrackType:I

    .line 754
    .line 755
    sget-object p1, Landroidx/media3/common/Format;->FIELD_AVERAGE_BITRATE:Ljava/lang/String;

    .line 756
    .line 757
    iget v4, v1, Landroidx/media3/common/Format;->averageBitrate:I

    .line 758
    .line 759
    invoke-virtual {p0, p1, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 760
    .line 761
    .line 762
    move-result p1

    .line 763
    iput p1, v3, Landroidx/media3/common/Format$Builder;->averageBitrate:I

    .line 764
    .line 765
    sget-object p1, Landroidx/media3/common/Format;->FIELD_PEAK_BITRATE:Ljava/lang/String;

    .line 766
    .line 767
    iget v4, v1, Landroidx/media3/common/Format;->peakBitrate:I

    .line 768
    .line 769
    invoke-virtual {p0, p1, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 770
    .line 771
    .line 772
    move-result p1

    .line 773
    iput p1, v3, Landroidx/media3/common/Format$Builder;->peakBitrate:I

    .line 774
    .line 775
    sget-object p1, Landroidx/media3/common/Format;->FIELD_CODECS:Ljava/lang/String;

    .line 776
    .line 777
    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 778
    .line 779
    .line 780
    move-result-object p1

    .line 781
    iget-object v4, v1, Landroidx/media3/common/Format;->codecs:Ljava/lang/String;

    .line 782
    .line 783
    if-eqz p1, :cond_1c

    .line 784
    .line 785
    goto :goto_14

    .line 786
    :cond_1c
    move-object p1, v4

    .line 787
    :goto_14
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->codecs:Ljava/lang/String;

    .line 788
    .line 789
    sget-object p1, Landroidx/media3/common/Format;->FIELD_PRIMARY_TRACK_GROUP_ID:Ljava/lang/String;

    .line 790
    .line 791
    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 792
    .line 793
    .line 794
    move-result-object p1

    .line 795
    iget-object v4, v1, Landroidx/media3/common/Format;->primaryTrackGroupId:Ljava/lang/String;

    .line 796
    .line 797
    if-eqz p1, :cond_1d

    .line 798
    .line 799
    goto :goto_15

    .line 800
    :cond_1d
    move-object p1, v4

    .line 801
    :goto_15
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->primaryTrackGroupId:Ljava/lang/String;

    .line 802
    .line 803
    sget-object p1, Landroidx/media3/common/Format;->FIELD_CONTAINER_MIME_TYPE:Ljava/lang/String;

    .line 804
    .line 805
    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 806
    .line 807
    .line 808
    move-result-object p1

    .line 809
    iget-object v4, v1, Landroidx/media3/common/Format;->containerMimeType:Ljava/lang/String;

    .line 810
    .line 811
    if-eqz p1, :cond_1e

    .line 812
    .line 813
    goto :goto_16

    .line 814
    :cond_1e
    move-object p1, v4

    .line 815
    :goto_16
    invoke-static {p1}, Landroidx/media3/common/MimeTypes;->normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 816
    .line 817
    .line 818
    move-result-object p1

    .line 819
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->containerMimeType:Ljava/lang/String;

    .line 820
    .line 821
    sget-object p1, Landroidx/media3/common/Format;->FIELD_SAMPLE_MIME_TYPE:Ljava/lang/String;

    .line 822
    .line 823
    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 824
    .line 825
    .line 826
    move-result-object p1

    .line 827
    iget-object v4, v1, Landroidx/media3/common/Format;->sampleMimeType:Ljava/lang/String;

    .line 828
    .line 829
    if-eqz p1, :cond_1f

    .line 830
    .line 831
    goto :goto_17

    .line 832
    :cond_1f
    move-object p1, v4

    .line 833
    :goto_17
    invoke-static {p1}, Landroidx/media3/common/MimeTypes;->normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 834
    .line 835
    .line 836
    move-result-object p1

    .line 837
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->sampleMimeType:Ljava/lang/String;

    .line 838
    .line 839
    sget-object p1, Landroidx/media3/common/Format;->FIELD_MAX_INPUT_SIZE:Ljava/lang/String;

    .line 840
    .line 841
    iget v4, v1, Landroidx/media3/common/Format;->maxInputSize:I

    .line 842
    .line 843
    invoke-virtual {p0, p1, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 844
    .line 845
    .line 846
    move-result p1

    .line 847
    iput p1, v3, Landroidx/media3/common/Format$Builder;->maxInputSize:I

    .line 848
    .line 849
    new-instance v4, Ljava/util/ArrayList;

    .line 850
    .line 851
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 852
    .line 853
    .line 854
    :goto_18
    new-instance p1, Ljava/lang/StringBuilder;

    .line 855
    .line 856
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 857
    .line 858
    .line 859
    sget-object v5, Landroidx/media3/common/Format;->FIELD_INITIALIZATION_DATA:Ljava/lang/String;

    .line 860
    .line 861
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 862
    .line 863
    .line 864
    const-string v5, "_"

    .line 865
    .line 866
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 867
    .line 868
    .line 869
    const/16 v5, 0x24

    .line 870
    .line 871
    invoke-static {v2, v5}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 872
    .line 873
    .line 874
    move-result-object v5

    .line 875
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 876
    .line 877
    .line 878
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 879
    .line 880
    .line 881
    move-result-object p1

    .line 882
    invoke-virtual {p0, p1}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B

    .line 883
    .line 884
    .line 885
    move-result-object p1

    .line 886
    if-nez p1, :cond_21

    .line 887
    .line 888
    iput-object v4, v3, Landroidx/media3/common/Format$Builder;->initializationData:Ljava/util/List;

    .line 889
    .line 890
    sget-object p1, Landroidx/media3/common/Format;->FIELD_DRM_INIT_DATA:Ljava/lang/String;

    .line 891
    .line 892
    invoke-virtual {p0, p1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 893
    .line 894
    .line 895
    move-result-object p1

    .line 896
    check-cast p1, Landroidx/media3/common/DrmInitData;

    .line 897
    .line 898
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->drmInitData:Landroidx/media3/common/DrmInitData;

    .line 899
    .line 900
    sget-object p1, Landroidx/media3/common/Format;->FIELD_SUBSAMPLE_OFFSET_US:Ljava/lang/String;

    .line 901
    .line 902
    iget-wide v4, v1, Landroidx/media3/common/Format;->subsampleOffsetUs:J

    .line 903
    .line 904
    invoke-virtual {p0, p1, v4, v5}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;J)J

    .line 905
    .line 906
    .line 907
    move-result-wide v4

    .line 908
    iput-wide v4, v3, Landroidx/media3/common/Format$Builder;->subsampleOffsetUs:J

    .line 909
    .line 910
    sget-object p1, Landroidx/media3/common/Format;->FIELD_WIDTH:Ljava/lang/String;

    .line 911
    .line 912
    iget v2, v1, Landroidx/media3/common/Format;->width:I

    .line 913
    .line 914
    invoke-virtual {p0, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 915
    .line 916
    .line 917
    move-result p1

    .line 918
    iput p1, v3, Landroidx/media3/common/Format$Builder;->width:I

    .line 919
    .line 920
    sget-object p1, Landroidx/media3/common/Format;->FIELD_HEIGHT:Ljava/lang/String;

    .line 921
    .line 922
    iget v2, v1, Landroidx/media3/common/Format;->height:I

    .line 923
    .line 924
    invoke-virtual {p0, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 925
    .line 926
    .line 927
    move-result p1

    .line 928
    iput p1, v3, Landroidx/media3/common/Format$Builder;->height:I

    .line 929
    .line 930
    sget-object p1, Landroidx/media3/common/Format;->FIELD_DECODED_WIDTH:Ljava/lang/String;

    .line 931
    .line 932
    iget v2, v1, Landroidx/media3/common/Format;->decodedWidth:I

    .line 933
    .line 934
    invoke-virtual {p0, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 935
    .line 936
    .line 937
    move-result p1

    .line 938
    iput p1, v3, Landroidx/media3/common/Format$Builder;->decodedWidth:I

    .line 939
    .line 940
    sget-object p1, Landroidx/media3/common/Format;->FIELD_DECODED_HEIGHT:Ljava/lang/String;

    .line 941
    .line 942
    iget v2, v1, Landroidx/media3/common/Format;->decodedHeight:I

    .line 943
    .line 944
    invoke-virtual {p0, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 945
    .line 946
    .line 947
    move-result p1

    .line 948
    iput p1, v3, Landroidx/media3/common/Format$Builder;->decodedHeight:I

    .line 949
    .line 950
    sget-object p1, Landroidx/media3/common/Format;->FIELD_FRAME_RATE:Ljava/lang/String;

    .line 951
    .line 952
    iget v2, v1, Landroidx/media3/common/Format;->frameRate:F

    .line 953
    .line 954
    invoke-virtual {p0, p1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;F)F

    .line 955
    .line 956
    .line 957
    move-result p1

    .line 958
    iput p1, v3, Landroidx/media3/common/Format$Builder;->frameRate:F

    .line 959
    .line 960
    sget-object p1, Landroidx/media3/common/Format;->FIELD_ROTATION_DEGREES:Ljava/lang/String;

    .line 961
    .line 962
    iget v2, v1, Landroidx/media3/common/Format;->rotationDegrees:I

    .line 963
    .line 964
    invoke-virtual {p0, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 965
    .line 966
    .line 967
    move-result p1

    .line 968
    iput p1, v3, Landroidx/media3/common/Format$Builder;->rotationDegrees:I

    .line 969
    .line 970
    sget-object p1, Landroidx/media3/common/Format;->FIELD_PIXEL_WIDTH_HEIGHT_RATIO:Ljava/lang/String;

    .line 971
    .line 972
    iget v2, v1, Landroidx/media3/common/Format;->pixelWidthHeightRatio:F

    .line 973
    .line 974
    invoke-virtual {p0, p1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;F)F

    .line 975
    .line 976
    .line 977
    move-result p1

    .line 978
    iput p1, v3, Landroidx/media3/common/Format$Builder;->pixelWidthHeightRatio:F

    .line 979
    .line 980
    sget-object p1, Landroidx/media3/common/Format;->FIELD_PROJECTION_DATA:Ljava/lang/String;

    .line 981
    .line 982
    invoke-virtual {p0, p1}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B

    .line 983
    .line 984
    .line 985
    move-result-object p1

    .line 986
    iput-object p1, v3, Landroidx/media3/common/Format$Builder;->projectionData:[B

    .line 987
    .line 988
    sget-object p1, Landroidx/media3/common/Format;->FIELD_STEREO_MODE:Ljava/lang/String;

    .line 989
    .line 990
    iget v2, v1, Landroidx/media3/common/Format;->stereoMode:I

    .line 991
    .line 992
    invoke-virtual {p0, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 993
    .line 994
    .line 995
    move-result p1

    .line 996
    iput p1, v3, Landroidx/media3/common/Format$Builder;->stereoMode:I

    .line 997
    .line 998
    sget-object p1, Landroidx/media3/common/Format;->FIELD_MAX_SUB_LAYERS:Ljava/lang/String;

    .line 999
    .line 1000
    iget v2, v1, Landroidx/media3/common/Format;->maxSubLayers:I

    .line 1001
    .line 1002
    invoke-virtual {p0, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1003
    .line 1004
    .line 1005
    move-result p1

    .line 1006
    iput p1, v3, Landroidx/media3/common/Format$Builder;->maxSubLayers:I

    .line 1007
    .line 1008
    sget-object p1, Landroidx/media3/common/Format;->FIELD_COLOR_INFO:Ljava/lang/String;

    .line 1009
    .line 1010
    invoke-virtual {p0, p1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 1011
    .line 1012
    .line 1013
    move-result-object p1

    .line 1014
    if-eqz p1, :cond_20

    .line 1015
    .line 1016
    new-instance v4, Landroidx/media3/common/ColorInfo;

    .line 1017
    .line 1018
    sget-object v2, Landroidx/media3/common/ColorInfo;->FIELD_COLOR_SPACE:Ljava/lang/String;

    .line 1019
    .line 1020
    invoke-virtual {p1, v2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1021
    .line 1022
    .line 1023
    move-result v5

    .line 1024
    sget-object v2, Landroidx/media3/common/ColorInfo;->FIELD_COLOR_RANGE:Ljava/lang/String;

    .line 1025
    .line 1026
    invoke-virtual {p1, v2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1027
    .line 1028
    .line 1029
    move-result v6

    .line 1030
    sget-object v2, Landroidx/media3/common/ColorInfo;->FIELD_COLOR_TRANSFER:Ljava/lang/String;

    .line 1031
    .line 1032
    invoke-virtual {p1, v2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1033
    .line 1034
    .line 1035
    move-result v7

    .line 1036
    sget-object v2, Landroidx/media3/common/ColorInfo;->FIELD_HDR_STATIC_INFO:Ljava/lang/String;

    .line 1037
    .line 1038
    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B

    .line 1039
    .line 1040
    .line 1041
    move-result-object v8

    .line 1042
    sget-object v2, Landroidx/media3/common/ColorInfo;->FIELD_LUMA_BITDEPTH:Ljava/lang/String;

    .line 1043
    .line 1044
    invoke-virtual {p1, v2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1045
    .line 1046
    .line 1047
    move-result v9

    .line 1048
    sget-object v2, Landroidx/media3/common/ColorInfo;->FIELD_CHROMA_BITDEPTH:Ljava/lang/String;

    .line 1049
    .line 1050
    invoke-virtual {p1, v2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1051
    .line 1052
    .line 1053
    move-result v10

    .line 1054
    invoke-direct/range {v4 .. v10}, Landroidx/media3/common/ColorInfo;-><init>(III[BII)V

    .line 1055
    .line 1056
    .line 1057
    iput-object v4, v3, Landroidx/media3/common/Format$Builder;->colorInfo:Landroidx/media3/common/ColorInfo;

    .line 1058
    .line 1059
    :cond_20
    sget-object p1, Landroidx/media3/common/Format;->FIELD_CHANNEL_COUNT:Ljava/lang/String;

    .line 1060
    .line 1061
    iget v0, v1, Landroidx/media3/common/Format;->channelCount:I

    .line 1062
    .line 1063
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1064
    .line 1065
    .line 1066
    move-result p1

    .line 1067
    iput p1, v3, Landroidx/media3/common/Format$Builder;->channelCount:I

    .line 1068
    .line 1069
    sget-object p1, Landroidx/media3/common/Format;->FIELD_SAMPLE_RATE:Ljava/lang/String;

    .line 1070
    .line 1071
    iget v0, v1, Landroidx/media3/common/Format;->sampleRate:I

    .line 1072
    .line 1073
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1074
    .line 1075
    .line 1076
    move-result p1

    .line 1077
    iput p1, v3, Landroidx/media3/common/Format$Builder;->sampleRate:I

    .line 1078
    .line 1079
    sget-object p1, Landroidx/media3/common/Format;->FIELD_PCM_ENCODING:Ljava/lang/String;

    .line 1080
    .line 1081
    iget v0, v1, Landroidx/media3/common/Format;->pcmEncoding:I

    .line 1082
    .line 1083
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1084
    .line 1085
    .line 1086
    move-result p1

    .line 1087
    iput p1, v3, Landroidx/media3/common/Format$Builder;->pcmEncoding:I

    .line 1088
    .line 1089
    sget-object p1, Landroidx/media3/common/Format;->FIELD_ENCODER_DELAY:Ljava/lang/String;

    .line 1090
    .line 1091
    iget v0, v1, Landroidx/media3/common/Format;->encoderDelay:I

    .line 1092
    .line 1093
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1094
    .line 1095
    .line 1096
    move-result p1

    .line 1097
    iput p1, v3, Landroidx/media3/common/Format$Builder;->encoderDelay:I

    .line 1098
    .line 1099
    sget-object p1, Landroidx/media3/common/Format;->FIELD_ENCODER_PADDING:Ljava/lang/String;

    .line 1100
    .line 1101
    iget v0, v1, Landroidx/media3/common/Format;->encoderPadding:I

    .line 1102
    .line 1103
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1104
    .line 1105
    .line 1106
    move-result p1

    .line 1107
    iput p1, v3, Landroidx/media3/common/Format$Builder;->encoderPadding:I

    .line 1108
    .line 1109
    sget-object p1, Landroidx/media3/common/Format;->FIELD_ACCESSIBILITY_CHANNEL:Ljava/lang/String;

    .line 1110
    .line 1111
    iget v0, v1, Landroidx/media3/common/Format;->accessibilityChannel:I

    .line 1112
    .line 1113
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1114
    .line 1115
    .line 1116
    move-result p1

    .line 1117
    iput p1, v3, Landroidx/media3/common/Format$Builder;->accessibilityChannel:I

    .line 1118
    .line 1119
    sget-object p1, Landroidx/media3/common/Format;->FIELD_TILE_COUNT_HORIZONTAL:Ljava/lang/String;

    .line 1120
    .line 1121
    iget v0, v1, Landroidx/media3/common/Format;->tileCountHorizontal:I

    .line 1122
    .line 1123
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1124
    .line 1125
    .line 1126
    move-result p1

    .line 1127
    iput p1, v3, Landroidx/media3/common/Format$Builder;->tileCountHorizontal:I

    .line 1128
    .line 1129
    sget-object p1, Landroidx/media3/common/Format;->FIELD_TILE_COUNT_VERTICAL:Ljava/lang/String;

    .line 1130
    .line 1131
    iget v0, v1, Landroidx/media3/common/Format;->tileCountVertical:I

    .line 1132
    .line 1133
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1134
    .line 1135
    .line 1136
    move-result p1

    .line 1137
    iput p1, v3, Landroidx/media3/common/Format$Builder;->tileCountVertical:I

    .line 1138
    .line 1139
    sget-object p1, Landroidx/media3/common/Format;->FIELD_CRYPTO_TYPE:Ljava/lang/String;

    .line 1140
    .line 1141
    iget v0, v1, Landroidx/media3/common/Format;->cryptoType:I

    .line 1142
    .line 1143
    invoke-virtual {p0, p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1144
    .line 1145
    .line 1146
    move-result p0

    .line 1147
    iput p0, v3, Landroidx/media3/common/Format$Builder;->cryptoType:I

    .line 1148
    .line 1149
    new-instance p0, Landroidx/media3/common/Format;

    .line 1150
    .line 1151
    invoke-direct {p0, v3}, Landroidx/media3/common/Format;-><init>(Landroidx/media3/common/Format$Builder;)V

    .line 1152
    .line 1153
    .line 1154
    return-object p0

    .line 1155
    :cond_21
    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1156
    .line 1157
    .line 1158
    add-int/lit8 v2, v2, 0x1

    .line 1159
    .line 1160
    goto/16 :goto_18

    .line 1161
    .line 1162
    :pswitch_10
    check-cast p1, Landroid/os/Bundle;

    .line 1163
    .line 1164
    sget-object p0, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_URI:Ljava/lang/String;

    .line 1165
    .line 1166
    invoke-virtual {p1, p0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 1167
    .line 1168
    .line 1169
    move-result-object p0

    .line 1170
    check-cast p0, Landroid/net/Uri;

    .line 1171
    .line 1172
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1173
    .line 1174
    .line 1175
    sget-object v0, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_MIME_TYPE:Ljava/lang/String;

    .line 1176
    .line 1177
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1178
    .line 1179
    .line 1180
    move-result-object v0

    .line 1181
    sget-object v1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_LANGUAGE:Ljava/lang/String;

    .line 1182
    .line 1183
    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1184
    .line 1185
    .line 1186
    move-result-object v1

    .line 1187
    sget-object v3, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_SELECTION_FLAGS:Ljava/lang/String;

    .line 1188
    .line 1189
    invoke-virtual {p1, v3, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1190
    .line 1191
    .line 1192
    move-result v3

    .line 1193
    sget-object v4, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_ROLE_FLAGS:Ljava/lang/String;

    .line 1194
    .line 1195
    invoke-virtual {p1, v4, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 1196
    .line 1197
    .line 1198
    move-result v2

    .line 1199
    sget-object v4, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_LABEL:Ljava/lang/String;

    .line 1200
    .line 1201
    invoke-virtual {p1, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1202
    .line 1203
    .line 1204
    move-result-object v4

    .line 1205
    sget-object v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_ID:Ljava/lang/String;

    .line 1206
    .line 1207
    invoke-virtual {p1, v5}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1208
    .line 1209
    .line 1210
    move-result-object p1

    .line 1211
    new-instance v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;

    .line 1212
    .line 1213
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 1214
    .line 1215
    .line 1216
    iput-object p0, v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->uri:Landroid/net/Uri;

    .line 1217
    .line 1218
    invoke-static {v0}, Landroidx/media3/common/MimeTypes;->normalizeMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 1219
    .line 1220
    .line 1221
    move-result-object p0

    .line 1222
    iput-object p0, v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->mimeType:Ljava/lang/String;

    .line 1223
    .line 1224
    iput-object v1, v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->language:Ljava/lang/String;

    .line 1225
    .line 1226
    iput v3, v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->selectionFlags:I

    .line 1227
    .line 1228
    iput v2, v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->roleFlags:I

    .line 1229
    .line 1230
    iput-object v4, v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->label:Ljava/lang/String;

    .line 1231
    .line 1232
    iput-object p1, v5, Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;->id:Ljava/lang/String;

    .line 1233
    .line 1234
    new-instance p0, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 1235
    .line 1236
    invoke-direct {p0, v5}, Landroidx/media3/common/MediaItem$SubtitleConfiguration;-><init>(Landroidx/media3/common/MediaItem$SubtitleConfiguration$Builder;)V

    .line 1237
    .line 1238
    .line 1239
    return-object p0

    .line 1240
    :pswitch_11
    check-cast p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;

    .line 1241
    .line 1242
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1243
    .line 1244
    .line 1245
    new-instance p0, Landroid/os/Bundle;

    .line 1246
    .line 1247
    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    .line 1248
    .line 1249
    .line 1250
    sget-object v0, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_URI:Ljava/lang/String;

    .line 1251
    .line 1252
    iget-object v1, p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->uri:Landroid/net/Uri;

    .line 1253
    .line 1254
    invoke-virtual {p0, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 1255
    .line 1256
    .line 1257
    iget-object v0, p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->mimeType:Ljava/lang/String;

    .line 1258
    .line 1259
    if-eqz v0, :cond_22

    .line 1260
    .line 1261
    sget-object v1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_MIME_TYPE:Ljava/lang/String;

    .line 1262
    .line 1263
    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1264
    .line 1265
    .line 1266
    :cond_22
    iget-object v0, p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->language:Ljava/lang/String;

    .line 1267
    .line 1268
    if-eqz v0, :cond_23

    .line 1269
    .line 1270
    sget-object v1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_LANGUAGE:Ljava/lang/String;

    .line 1271
    .line 1272
    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1273
    .line 1274
    .line 1275
    :cond_23
    iget v0, p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->selectionFlags:I

    .line 1276
    .line 1277
    if-eqz v0, :cond_24

    .line 1278
    .line 1279
    sget-object v1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_SELECTION_FLAGS:Ljava/lang/String;

    .line 1280
    .line 1281
    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 1282
    .line 1283
    .line 1284
    :cond_24
    iget v0, p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->roleFlags:I

    .line 1285
    .line 1286
    if-eqz v0, :cond_25

    .line 1287
    .line 1288
    sget-object v1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_ROLE_FLAGS:Ljava/lang/String;

    .line 1289
    .line 1290
    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 1291
    .line 1292
    .line 1293
    :cond_25
    iget-object v0, p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->label:Ljava/lang/String;

    .line 1294
    .line 1295
    if-eqz v0, :cond_26

    .line 1296
    .line 1297
    sget-object v1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_LABEL:Ljava/lang/String;

    .line 1298
    .line 1299
    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1300
    .line 1301
    .line 1302
    :cond_26
    iget-object p1, p1, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->id:Ljava/lang/String;

    .line 1303
    .line 1304
    if-eqz p1, :cond_27

    .line 1305
    .line 1306
    sget-object v0, Landroidx/media3/common/MediaItem$SubtitleConfiguration;->FIELD_ID:Ljava/lang/String;

    .line 1307
    .line 1308
    invoke-virtual {p0, v0, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1309
    .line 1310
    .line 1311
    :cond_27
    return-object p0

    .line 1312
    :pswitch_12
    check-cast p1, Landroidx/media3/common/StreamKey;

    .line 1313
    .line 1314
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1315
    .line 1316
    .line 1317
    new-instance p0, Landroid/os/Bundle;

    .line 1318
    .line 1319
    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    .line 1320
    .line 1321
    .line 1322
    iget v0, p1, Landroidx/media3/common/StreamKey;->periodIndex:I

    .line 1323
    .line 1324
    if-eqz v0, :cond_28

    .line 1325
    .line 1326
    sget-object v1, Landroidx/media3/common/StreamKey;->FIELD_PERIOD_INDEX:Ljava/lang/String;

    .line 1327
    .line 1328
    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 1329
    .line 1330
    .line 1331
    :cond_28
    iget v0, p1, Landroidx/media3/common/StreamKey;->groupIndex:I

    .line 1332
    .line 1333
    if-eqz v0, :cond_29

    .line 1334
    .line 1335
    sget-object v1, Landroidx/media3/common/StreamKey;->FIELD_GROUP_INDEX:Ljava/lang/String;

    .line 1336
    .line 1337
    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 1338
    .line 1339
    .line 1340
    :cond_29
    iget p1, p1, Landroidx/media3/common/StreamKey;->streamIndex:I

    .line 1341
    .line 1342
    if-eqz p1, :cond_2a

    .line 1343
    .line 1344
    sget-object v0, Landroidx/media3/common/StreamKey;->FIELD_STREAM_INDEX:Ljava/lang/String;

    .line 1345
    .line 1346
    invoke-virtual {p0, v0, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 1347
    .line 1348
    .line 1349
    :cond_2a
    return-object p0

    .line 1350
    :pswitch_13
    check-cast p1, Landroidx/media3/common/Label;

    .line 1351
    .line 1352
    new-instance p0, Ljava/lang/StringBuilder;

    .line 1353
    .line 1354
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 1355
    .line 1356
    .line 1357
    iget-object v0, p1, Landroidx/media3/common/Label;->language:Ljava/lang/String;

    .line 1358
    .line 1359
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1360
    .line 1361
    .line 1362
    const-string v0, ": "

    .line 1363
    .line 1364
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1365
    .line 1366
    .line 1367
    iget-object p1, p1, Landroidx/media3/common/Label;->value:Ljava/lang/String;

    .line 1368
    .line 1369
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1370
    .line 1371
    .line 1372
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1373
    .line 1374
    .line 1375
    move-result-object p0

    .line 1376
    return-object p0

    .line 1377
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
.end method
