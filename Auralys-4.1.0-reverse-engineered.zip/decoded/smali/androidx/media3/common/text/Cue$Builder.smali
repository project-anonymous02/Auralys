.class public final Landroidx/media3/common/text/Cue$Builder;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public bitmap:Landroid/graphics/Bitmap;

.field public final bitmapHeight:F

.field public line:F

.field public lineAnchor:I

.field public lineType:I

.field public multiRowAlignment:Landroid/text/Layout$Alignment;

.field public position:F

.field public positionAnchor:I

.field public shearDegrees:F

.field public size:F

.field public text:Ljava/lang/CharSequence;

.field public textAlignment:Landroid/text/Layout$Alignment;

.field public textSize:F

.field public textSizeType:I

.field public verticalType:I

.field public final windowColor:I

.field public final windowColorSet:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Landroidx/media3/common/text/Cue$Builder;->text:Ljava/lang/CharSequence;

    .line 6
    .line 7
    iput-object v0, p0, Landroidx/media3/common/text/Cue$Builder;->bitmap:Landroid/graphics/Bitmap;

    .line 8
    .line 9
    iput-object v0, p0, Landroidx/media3/common/text/Cue$Builder;->textAlignment:Landroid/text/Layout$Alignment;

    .line 10
    .line 11
    iput-object v0, p0, Landroidx/media3/common/text/Cue$Builder;->multiRowAlignment:Landroid/text/Layout$Alignment;

    .line 12
    .line 13
    const v0, -0x800001

    .line 14
    .line 15
    .line 16
    iput v0, p0, Landroidx/media3/common/text/Cue$Builder;->line:F

    .line 17
    .line 18
    const/high16 v1, -0x80000000

    .line 19
    .line 20
    iput v1, p0, Landroidx/media3/common/text/Cue$Builder;->lineType:I

    .line 21
    .line 22
    iput v1, p0, Landroidx/media3/common/text/Cue$Builder;->lineAnchor:I

    .line 23
    .line 24
    iput v0, p0, Landroidx/media3/common/text/Cue$Builder;->position:F

    .line 25
    .line 26
    iput v1, p0, Landroidx/media3/common/text/Cue$Builder;->positionAnchor:I

    .line 27
    .line 28
    iput v1, p0, Landroidx/media3/common/text/Cue$Builder;->textSizeType:I

    .line 29
    .line 30
    iput v0, p0, Landroidx/media3/common/text/Cue$Builder;->textSize:F

    .line 31
    .line 32
    iput v0, p0, Landroidx/media3/common/text/Cue$Builder;->size:F

    .line 33
    .line 34
    iput v0, p0, Landroidx/media3/common/text/Cue$Builder;->bitmapHeight:F

    .line 35
    .line 36
    const/4 v0, 0x0

    .line 37
    iput-boolean v0, p0, Landroidx/media3/common/text/Cue$Builder;->windowColorSet:Z

    .line 38
    .line 39
    const/high16 v0, -0x1000000

    .line 40
    .line 41
    iput v0, p0, Landroidx/media3/common/text/Cue$Builder;->windowColor:I

    .line 42
    .line 43
    iput v1, p0, Landroidx/media3/common/text/Cue$Builder;->verticalType:I

    .line 44
    .line 45
    return-void
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
.end method


# virtual methods
.method public final build()Landroidx/media3/common/text/Cue;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Landroidx/media3/common/text/Cue;

    .line 4
    .line 5
    move-object v2, v1

    .line 6
    iget-object v1, v0, Landroidx/media3/common/text/Cue$Builder;->text:Ljava/lang/CharSequence;

    .line 7
    .line 8
    move-object v3, v2

    .line 9
    iget-object v2, v0, Landroidx/media3/common/text/Cue$Builder;->textAlignment:Landroid/text/Layout$Alignment;

    .line 10
    .line 11
    move-object v4, v3

    .line 12
    iget-object v3, v0, Landroidx/media3/common/text/Cue$Builder;->multiRowAlignment:Landroid/text/Layout$Alignment;

    .line 13
    .line 14
    move-object v5, v4

    .line 15
    iget-object v4, v0, Landroidx/media3/common/text/Cue$Builder;->bitmap:Landroid/graphics/Bitmap;

    .line 16
    .line 17
    move-object v6, v5

    .line 18
    iget v5, v0, Landroidx/media3/common/text/Cue$Builder;->line:F

    .line 19
    .line 20
    move-object v7, v6

    .line 21
    iget v6, v0, Landroidx/media3/common/text/Cue$Builder;->lineType:I

    .line 22
    .line 23
    move-object v8, v7

    .line 24
    iget v7, v0, Landroidx/media3/common/text/Cue$Builder;->lineAnchor:I

    .line 25
    .line 26
    move-object v9, v8

    .line 27
    iget v8, v0, Landroidx/media3/common/text/Cue$Builder;->position:F

    .line 28
    .line 29
    move-object v10, v9

    .line 30
    iget v9, v0, Landroidx/media3/common/text/Cue$Builder;->positionAnchor:I

    .line 31
    .line 32
    move-object v11, v10

    .line 33
    iget v10, v0, Landroidx/media3/common/text/Cue$Builder;->textSizeType:I

    .line 34
    .line 35
    move-object v12, v11

    .line 36
    iget v11, v0, Landroidx/media3/common/text/Cue$Builder;->textSize:F

    .line 37
    .line 38
    move-object v13, v12

    .line 39
    iget v12, v0, Landroidx/media3/common/text/Cue$Builder;->size:F

    .line 40
    .line 41
    iget v14, v0, Landroidx/media3/common/text/Cue$Builder;->verticalType:I

    .line 42
    .line 43
    iget v15, v0, Landroidx/media3/common/text/Cue$Builder;->shearDegrees:F

    .line 44
    .line 45
    const/16 v18, 0x0

    .line 46
    .line 47
    move-object/from16 v16, v13

    .line 48
    .line 49
    iget v13, v0, Landroidx/media3/common/text/Cue$Builder;->bitmapHeight:F

    .line 50
    .line 51
    move-object/from16 v17, v16

    .line 52
    .line 53
    move/from16 v16, v14

    .line 54
    .line 55
    iget-boolean v14, v0, Landroidx/media3/common/text/Cue$Builder;->windowColorSet:Z

    .line 56
    .line 57
    iget v0, v0, Landroidx/media3/common/text/Cue$Builder;->windowColor:I

    .line 58
    .line 59
    move/from16 v19, v15

    .line 60
    .line 61
    move v15, v0

    .line 62
    move-object/from16 v0, v17

    .line 63
    .line 64
    move/from16 v17, v19

    .line 65
    .line 66
    invoke-direct/range {v0 .. v18}, Landroidx/media3/common/text/Cue;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFZIIFI)V

    .line 67
    .line 68
    .line 69
    return-object v0
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
.end method
