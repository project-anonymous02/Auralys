.class public final Landroidx/media3/common/util/NetworkTypeObserver$Receiver;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic this$0:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(BLjava/lang/Object;)V
    .locals 0

    .line 1
    iput-byte p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->$r8$classId:B

    .line 2
    .line 3
    iput-object p2, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    .line 1
    iget-byte v0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->$r8$classId:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    if-eqz p1, :cond_6

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    const v0, -0x7ed8ea7f

    .line 23
    .line 24
    .line 25
    const-string v1, "DiscordSvc"

    .line 26
    .line 27
    const/4 v2, 0x0

    .line 28
    if-eq p2, v0, :cond_3

    .line 29
    .line 30
    const v0, -0x56ac2893

    .line 31
    .line 32
    .line 33
    if-eq p2, v0, :cond_0

    .line 34
    .line 35
    goto/16 :goto_0

    .line 36
    .line 37
    :cond_0
    const-string p2, "android.intent.action.SCREEN_ON"

    .line 38
    .line 39
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    if-nez p1, :cond_1

    .line 44
    .line 45
    goto/16 :goto_0

    .line 46
    .line 47
    :cond_1
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 50
    .line 51
    iput-boolean v2, p1, Lcom/metrolist/music/playback/MusicService;->isScreenOff:Z

    .line 52
    .line 53
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 56
    .line 57
    iget-object p1, p1, Lcom/metrolist/music/playback/MusicService;->player:Landroidx/media3/exoplayer/ExoPlayerImpl;

    .line 58
    .line 59
    if-eqz p1, :cond_2

    .line 60
    .line 61
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlayerImpl;->isPlaying()Z

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    if-eqz p1, :cond_2

    .line 66
    .line 67
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 70
    .line 71
    invoke-virtual {p1}, Lcom/metrolist/music/playback/MusicService;->startWidgetUpdates()V

    .line 72
    .line 73
    .line 74
    :cond_2
    sget-object p1, Ltimber/log/Timber;->Forest:Lokhttp3/ConnectionPool;

    .line 75
    .line 76
    invoke-virtual {p1, v1}, Lokhttp3/ConnectionPool;->tag(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    new-array p1, v2, [Ljava/lang/Object;

    .line 80
    .line 81
    invoke-static {p1}, Lokhttp3/ConnectionPool;->i([Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 87
    .line 88
    iget-object p2, p1, Lcom/metrolist/music/playback/MusicService;->screenOffHandler:Landroid/os/Handler;

    .line 89
    .line 90
    iget-object p1, p1, Lcom/metrolist/music/playback/MusicService;->screenOffTimeout:Lcom/metrolist/music/playback/MusicService$$ExternalSyntheticLambda0;

    .line 91
    .line 92
    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 93
    .line 94
    .line 95
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 98
    .line 99
    iget-object p2, p1, Lcom/metrolist/music/playback/MusicService;->screenOffHandler:Landroid/os/Handler;

    .line 100
    .line 101
    iget-object p1, p1, Lcom/metrolist/music/playback/MusicService;->pauseTimeout:Lcom/metrolist/music/playback/MusicService$$ExternalSyntheticLambda0;

    .line 102
    .line 103
    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 104
    .line 105
    .line 106
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 109
    .line 110
    iput-boolean v2, p1, Lcom/metrolist/music/playback/MusicService;->discordIntentionalDisconnect:Z

    .line 111
    .line 112
    iget-object p0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast p0, Lcom/metrolist/music/playback/MusicService;

    .line 115
    .line 116
    invoke-virtual {p0}, Lcom/metrolist/music/playback/MusicService;->syncDiscordState()V

    .line 117
    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_3
    const-string p2, "android.intent.action.SCREEN_OFF"

    .line 121
    .line 122
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    if-nez p1, :cond_4

    .line 127
    .line 128
    goto :goto_0

    .line 129
    :cond_4
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 130
    .line 131
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 132
    .line 133
    const/4 p2, 0x1

    .line 134
    iput-boolean p2, p1, Lcom/metrolist/music/playback/MusicService;->isScreenOff:Z

    .line 135
    .line 136
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 139
    .line 140
    iget-object p2, p1, Lcom/metrolist/music/playback/MusicService;->widgetUpdateJob:Lkotlinx/coroutines/StandaloneCoroutine;

    .line 141
    .line 142
    const/4 v0, 0x0

    .line 143
    if-eqz p2, :cond_5

    .line 144
    .line 145
    invoke-virtual {p2, v0}, Lkotlinx/coroutines/JobSupport;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 146
    .line 147
    .line 148
    :cond_5
    iput-object v0, p1, Lcom/metrolist/music/playback/MusicService;->widgetUpdateJob:Lkotlinx/coroutines/StandaloneCoroutine;

    .line 149
    .line 150
    sget-object p1, Ltimber/log/Timber;->Forest:Lokhttp3/ConnectionPool;

    .line 151
    .line 152
    invoke-virtual {p1, v1}, Lokhttp3/ConnectionPool;->tag(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    new-array p1, v2, [Ljava/lang/Object;

    .line 156
    .line 157
    invoke-static {p1}, Lokhttp3/ConnectionPool;->i([Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast p1, Lcom/metrolist/music/playback/MusicService;

    .line 163
    .line 164
    iget-object p2, p1, Lcom/metrolist/music/playback/MusicService;->screenOffHandler:Landroid/os/Handler;

    .line 165
    .line 166
    iget-object p1, p1, Lcom/metrolist/music/playback/MusicService;->pauseTimeout:Lcom/metrolist/music/playback/MusicService$$ExternalSyntheticLambda0;

    .line 167
    .line 168
    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 169
    .line 170
    .line 171
    iget-object p0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 172
    .line 173
    check-cast p0, Lcom/metrolist/music/playback/MusicService;

    .line 174
    .line 175
    iget-object p1, p0, Lcom/metrolist/music/playback/MusicService;->screenOffHandler:Landroid/os/Handler;

    .line 176
    .line 177
    iget-object p0, p0, Lcom/metrolist/music/playback/MusicService;->screenOffTimeout:Lcom/metrolist/music/playback/MusicService$$ExternalSyntheticLambda0;

    .line 178
    .line 179
    const-wide/32 v0, 0x927c0

    .line 180
    .line 181
    .line 182
    invoke-virtual {p1, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 183
    .line 184
    .line 185
    :cond_6
    :goto_0
    return-void

    .line 186
    :pswitch_0
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    const-string v0, "android.intent.action.MEDIA_BUTTON"

    .line 191
    .line 192
    invoke-static {p1, v0}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result p1

    .line 196
    if-nez p1, :cond_7

    .line 197
    .line 198
    goto :goto_1

    .line 199
    :cond_7
    const-string p1, "android.intent.extra.KEY_EVENT"

    .line 200
    .line 201
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    check-cast p1, Landroid/view/KeyEvent;

    .line 206
    .line 207
    if-nez p1, :cond_8

    .line 208
    .line 209
    goto :goto_1

    .line 210
    :cond_8
    iget-object p0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 211
    .line 212
    check-cast p0, Landroidx/media3/session/MediaSessionLegacyStub;

    .line 213
    .line 214
    iget-object p0, p0, Landroidx/media3/session/MediaSessionLegacyStub;->sessionCompat:Landroidx/core/provider/CallbackWrapper;

    .line 215
    .line 216
    iget-object p0, p0, Landroidx/core/provider/CallbackWrapper;->mExecutor:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast p0, Landroidx/core/provider/CallbackWrapper;

    .line 219
    .line 220
    iget-object p0, p0, Landroidx/core/provider/CallbackWrapper;->mCallback:Ljava/lang/Object;

    .line 221
    .line 222
    check-cast p0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;

    .line 223
    .line 224
    iget-object p0, p0, Landroidx/media3/session/legacy/MediaControllerCompat$MediaControllerImplApi23;->controllerFwk:Landroid/media/session/MediaController;

    .line 225
    .line 226
    invoke-virtual {p0, p1}, Landroid/media/session/MediaController;->dispatchMediaButtonEvent(Landroid/view/KeyEvent;)Z

    .line 227
    .line 228
    .line 229
    :goto_1
    return-void

    .line 230
    :pswitch_1
    iget-object p0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast p0, Landroidx/media3/session/AndroidAutoConnectionStateObserver;

    .line 233
    .line 234
    iget-object p1, p0, Landroidx/media3/session/AndroidAutoConnectionStateObserver;->backgroundExecutor:Ljava/util/concurrent/Executor;

    .line 235
    .line 236
    new-instance p2, Landroidx/media3/session/AndroidAutoConnectionStateObserver$$ExternalSyntheticLambda0;

    .line 237
    .line 238
    const/4 v0, 0x2

    .line 239
    invoke-direct {p2, p0, v0}, Landroidx/media3/session/AndroidAutoConnectionStateObserver$$ExternalSyntheticLambda0;-><init>(Landroidx/media3/session/AndroidAutoConnectionStateObserver;B)V

    .line 240
    .line 241
    .line 242
    invoke-interface {p1, p2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 243
    .line 244
    .line 245
    return-void

    .line 246
    :pswitch_2
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->isInitialStickyBroadcast()Z

    .line 247
    .line 248
    .line 249
    move-result p1

    .line 250
    if-nez p1, :cond_9

    .line 251
    .line 252
    iget-object p0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 253
    .line 254
    check-cast p0, Landroidx/media3/exoplayer/scheduler/RequirementsWatcher;

    .line 255
    .line 256
    invoke-virtual {p0}, Landroidx/media3/exoplayer/scheduler/RequirementsWatcher;->checkRequirements()V

    .line 257
    .line 258
    .line 259
    :cond_9
    return-void

    .line 260
    :pswitch_3
    iget-object v0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 261
    .line 262
    check-cast v0, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;

    .line 263
    .line 264
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->isInitialStickyBroadcast()Z

    .line 265
    .line 266
    .line 267
    move-result p0

    .line 268
    if-nez p0, :cond_a

    .line 269
    .line 270
    invoke-virtual {v0}, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->getSpatializerChannelMasks()Ljava/util/List;

    .line 271
    .line 272
    .line 273
    move-result-object p0

    .line 274
    iget-object v1, v0, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->audioAttributes:Landroidx/media3/common/AudioAttributes;

    .line 275
    .line 276
    iget-object v2, v0, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->routedDevice:Landroid/media/AudioDeviceInfo;

    .line 277
    .line 278
    invoke-static {p1, p2, v1, v2, p0}, Landroidx/media3/exoplayer/audio/AudioCapabilities;->getCapabilitiesInternal(Landroid/content/Context;Landroid/content/Intent;Landroidx/media3/common/AudioAttributes;Landroid/media/AudioDeviceInfo;Ljava/util/List;)Landroidx/media3/exoplayer/audio/AudioCapabilities;

    .line 279
    .line 280
    .line 281
    move-result-object p0

    .line 282
    invoke-virtual {v0, p0}, Landroidx/media3/exoplayer/audio/AudioCapabilitiesReceiver;->onNewAudioCapabilities(Landroidx/media3/exoplayer/audio/AudioCapabilities;)V

    .line 283
    .line 284
    .line 285
    :cond_a
    return-void

    .line 286
    :pswitch_4
    iget-object p1, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 287
    .line 288
    check-cast p1, Landroidx/compose/ui/node/RulerTrackingMap;

    .line 289
    .line 290
    iget-object p1, p1, Landroidx/compose/ui/node/RulerTrackingMap;->accessFlags:Ljava/lang/Object;

    .line 291
    .line 292
    check-cast p1, Landroidx/compose/ui/node/RulerTrackingMap;

    .line 293
    .line 294
    new-instance p2, Landroidx/core/app/ActivityCompat$$ExternalSyntheticLambda0;

    .line 295
    .line 296
    const/16 v0, 0x12

    .line 297
    .line 298
    invoke-direct {p2, v0, p0}, Landroidx/core/app/ActivityCompat$$ExternalSyntheticLambda0;-><init>(BLjava/lang/Object;)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {p1, p2}, Landroidx/compose/ui/node/RulerTrackingMap;->runInBackground(Ljava/lang/Runnable;)V

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :pswitch_5
    iget-object p0, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast p0, Landroidx/appcompat/view/menu/BaseMenuWrapper;

    .line 308
    .line 309
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/BaseMenuWrapper;->onChange()V

    .line 310
    .line 311
    .line 312
    return-void

    .line 313
    :pswitch_6
    iget-object p2, p0, Landroidx/media3/common/util/NetworkTypeObserver$Receiver;->this$0:Ljava/lang/Object;

    .line 314
    .line 315
    check-cast p2, Landroidx/media3/common/util/NetworkTypeObserver;

    .line 316
    .line 317
    iget-object p2, p2, Landroidx/media3/common/util/NetworkTypeObserver;->backgroundExecutor:Ljava/util/concurrent/Executor;

    .line 318
    .line 319
    new-instance v0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 320
    .line 321
    const/16 v1, 0x8

    .line 322
    .line 323
    invoke-direct {v0, p0, p1, v1}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 324
    .line 325
    .line 326
    invoke-interface {p2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 327
    .line 328
    .line 329
    return-void

    .line 330
    nop

    .line 331
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
.end method
