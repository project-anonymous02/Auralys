.class public interface abstract Landroidx/media3/common/util/Consumer;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# virtual methods
.method public abstract accept(Ljava/lang/Object;)V
.end method
