.class public final Landroidx/media3/common/Format$Builder;
.super Ljava/lang/Object;
.source "r8-map-id-784ebb21e2544a232bb05d6c6532484f7cac232a67ed266b53301d1128674b41"


# instance fields
.field public accessibilityChannel:I

.field public auxiliaryTrackType:I

.field public averageBitrate:I

.field public channelCount:I

.field public codecs:Ljava/lang/String;

.field public colorInfo:Landroidx/media3/common/ColorInfo;

.field public containerMimeType:Ljava/lang/String;

.field public cryptoType:I

.field public cueReplacementBehavior:I

.field public decodedHeight:I

.field public decodedWidth:I

.field public drmInitData:Landroidx/media3/common/DrmInitData;

.field public encoderDelay:I

.field public encoderPadding:I

.field public frameRate:F

.field public hasPrerollSamples:Z

.field public height:I

.field public id:Ljava/lang/String;

.field public initializationData:Ljava/util/List;

.field public label:Ljava/lang/String;

.field public labels:Lcom/google/common/collect/ImmutableList;

.field public language:Ljava/lang/String;

.field public maxInputSize:I

.field public maxNumReorderSamples:I

.field public maxSubLayers:I

.field public metadata:Landroidx/media3/common/Metadata;

.field public pcmEncoding:I

.field public peakBitrate:I

.field public pixelWidthHeightRatio:F

.field public primaryTrackGroupId:Ljava/lang/String;

.field public projectionData:[B

.field public roleFlags:I

.field public rotationDegrees:I

.field public sampleMimeType:Ljava/lang/String;

.field public sampleRate:I

.field public selectionFlags:I

.field public stereoMode:I

.field public subsampleOffsetUs:J

.field public tileCountHorizontal:I

.field public tileCountVertical:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lcom/google/common/collect/ImmutableList;->EMPTY_ITR:Lcom/google/common/collect/ImmutableList$Itr;

    .line 5
    .line 6
    sget-object v0, Lcom/google/common/collect/RegularImmutableList;->EMPTY:Lcom/google/common/collect/RegularImmutableList;

    .line 7
    .line 8
    iput-object v0, p0, Landroidx/media3/common/Format$Builder;->labels:Lcom/google/common/collect/ImmutableList;

    .line 9
    .line 10
    const/4 v0, -0x1

    .line 11
    iput v0, p0, Landroidx/media3/common/Format$Builder;->averageBitrate:I

    .line 12
    .line 13
    iput v0, p0, Landroidx/media3/common/Format$Builder;->peakBitrate:I

    .line 14
    .line 15
    iput v0, p0, Landroidx/media3/common/Format$Builder;->maxInputSize:I

    .line 16
    .line 17
    iput v0, p0, Landroidx/media3/common/Format$Builder;->maxNumReorderSamples:I

    .line 18
    .line 19
    const-wide v1, 0x7fffffffffffffffL

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    iput-wide v1, p0, Landroidx/media3/common/Format$Builder;->subsampleOffsetUs:J

    .line 25
    .line 26
    iput v0, p0, Landroidx/media3/common/Format$Builder;->width:I

    .line 27
    .line 28
    iput v0, p0, Landroidx/media3/common/Format$Builder;->height:I

    .line 29
    .line 30
    iput v0, p0, Landroidx/media3/common/Format$Builder;->decodedWidth:I

    .line 31
    .line 32
    iput v0, p0, Landroidx/media3/common/Format$Builder;->decodedHeight:I

    .line 33
    .line 34
    const/high16 v1, -0x40800000    # -1.0f

    .line 35
    .line 36
    iput v1, p0, Landroidx/media3/common/Format$Builder;->frameRate:F

    .line 37
    .line 38
    const/high16 v1, 0x3f800000    # 1.0f

    .line 39
    .line 40
    iput v1, p0, Landroidx/media3/common/Format$Builder;->pixelWidthHeightRatio:F

    .line 41
    .line 42
    iput v0, p0, Landroidx/media3/common/Format$Builder;->stereoMode:I

    .line 43
    .line 44
    iput v0, p0, Landroidx/media3/common/Format$Builder;->maxSubLayers:I

    .line 45
    .line 46
    iput v0, p0, Landroidx/media3/common/Format$Builder;->channelCount:I

    .line 47
    .line 48
    iput v0, p0, Landroidx/media3/common/Format$Builder;->sampleRate:I

    .line 49
    .line 50
    iput v0, p0, Landroidx/media3/common/Format$Builder;->pcmEncoding:I

    .line 51
    .line 52
    iput v0, p0, Landroidx/media3/common/Format$Builder;->accessibilityChannel:I

    .line 53
    .line 54
    const/4 v1, 0x1

    .line 55
    iput v1, p0, Landroidx/media3/common/Format$Builder;->cueReplacementBehavior:I

    .line 56
    .line 57
    iput v0, p0, Landroidx/media3/common/Format$Builder;->tileCountHorizontal:I

    .line 58
    .line 59
    iput v0, p0, Landroidx/media3/common/Format$Builder;->tileCountVertical:I

    .line 60
    .line 61
    const/4 v0, 0x0

    .line 62
    iput v0, p0, Landroidx/media3/common/Format$Builder;->cryptoType:I

    .line 63
    .line 64
    iput v0, p0, Landroidx/media3/common/Format$Builder;->auxiliaryTrackType:I

    .line 65
    .line 66
    return-void
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
.end method
